# F5 — Quanto costa il tuo stack

**Tipo:** VIDEO + MOTION + PHOTO
**Obiettivo:** salvataggi e condivisioni
**Durata:** 30 secondi
**Formato:** 9:16, 1080×1920, 30 fps
**Angolo:** matematica verificabile, non opinione

---

## Hook, su tre canali

- **Visivo:** una calcolatrice che somma 20 + 20 + 10.
- **Testo a schermo:** `600 €/anno`
- **Voce:** "Fai questo conto. Cursor venti. Claude venti. Copilot dieci."

---

## Beat

| # | TC | VIDEO | MOTION / testo | Voce | Asset |
|---|---|---|---|---|---|
| 1 | 0:00–0:06 | Calcolatrice, tre addendi | `20 + 20 + 10` | "Fai questo conto. Cursor venti. Claude venti. Copilot dieci." | F5-VID-01 |
| 2 | 0:06–0:12 | Totale mensile | `50 €/mese` | "Cinquanta al mese." | F5-MOT-01 |
| 3 | 0:12–0:18 | Totale annuale | `600 €/anno` | "Seicento all'anno. Per un freelance sono due settimane di lavoro." | F5-MOT-01 |
| 4 | 0:18–0:25 | Stack alternativo | `0 €` | "L'alternativa gratis esiste, e ha dei limiti. Sui task lunghi sbaglia." | F5-VID-02 |
| 5 | 0:25–0:30 | Ritorno al conto | `rifai il conto` | "Per il resto basta. Rifai il conto con il tuo stack." | F5-MOT-01 |

---

## Shot list

| Asset | Tipo | Cosa riprendere | Note |
|---|---|---|---|
| F5-VID-01 | VIDEO | Calcolatrice fisica o del telefono, tre addendi | Inquadratura dall'alto, mano visibile |
| F5-VID-02 | VIDEO | Terminale con Freebuff su un task reale | Includi un errore o un limite, per onestà |
| F5-MOT-01 | MOTION | Contatori 50 e 600 | Ricetta MOT-03 |
| F5-PH-01 | PHOTO | Copertina | Prompt 5 |
| F5-AUD-01 | AUDIO | Voiceover | `02-voiceover/F5.txt` |

---

## Voiceover, parole esatte

> Fai questo conto. Cursor venti. Claude venti. Copilot dieci.
> Cinquanta al mese. Seicento all'anno.
> Per un freelance sono due settimane di lavoro.
> L'alternativa gratis esiste, e ha dei limiti. Sui task lunghi sbaglia.
> Per il resto basta. Rifai il conto con il tuo stack.

**Durata voce:** 27–29 secondi.

---

## Testi a schermo

| TC | Testo | Stile |
|---|---|---|
| 0:00–0:05 | `20 + 20 + 10` | 96 px, monospace |
| 0:06–0:11 | `50 €/mese` | 120 px, bianco |
| 0:12–0:17 | `600 €/anno` | 160 px, verde |
| 0:18–0:24 | `0 €` | 120 px, bianco |
| 0:25–0:30 | `rifai il conto` | 64 px, basso |

---

## Caption

> 20 + 20 + 10 = 50 €/mese. 600 €/anno.
> Per un freelance sono due settimane di lavoro.
> L'alternativa gratis esiste e ha dei limiti. Nel video dico quali.
> Rifai il conto con il tuo stack.
> ADV: referral.
> #freelance #coding #ai #costi

---

## Suono

- Musica: click ritmico, 95 BPM, volume 12%.
- SFX: "tick" su ogni addendo, "cash" sul totale.
- Nessuna voce robotica: il conto deve sembrare fatto da una persona.

---

## Export

Come F1. Controlla che `600 €/anno` resti leggibile nella thumbnail.

---

## Rischi

- I prezzi cambiano. Verificali il giorno della registrazione e aggiorna voce e testi.
- Non sommare piani che non usi. Il conto deve essere il tuo, non un massimo teorico.
- Se non sei un freelance, cambia la frase: "per me sono X giorni di lavoro".
