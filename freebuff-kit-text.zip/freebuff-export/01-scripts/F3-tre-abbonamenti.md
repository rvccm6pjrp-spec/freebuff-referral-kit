# F3 — Ho cancellato tre abbonamenti

**Tipo:** VIDEO + MOTION + PHOTO
**Obiettivo:** fiducia e condivisione
**Durata:** 35 secondi
**Formato:** 9:16, 1080×1920, 30 fps
**Angolo:** confessione con ricevute, non pubblicità

---

## Hook, su tre canali

- **Visivo:** tre email di disdetta, poi il totale.
- **Testo a schermo:** `50 €/mese → 0`
- **Voce:** "Ho cancellato tre abbonamenti. Cinquanta euro al mese. Ecco cosa ho perso."

---

## Beat

| # | TC | VIDEO | MOTION / testo | Voce | Asset |
|---|---|---|---|---|---|
| 1 | 0:00–0:06 | Tre email di disdetta, una dopo l'altra | `50 €/mese` | "Ho cancellato tre abbonamenti. Cinquanta euro al mese." | F3-VID-01, F3-MOT-01 |
| 2 | 0:06–0:12 | Schermo con il workflow ricostruito | `cosa ho perso` | "Ecco cosa ho perso: l'autocomplete perfetto e due integrazioni." | F3-VID-02 |
| 3 | 0:12–0:20 | Lo stesso lavoro fatto con Freebuff | `stesso lavoro` | "Cosa ho tenuto: tutto il resto." | F3-VID-02 |
| 4 | 0:20–0:28 | Un errore reale dell'agent, non tagliato | `questo lo sbaglia` | "Questo lo sbaglia. Sui task lunghi non è al livello dei tool a pagamento." | F3-VID-03 |
| 5 | 0:28–0:35 | Ritorno alle email | `600 €/anno` | "Se mi serve, riattivo. Per ora il conto è zero." | F3-MOT-01 |

---

## Shot list

| Asset | Tipo | Cosa riprendere | Note |
|---|---|---|---|
| F3-VID-01 | VIDEO | Tre email di disdetta, con i dati personali oscurati | Verifica che siano reali e tue |
| F3-VID-02 | VIDEO | Ricostruzione del workflow: terminale, build, test | Velocizza 4x, tieni leggibile il risultato |
| F3-VID-03 | VIDEO | Un errore vero dell'agent | Non tagliarlo: è la prova di onestà |
| F3-MOT-01 | MOTION | Contatore 50 → 600 | Ricetta MOT-03 |
| F3-PH-01 | PHOTO | Copertina | Prompt 3 |
| F3-AUD-01 | AUDIO | Voiceover | `02-voiceover/F3.txt` |

---

## Voiceover, parole esatte

> Ho cancellato tre abbonamenti. Cinquanta euro al mese.
> Ecco cosa ho perso: l'autocomplete perfetto e due integrazioni.
> Cosa ho tenuto: tutto il resto.
> Questo lo sbaglia. Sui task lunghi non è al livello dei tool a pagamento.
> Se mi serve, riattivo. Per ora il conto è zero.

**Durata voce:** 30–33 secondi.

---

## Testi a schermo

| TC | Testo | Stile |
|---|---|---|
| 0:00–0:05 | `50 €/mese` | 120 px, bianco |
| 0:06–0:11 | `cosa ho perso` | 64 px, grigio |
| 0:12–0:18 | `cosa ho tenuto` | 64 px, verde |
| 0:20–0:27 | `sbaglia` | 96 px, rosso desaturato |
| 0:28–0:35 | `600 €/anno` | 120 px, bianco |

---

## Caption

> Ho cancellato Cursor, Copilot e Claude Pro. 50 €/mese, 600 €/anno.
> Cosa ho perso: l'autocomplete perfetto e due integrazioni.
> Cosa ho tenuto: tutto il resto.
> Se il tuo lavoro dipende da quelle due cose, tieni l'abbonamento.
> ADV: referral.
> #coding #ai #freelance #italia

---

## Suono

- Musica: pianoforte minimal o lo-fi, volume 15%.
- Nessun SFX aggressivo: il tono è confessionale.
- Pausa di 0,5 s prima di "questo lo sbaglia".

---

## Export

Come F1. Per questa durata, mantieni il bitrate a 12 Mbps e controlla che i sottotitoli non coprano la tastiera.

---

## Rischi

- Non cancellare abbonamenti che ti servono davvero per girare il video.
- Se non hai tre abbonamenti, non inventarli: fai la versione con due, o cambia format.
- La frase "non è al livello" deve essere vera per il tuo caso. Non è una scheda tecnica.
