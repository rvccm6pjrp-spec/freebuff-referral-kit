# F7 — La fattura che nessuno legge

**Tipo:** VIDEO + MOTION + PHOTO
**Obiettivo:** specificità italiana e salvataggi
**Durata:** 30 secondi
**Formato:** 9:16, 1080×1920, 30 fps
**Ruolo:** è il video che nella prima settimana ha portato più iscritti

---

## Hook, su tre canali

- **Visivo:** XML a schermo, zoom su una riga chilometrica.
- **Testo a schermo:** `nessuno lo legge`
- **Voce:** "Questa è una fattura elettronica. È scritta per le macchine."

---

## Beat

| # | TC | VIDEO | MOTION / testo | Voce | Asset |
|---|---|---|---|---|---|
| 1 | 0:00–0:05 | XML, zoom su una riga | `XML` | "Questa è una fattura elettronica. È scritta per le macchine." | F7-VID-01 |
| 2 | 0:05–0:11 | I tre dati cercati a mano nel testo | `importo / fornitore / scadenza` | "Importo, fornitore, scadenza. Tre informazioni, zero leggibilità." | F7-MOT-01 |
| 3 | 0:11–0:21 | Build velocizzata | `12 minuti` | "Ho chiesto una pagina leggibile." | F7-VID-02 |
| 4 | 0:21–0:27 | Pagina finale sul telefono | `leggibile` | "Dodici minuti. Ora la mando al commercialista." | F7-VID-03 |
| 5 | 0:27–0:30 | Mano che scorre | `vediamo se capisce` | "Vediamo se capisce." | F7-VID-03 |

---

## Shot list

| Asset | Tipo | Cosa riprendere | Note |
|---|---|---|---|
| F7-VID-01 | VIDEO | File XML aperto, cursor che scorre | Oscura i dati sensibili |
| F7-VID-02 | VIDEO | Build della pagina, velocizzata 6x | Mostra il prompt, non solo il risultato |
| F7-VID-03 | VIDEO | Telefono con la pagina, mano che scorre | Riprendi lo schermo del telefono, non il desktop |
| F7-MOT-01 | MOTION | Tre etichette sui dati | Ricetta MOT-04 |
| F7-PH-01 | PHOTO | Copertina | Prompt 7 |
| F7-AUD-01 | AUDIO | Voiceover | `02-voiceover/F7.txt` |

---

## Voiceover, parole esatte

> Questa è una fattura elettronica. È scritta per le macchine.
> Importo, fornitore, scadenza. Tre informazioni, zero leggibilità.
> Ho chiesto una pagina leggibile.
> Dodici minuti. Ora la mando al commercialista.
> Vediamo se capisce.

**Durata voce:** 27–29 secondi.

---

## Testi a schermo

| TC | Testo | Stile |
|---|---|---|
| 0:00–0:04 | `XML` | 120 px, monospace |
| 0:05–0:10 | `importo` `fornitore` `scadenza` | 56 px, tre righe |
| 0:11–0:20 | `12 minuti` | 96 px, angolo alto |
| 0:21–0:26 | `leggibile` | 120 px, verde |
| 0:27–0:30 | `vediamo se capisce` | 64 px, basso |

---

## Caption

> Le fatture elettroniche sono scritte per le macchine.
> Ho fatto una pagina che le legge in dodici minuti.
> Importo, fornitore, scadenza.
> Commenta FATTURA e ti mando il prompt.
> ADV: referral.
> #fatturaelettronica #commercialista #partitaiva #italia

---

## Suono

- Musica: lo-fi italiano, 90 BPM, volume 12%.
- SFX: "scroll" lungo sull'XML, "pop" sui tre dati.
- Tono: ironico, mai lamentoso.

---

## Export

Come F1. Se pubblichi su LinkedIn, usa la stessa clip ma con caption diversa (vedi `01-scripts/F7` e adatta).

---

## Rischi

- Non usare una fattura di un cliente senza autorizzazione. Meglio una tua o una demo.
- Non dire "il commercialista non capisce": è una battuta, non un'accusa. Tienila leggera.
- Se la pagina finale ha un errore, rifalla. Questo video vende la qualità del risultato.
