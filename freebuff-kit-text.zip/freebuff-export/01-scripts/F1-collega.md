# F1 — Il collega che paga

**Tipo:** VIDEO + MOTION + PHOTO
**Obiettivo:** reach e riconoscibilità
**Durata:** 25 secondi
**Formato:** 9:16, 1080×1920, 30 fps
**Hook rate atteso:** il format originale ha fatto 3,5M view

---

## Hook, su tre canali

- **Visivo:** pagina prezzi di Cursor, poi un terminale dove qualcuno digita lentissimo.
- **Testo a schermo:** `20 €/mese`
- **Voce:** "Il mio collega paga venti euro al mese per farsi scrivere codice."

---

## Beat

| # | TC | VIDEO | MOTION / testo | Voce | Asset |
|---|---|---|---|---|---|
| 1 | 0:00–0:04 | Pagina prezzi Cursor, scroll lento | `20 €/mese` slam al centro | "Il mio collega paga venti euro al mese per farsi scrivere codice." | F1-VID-01, F1-MOT-01 |
| 2 | 0:04–0:09 | Mani che digitano una funzione, una riga alla volta | `scrive a mano` in basso | "E adesso ti faccio vedere cosa fa con le mani. Scrive. Una riga alla volta." | F1-VID-02 |
| 3 | 0:09–0:15 | Split: a sinistra le mani, a destra l'agent | Etichette `lui` / `io` | "Stessa funzione. Stesso repository." | F1-VID-03, F1-MOT-02 |
| 4 | 0:15–0:21 | `git diff` con le righe verdi | `stesso risultato` | "Venti secondi. Lui ci ha messo un'ora." | F1-VID-04 |
| 5 | 0:21–0:25 | Ritorno al prezzo | `paga ancora` | "Non gliel'ho detto. Paga ancora." | F1-MOT-01 |

---

## Shot list

| Asset | Tipo | Cosa riprendere | Note |
|---|---|---|---|
| F1-VID-01 | VIDEO | Pagina prezzi di Cursor, scroll dall'alto al piano Pro | Non tagliare il prezzo. Registra a 1080×1920 |
| F1-VID-02 | VIDEO | Mani su tastiera, inquadratura dall'alto, digitazione lenta | Luce calda, niente volto. 10 secondi di girato per scegliere i migliori 5 |
| F1-VID-03 | VIDEO | Split screen della stessa funzione: a sinistra editor vuoto, a destra agent che scrive | Stesso font e stessa finestra per rendere il confronto onesto |
| F1-VID-04 | VIDEO | Terminale con `git diff`, righe aggiunte in verde | Fermo 3 secondi sul diff completo |
| F1-MOT-01 | MOTION | Testo `20 €/mese` che entra con slam | Specifiche in `04-prompts/motion.md`, ricetta MOT-01 |
| F1-MOT-02 | MOTION | Wipe verticale che divide lo schermo | 0,4 s, bordo verde 2 px |
| F1-PH-01 | PHOTO | Copertina del video | Prompt 1 in `04-prompts/immagini.md` |
| F1-AUD-01 | AUDIO | Voiceover | Testo in `02-voiceover/F1.txt` |
| F1-CAP-01 | CAPTION | Sottotitoli | `03-captions/F1.srt` |

---

## Voiceover, parole esatte

> Il mio collega paga venti euro al mese per farsi scrivere codice.
> E adesso ti faccio vedere cosa fa con le mani.
> Scrive. Una riga alla volta.
> Stessa funzione. Stesso repository.
> Venti secondi. Lui ci ha messo un'ora.
> Non gliel'ho detto. Paga ancora.

**Durata voce:** 22–24 secondi. Se sfora, taglia "una riga alla volta".

---

## Testi a schermo

| TC | Testo | Stile |
|---|---|---|
| 0:00–0:03 | `20 €/mese` | 120 px, bold, bianco su nero |
| 0:04–0:08 | `scrive a mano` | 64 px, basso, grigio chiaro |
| 0:09–0:14 | `lui` / `io` | 48 px, angoli alti |
| 0:15–0:20 | `stesso risultato` | 72 px, centro, verde |
| 0:21–0:25 | `paga ancora` | 96 px, centro, bianco |

---

## Caption

> Il mio collega paga 20 €/mese per scrivere codice a mano.
> Stessa funzione, stesso repo, venti secondi.
> Non gliel'ho detto.
> Se sei tu il collega: commenta FREE e ti mando il comando.
> ADV: referral personale.
> #programmazione #coding #ai #cursor #freebuff

---

## Suono

- Musica: loop minimal, 90–110 BPM, volume 15%.
- SFX: un "tick" sulla digitazione lenta, un "whoosh" sul wipe, un "click" sul diff.
- Nessun soundtrend vocale: la voce deve restare protagonista.

---

## Export

- H.264, 1080×1920, 30 fps, 12 Mbps VBR 2 pass.
- Audio AAC 320 kbps, 48 kHz, normalizzato a -14 LUFS.
- Sottotitoli bruciati, con margine inferiore di 320 px.
- Nessun watermark.

---

## Rischi

- Il prezzo di Cursor può cambiare: verificalo il giorno della registrazione.
- Il confronto deve essere onesto: se la funzione richiede più tempo, mostralo. Un taglio troppo favorevole si smonta nei commenti.
- Non usare il volto del collega senza permesso. Mani e schermo bastano.
