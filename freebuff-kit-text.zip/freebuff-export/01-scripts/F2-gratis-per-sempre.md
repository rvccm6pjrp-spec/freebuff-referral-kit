# F2 — Gratis per sempre

**Tipo:** VIDEO + MOTION + PHOTO
**Obiettivo:** conversione diretta
**Durata:** 20 secondi
**Formato:** 9:16, 1080×1920, 30 fps
**Riferimento:** il Short "Free FOREVER AI Coding Agent (No subscriptions)" ha fatto 175.000 view

---

## Hook, su tre canali

- **Visivo:** pagina prezzi di Claude Code, poi schermo nero con `0 €`.
- **Testo a schermo:** `20 €/mese → 0`
- **Voce:** "Claude Code venti euro al mese. Cursor venti. Questo zero, e non è un trial."

---

## Beat

| # | TC | VIDEO | MOTION / testo | Voce | Asset |
|---|---|---|---|---|---|
| 1 | 0:00–0:04 | Due pagine prezzo affiancate | `20 €` / `20 €` | "Claude Code venti euro al mese. Cursor venti." | F2-VID-01, F2-MOT-01 |
| 2 | 0:04–0:08 | Terminale, tre comandi digitati | `npm i -g freebuff` | "Questo zero. E non è un trial: non chiede la carta." | F2-VID-02 |
| 3 | 0:08–0:15 | Build cronometrata | Timer in alto a destra | "Stesso task, stesso repo. Guarda il timer." | F2-VID-03 |
| 4 | 0:15–0:18 | Risultato funzionante | `funziona` | "Gratis anche domani. Finanziato dalla pubblicità." | F2-VID-03 |
| 5 | 0:18–0:20 | Freccia verso il commento | `commenta FREE` | "Commenta FREE e ti mando il comando." | F2-MOT-01 |

---

## Shot list

| Asset | Tipo | Cosa riprendere | Note |
|---|---|---|---|
| F2-VID-01 | VIDEO | Pagina prezzi Claude e Cursor, affiancate | Prezzi visibili e non modificati |
| F2-VID-02 | VIDEO | `npm install -g freebuff`, `cd progetto`, `freebuff` | Digitazione a velocità reale, nessun taglio |
| F2-VID-03 | VIDEO | Build di una pagina reale, con timer | 20–30 secondi di girato, montati a 8x |
| F2-MOT-01 | MOTION | Contatore da 20 a 0 | Ricetta MOT-02 |
| F2-PH-01 | PHOTO | Copertina | Prompt 2 |
| F2-AUD-01 | AUDIO | Voiceover | `02-voiceover/F2.txt` |
| F2-CAP-01 | CAPTION | Sottotitoli | `03-captions/F2.srt` |

---

## Voiceover, parole esatte

> Claude Code venti euro al mese. Cursor venti.
> Questo zero. E non è un trial: non chiede la carta.
> Stesso task, stesso repo. Guarda il timer.
> Gratis anche domani. Finanziato dalla pubblicità.
> Commenta FREE e ti mando il comando.

**Durata voce:** 18–20 secondi.

---

## Testi a schermo

| TC | Testo | Stile |
|---|---|---|
| 0:00–0:03 | `20 €` / `20 €` | 96 px, due colonne |
| 0:03–0:05 | `0 €` | 160 px, verde, slam |
| 0:08–0:14 | `timer 00:19` | 48 px, angolo alto destro |
| 0:15–0:17 | `gratis anche domani` | 64 px, centro |
| 0:18–0:20 | `commenta FREE` | 72 px, basso |

---

## Caption

> Claude Code 20 €/mese. Cursor 20 €/mese. Questo 0.
> Non è un trial e non chiede la carta.
> Un video, un comando, un task vero.
> Commenta FREE e ti mando l'installazione.
> ADV: referral.
> #coding #ai #claudecode #cursor #freebuff

---

## Suono

- Musica: beat secco, 100 BPM, volume 12%.
- SFX: "whoosh" sul passaggio a zero, "click" sul risultato.
- La voce dice il prezzo, la musica non lo copre.

---

## Export

Come F1. Sottotitoli bruciati, margine inferiore 320 px.

---

## Rischi

- "Gratis per sempre" è una promessa del sito Freebuff. Se cambia, il video invecchia: scrivilo nel calendario e ricontrolla ogni 30 giorni.
- Non dire "illimitato" se non è verificato nel momento della registrazione.
- Il timer deve essere reale. Un timer finto si nota.
