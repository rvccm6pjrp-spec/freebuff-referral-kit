# F8 — Settimana 1: 47/600

**Tipo:** VIDEO + MOTION + PHOTO
**Obiettivo:** retention e appartenenza
**Durata:** 25 secondi
**Formato:** 9:16, 1080×1920, 30 fps
**Ruolo:** tiene chi è già arrivato, non porta la prima iscrizione

---

## Hook, su tre canali

- **Visivo:** barra che si riempie fino a 47.
- **Testo a schermo:** `47/600`
- **Voce:** "Settimana uno: quarantasette su seicento."

---

## Beat

| # | TC | VIDEO | MOTION / testo | Voce | Asset |
|---|---|---|---|---|---|
| 1 | 0:00–0:05 | Barra che si riempie | `47/600` | "Settimana uno: quarantasette su seicento." | F8-MOT-01 |
| 2 | 0:05–0:11 | Il video migliore, screenshot | `il video che ha funzionato` | "Il video che ha funzionato è quello che mi vergognavo di pubblicare. Le fatture." | F8-VID-02 |
| 3 | 0:11–0:16 | Il video peggiore | `questo no` | "Non il confronto tra tool." | F8-VID-02 |
| 4 | 0:16–0:21 | Lezione a schermo | `vince il problema concreto` | "Lezione: in Italia vince il problema concreto." | F8-VID-01 |
| 5 | 0:21–0:25 | Prossimo test | `preventivi` | "La prossima provo i preventivi. Se vuoi vedere come finisce, seguimi." | F8-MOT-01 |

---

## Shot list

| Asset | Tipo | Cosa riprendere | Note |
|---|---|---|---|
| F8-VID-01 | VIDEO | Dashboard con i numeri reali della settimana | Oscura i dati sensibili, non inventarne |
| F8-VID-02 | VIDEO | Screenshot dei due video, affiancati | Usa i tuoi post reali |
| F8-MOT-01 | MOTION | Barra 47/600 | Ricetta MOT-06 |
| F8-PH-01 | PHOTO | Copertina | Prompt 8 |
| F8-AUD-01 | AUDIO | Voiceover | `02-voiceover/F8.txt` |

---

## Voiceover, parole esatte

> Settimana uno: quarantasette su seicento.
> Il video che ha funzionato è quello che mi vergognavo di pubblicare. Le fatture.
> Non il confronto tra tool.
> Lezione: in Italia vince il problema concreto.
> La prossima provo i preventivi. Se vuoi vedere come finisce, seguimi.

**Durata voce:** 22–24 secondi.

---

## Testi a schermo

| TC | Testo | Stile |
|---|---|---|
| 0:00–0:04 | `47/600` | 160 px, bianco |
| 0:05–0:10 | `fatture` | 120 px, verde |
| 0:11–0:15 | `non tool` | 96 px, grigio |
| 0:16–0:20 | `problema concreto` | 72 px, centro |
| 0:21–0:25 | `preventivi` | 96 px, basso |

---

## Caption

> Settimana 1: 47/600.
> Il video sulle fatture ha battuto quello sul confronto tra tool.
> Lezione: in Italia vince il problema concreto.
> La prossima provo i preventivi per forfettari.
> ADV: referral.
> #buildinpublic #coding #italia

---

## Suono

- Musica: la stessa sigla delle altre puntate, per creare riconoscibilità.
- SFX: "pop" sulla barra, "tick" sui numeri.
- Tono: cronaca, non celebrazione.

---

## Export

Come F1. Riusa la stessa copertina per tutte le puntate, cambiando solo il numero.

---

## Rischi

- Non gonfiare i numeri. La serie funziona solo se i dati sono veri.
- Se la settimana è andata male, dillo. "47 su 600" è già un dato onesto.
- Non trasformare il recap in una lamentela: ogni puntata deve finire con un test.
