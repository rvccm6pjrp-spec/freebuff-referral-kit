# F4 — L'ha letto da sola

**Tipo:** VIDEO + MOTION + PHOTO
**Obiettivo:** completion e salvataggi
**Durata:** 22 secondi
**Formato:** 9:16, 1080×1920, 30 fps
**Riferimento:** il format "Wait, it did what?" ha una completion del 72–85%

---

## Hook, su tre canali

- **Visivo:** una fattura PDF di 40 pagine. Al secondo 2, la pagina pulita è già pronta.
- **Testo a schermo:** `40 pagine → 1 schermata`
- **Voce:** "Le ho dato una fattura di quaranta pagine. Guarda cosa ha tirato fuori."

---

## Beat

| # | TC | VIDEO | MOTION / testo | Voce | Asset |
|---|---|---|---|---|---|
| 1 | 0:00–0:03 | PDF, scroll veloce | `40 pagine` | "Le ho dato una fattura di quaranta pagine." | F4-VID-01 |
| 2 | 0:03–0:06 | Reveal: pagina pulita già pronta | `già fatto` | "Guarda cosa ha tirato fuori." | F4-VID-02, F4-MOT-01 |
| 3 | 0:06–0:13 | Processo velocizzato | `8x` | "Importo, fornitore, scadenza." | F4-VID-03 |
| 4 | 0:13–0:18 | I tre dati evidenziati e cliccabili | `tre dati` | "Tutto cliccabile. Niente da copiare a mano." | F4-VID-02, F4-MOT-01 |
| 5 | 0:18–0:22 | Ritorno al PDF | `12 minuti` | "Dodici minuti. La prossima la faccio in sei." | F4-MOT-01 |

---

## Shot list

| Asset | Tipo | Cosa riprendere | Note |
|---|---|---|---|
| F4-VID-01 | VIDEO | PDF di una fattura reale, dati oscurati | 40 pagine vere, non un mockup |
| F4-VID-02 | VIDEO | Pagina finale con importo, fornitore, scadenza | Font leggibile, contrasto alto |
| F4-VID-03 | VIDEO | Processo di build, velocizzato 8x | Mostra il prompt, non solo il risultato |
| F4-MOT-01 | MOTION | Wipe a tendina sul reveal | 0,6 s, da sinistra, bordo verde |
| F4-PH-01 | PHOTO | Copertina | Prompt 4 |
| F4-AUD-01 | AUDIO | Voiceover | `02-voiceover/F4.txt` |
| F4-CAP-01 | CAPTION | Sottotitoli | `03-captions/F4.srt` |

---

## Voiceover, parole esatte

> Le ho dato una fattura di quaranta pagine.
> Guarda cosa ha tirato fuori.
> Importo, fornitore, scadenza.
> Tutto cliccabile. Niente da copiare a mano.
> Dodici minuti. La prossima la faccio in sei.

**Durata voce:** 19–21 secondi.

---

## Testi a schermo

| TC | Testo | Stile |
|---|---|---|
| 0:00–0:02 | `40 pagine` | 96 px, basso |
| 0:03–0:05 | `già fatto` | 120 px, verde, slam |
| 0:06–0:12 | `importo / fornitore / scadenza` | 56 px, tre righe |
| 0:13–0:17 | `tre dati` | 72 px, centro |
| 0:18–0:22 | `12 minuti` | 96 px, bianco |

---

## Caption

> Quaranta pagine di fattura elettronica, una schermata leggibile.
> Importo, fornitore, scadenza.
> Se lavori con le Partite IVA, salva questo video.
> Commenta FATTURA e ti mando il prompt.
> ADV: referral.
> #fatturaelettronica #partitaiva #freelance #ai

---

## Suono

- Musica: tensione leggera nei primi 3 secondi, poi rilascio.
- SFX: "whoosh" sul reveal, "pop" sui tre dati.
- Silenzio di 0,3 s prima di "dodici minuti".

---

## Export

Come F1. Il reveal deve essere visibile anche a schermo ridotto: controlla su un telefono prima di esportare.

---

## Rischi

- Oscura tutti i dati personali e fiscali. Una fattura vera contiene indirizzi e codici.
- Non dire "40 pagine" se il PDF ne ha 12. La specificità è il punto.
- Se il risultato non è pulito, rifai la pagina prima di registrare. Il reveal deve sembrare finito.
