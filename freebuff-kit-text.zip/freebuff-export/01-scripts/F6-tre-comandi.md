# F6 — Tre comandi

**Tipo:** VIDEO + MOTION + PHOTO
**Obiettivo:** attivazione, far completare la prima build
**Durata:** 20 secondi
**Formato:** 9:16, 1080×1920, 30 fps
**Ruolo nel funnel:** è il video che trasforma un click in un utente reale

---

## Hook, su tre canali

- **Visivo:** terminale, tre righe digitate a velocità normale.
- **Testo a schermo:** `3 comandi. 0 €.`
- **Voce:** "Tre comandi e hai un agent che scrive codice."

---

## Beat

| # | TC | VIDEO | MOTION / testo | Voce | Asset |
|---|---|---|---|---|---|
| 1 | 0:00–0:06 | `npm install -g freebuff` | `1` | "Installa." | F6-VID-01, F6-MOT-01 |
| 2 | 0:06–0:10 | `cd il-tuo-progetto` | `2` | "Entra nel progetto." | F6-VID-01, F6-MOT-01 |
| 3 | 0:10–0:13 | `freebuff` | `3` | "Avvia." | F6-VID-01, F6-MOT-01 |
| 4 | 0:13–0:17 | Primo prompt e pagina che appare | `crea una pagina` | "Nessuna carta, nessun trial." | F6-VID-02 |
| 5 | 0:17–0:20 | Freccia al commento | `commenta SETUP` | "Commenta SETUP e ti mando i cinque prompt con cui inizio." | F6-MOT-01 |

---

## Shot list

| Asset | Tipo | Cosa riprendere | Note |
|---|---|---|---|
| F6-VID-01 | VIDEO | Terminale, tre comandi a velocità reale | Nessun taglio: si deve vedere la digitazione |
| F6-VID-02 | VIDEO | Primo prompt e risultato | Un prompt semplice, risultato in meno di 15 secondi |
| F6-MOT-01 | MOTION | Contatore 1, 2, 3 in monospace | Ricetta MOT-05 |
| F6-PH-01 | PHOTO | Copertina | Prompt 6 |
| F6-AUD-01 | AUDIO | Voiceover | `02-voiceover/F6.txt` |

---

## Voiceover, parole esatte

> Tre comandi e hai un agent che scrive codice.
> Installa. Entra nel progetto. Avvia.
> Nessuna carta, nessun trial.
> Primo prompt: crea una pagina con il mio nome. Fatto.
> Commenta SETUP e ti mando i cinque prompt con cui inizio.

**Durata voce:** 18–20 secondi.

---

## Testi a schermo

| TC | Testo | Stile |
|---|---|---|
| 0:00–0:03 | `3 comandi` | 120 px, bianco |
| 0:03–0:13 | `1` `2` `3` | 160 px, verde, monospace |
| 0:13–0:17 | `0 €` | 96 px, centro |
| 0:17–0:20 | `commenta SETUP` | 72 px, basso |

---

## Caption

> `npm install -g freebuff`
> `cd il-tuo-progetto`
> `freebuff`
> Tre righe, zero carta.
> Commenta SETUP e ti mando la guida ai primi cinque prompt.
> ADV: referral.
> #coding #programmazione #studenti #ai

---

## Suono

- Musica: beat tech minimale, 110 BPM, volume 10%.
- SFX: "tick" su ogni comando, "pop" sul risultato.
- La voce deve essere più veloce delle altre: questo video vende un'azione.

---

## Export

Come F1. Se pubblichi su YouTube Shorts, aggiungi `freebuff` nel titolo e nella descrizione.

---

## Rischi

- Se il comando di installazione cambia, il video è da rifare. Ricontrolla il giorno stesso.
- Non mostrare un prompt che richiede più di 20 secondi: qui il punto è la velocità.
- Non dire "senza carta" se in futuro verrà richiesta. Oggi è vero, domani si vede.
