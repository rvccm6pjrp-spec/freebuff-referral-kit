# Freebuff Motion — Remotion

Sei overlay motion trasparenti, 1080×1920, 30 fps, pronti da montare sopra i video.

## Requisiti

- Node 20 o superiore
- npm
- Connessione per il primo render (Scarica Chrome Headless Shell e i font)

## Installazione

```bash
cd freebuff-export/remotion
npm install
```

## Anteprima

```bash
npm run studio
```

Si apre Remotion Studio. Seleziona una composizione e premi spazio.

## Render di tutte le anteprime PNG

```bash
npm run still
```

Output in `out/stills/`. Serve per controllare che testi e colori siano giusti prima del render finale.

## Render di tutti i motion

```bash
npm run render
```

Output in `out/motion/`, un file ProRes 4444 con alpha per ogni composizione.

## Promo pubblicabile

La composizione `PROMO-Freebuff` è un video verticale di 26 secondi, già impaginato per TikTok, Reels e Shorts: ricevuta dei costi, timbro "gratis", CTA e codice invito.

```bash
npm run render:promo
```

Output: `out/promo/FREEBUFF-promo-v01.mp4` (H.264, 1080×1920, 30 fps, senza audio).

**Prima di pubblicare** imposta il tuo codice in `src/config.ts`. Senza codice il video mostra `IL-TUO-CODICE`.

## Output già renderizzati (13/11/2026)

| File | Composizione | Durata | Peso |
|---|---|---|---|
| `out/motion/F1-MOT-01.mov` | PriceSlam | 2,0 s | 5,1 MB |
| `out/motion/F2-MOT-02.mov` | CounterZero | 2,0 s | 8,4 MB |
| `out/motion/F5-MOT-01.mov` | CounterStack | 3,0 s | 9,0 MB |
| `out/motion/F4-MOT-01.mov` | WipeReveal | 0,6 s | 1,2 MB |
| `out/motion/F6-MOT-01.mov` | CommandCounter | 3,0 s | 6,1 MB |
| `out/motion/F8-MOT-01.mov` | BarFill | 3,0 s | 6,5 MB |

Tutti ProRes 4444, 1080×1920, 30 fps, `yuva444p12le` (alpha a 12 bit).

Le immagini in `out/stills/` sono anteprime con fondo scuro, non overlay: servono solo a controllare il layout.

## Mapping con i video

| Composizione | File | Usata in | Durata |
|---|---|---|---|
| MOT-01-PriceSlam | `F1-MOT-01.mov` | F1, F2 | 2,0 s |
| MOT-02-CounterZero | `F2-MOT-02.mov` | F2 | 2,0 s |
| MOT-03-CounterStack | `F5-MOT-01.mov` | F5, F3 | 3,0 s |
| MOT-04-WipeReveal | `F4-MOT-01.mov` | F4, F7 | 0,6 s |
| MOT-05-CommandCounter | `F6-MOT-01.mov` | F6 | 3,0 s |
| MOT-06-BarFill | `F8-MOT-01.mov` | F8 | 3,0 s |

## Come si montano

1. Importa il video in CapCut, Premiere o DaVinci.
2. Metti il `.mov` su una traccia superiore.
3. Allinea il primo frame del motion al timecode indicato nello script.
4. Non ridimensionare: è già 1080×1920.
5. Se il motion copre il viso o il codice, sposta il video sotto, non il motion.

## Personalizzazione

- **Testi:** in `src/compositions/`, ogni componente ha il testo in chiaro.
- **Colori:** `src/theme.ts`, palette unica per tutti e sei.
- **Font:** Inter e JetBrains Mono da Google Fonts, caricati da `@remotion/google-fonts`.
- **Durate:** `src/Root.tsx`, `durationInFrames`. A 30 fps, 30 frame = 1 secondo.

## Come è fatto il trasparente

- Codec ProRes 4444.
- Pixel format `yuva444p10le`.
- Immagini PNG.
- Sfondo `transparent` in ogni composizione.

Senza questi tre parametri il file esce nero e sembra rotto. Sono già impostati in `remotion.config.ts` e nello script di render.

## Problemi comuni

**"Maximum for --concurrency is 2"**
Macchina con pochi core. Aggiungi `concurrency: 1` nelle opzioni di `renderMedia`.

**Chrome non parte**
Remotion scarica `chrome-headless-shell`. Se la rete lo blocca, passagli un binario locale con `browserExecutable`.

**Linux: `libnspr4.so: cannot open shared object file`**
Mancano le librerie di sistema del browser. Su Ubuntu/Debian:

```bash
sudo apt-get install -y libnspr4 libnss3 libatk1.0-0t64 libatk-bridge2.0-0t64 \
  libcups2t64 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 \
  libxrandr2 libgbm1 libpango-1.0-0 libcairo2 libasound2t64 libatspi2.0-0t64
```

Senza root puoi scaricare i `.deb` ed estrarli in una cartella, poi lanciare con `LD_LIBRARY_PATH`.

**Il file esce nero**
Controlla di aver renderizzato con `codec: 'prores'`, `proResProfile: '4444'`, `pixelFormat: 'yuva444p10le'`.

**I font non si caricano**
Al primo render servono 5–10 secondi in più. Se la rete è bloccata, sostituisci i font in `theme.ts` con un font di sistema.

## Struttura

```
remotion/
├── package.json
├── remotion.config.ts
├── tsconfig.json
├── scripts/
│   ├── render-all.mjs
│   └── render-stills.mjs
└── src/
    ├── index.ts
    ├── Root.tsx
    ├── theme.ts
    └── compositions/
        ├── PriceSlam.tsx
        ├── CounterZero.tsx
        ├── CounterStack.tsx
        ├── WipeReveal.tsx
        ├── CommandCounter.tsx
        └── BarFill.tsx
```
