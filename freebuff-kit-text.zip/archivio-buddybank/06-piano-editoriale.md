# 06 — Piano operativo

## La sequenza

Non partire da "quanti video faccio". Parti da qui:

1. **Verifica** le condizioni (fatto, `01`).
2. **Scegli** nome e canali (fatto, `03`).
3. **Pubblica** 3 video di fila che siano utili anche senza codice.
4. **Misura** per 3 settimane prima di cambiare qualcosa.
5. **Scala** solo il formato che produce salvataggi e aperture.
6. **Valuta** il paid solo dopo 10 aperture organiche e con ok scritto della banca.

---

## Le fasi

| Fase | Date | Obiettivo | Contenuti | Cadenza |
|---|---|---|---|---|
| **0. Setup** | gio 12 – lun 16 nov | Account, warm-up, verifica condizioni | Nessuna pubblicazione | 0 video |
| **1. Lancio** | mar 17 nov – dom 6 dic | Capire quale formato regge | Tutorial, 10€, esclusioni, tempi | 5/settimana |
| **2. Dicembre** | lun 7 – mer 23 dic | Pubblico 25–35, angolo budget | Confronto costi, "quando non conviene", carosello | 4/settimana |
| **3. Gennaio** | lun 4 – dom 17 gen | Urgenza reale, fine promo | "Ultimi giorni", riepilogo, FAQ | 5/settimana |
| **4. Chiusura** | lun 18 – mer 20 gen | Ultimo richiamo, poi cambio | 2 video finali, nessuna promessa oltre la scadenza | 2 video |
| **5. Dopo** | dal 21 gen | Non perdere il pubblico | Conti, costi, risparmio: il profilo continua | 3/settimana |

**Perché la fase 0 è separata:** il bonus maggiorato scade il 16/11 e non è nel regolamento PDF. Costruire il lancio su un dato che sparisce in quattro giorni significa girare di fretta, pubblicare su un account senza storico e poi correggere tutto il 17. Conviene partire il **17 novembre** con i 50 €, che sono la parte stabile dell'offerta. Gli 80 € restano un'opzione solo se hai già un pubblico e pubblichi entro il 15/11.

---

## Cadenza settimanale (fase 1 e 3)

| Giorno | Cosa | Piattaforma |
|---|---|---|
| Lunedì | Video "regolamento" (script 2 o 5) | TikTok + Reels |
| Martedì | Video tutorial (script 3) | TikTok |
| Mercoledì | Carosello o video "matematica" (script 4) | Instagram + TikTok |
| Giovedì | Video "quando non conviene" (script 7) | TikTok + Reels |
| Venerdì | Video "tempi" o risposta a un commento (script 6) | TikTok |
| Sabato | Riciclo del video migliore della settimana, con nuova didascalia | Reels + YouTube Shorts |
| Domenica | Riposo e revisione dati (eccezione: 17/01, ultimo giorno del codice) | — |

La prima settimana segue il calendario di lancio, quindi i giorni sono indicativi: l'importante è non pubblicare due video lo stesso giorno sullo stesso profilo.

**Perché 5 e non 14:** con 5 video a settimana puoi mantenerli buoni. Con 14 pubblichi rumore e l'algoritmo ti seppellisce.

---

## Workflow di produzione

**Domenica (60 min):** guardi i dati della settimana, scegli i 5 concept, aggiorni il CSV, scrivi le didascalie.
**Lunedì (120 min):** batch di registrazione e montaggio dei 5 video.
**Martedì–venerdì (15 min/giorno):** pubblichi, rispondi ai commenti, salvi le domande ricorrenti.
**Sabato (20 min):** riciclo e programmazione della settimana dopo.

**Regola:** non pubblicare un video lo stesso giorno in cui lo giri. La fretta si vede, e sui temi economici la fretta sembra approssimazione.

---

## Strumenti e costi

| Strumento | A cosa serve | Costo indicativo |
|---|---|---|
| Smartphone | Ripresa | 0 (hai già) |
| Microfono a clip | Audio | 15–30 € una volta |
| CapCut | Montaggio, sottotitoli | Gratis (Pro opzionale) |
| Canva | Caroselli, copertine | Gratis |
| ChatGPT / Claude | Varianti di hook e didascalie | Gratis o piano base |
| Fogli/Notion | Calendario e metriche | Gratis |
| Scheduler nativo TikTok / Meta Business Suite | Programmazione | Gratis |
| Submagic (opzionale) | Sottotitoli avanzati | ~12 €/mese, verifica il listino |

**Totale: 15–40 € una volta, poi 0–12 €/mese.** Non serve altro. Runway, HeyGen e avatar AI non servono per questo formato: un volto vero che legge un regolamento batte un avatar che recita una promo.

---

## Metriche: la dashboard settimanale

Compila ogni domenica. Otto numeri, non ottanta.

| Metrica | Dove | Cosa ti dice |
|---|---|---|
| Visualizzazioni | TikTok/IG analytics | Reach |
| Retention a 3 s (%) | TikTok/IG | Qualità dell'hook |
| Tempo medio di visione | TikTok/IG | Ritmo e durata |
| Salvataggi per 1.000 view | Calcolo | Utilità reale del contenuto |
| Condivisioni per 1.000 view | Calcolo | Capacità di passaparola |
| Visite profilo | TikTok/IG | Efficacia della CTA |
| Aperture con codice | App buddy, sezione inviti | Conversione vera |
| Ore lavorate | Tuo conteggio | Costo per acquisizione |

**Derivate:**
- Visite profilo per 1.000 view = visite / view × 1.000
- Codici per 1.000 visite profilo = aperture / visite × 1.000
- Costo per apertura = (ore × valore ora) / aperture

**Onestà:** le aperture con codice sono l'unico numero che conta davvero. Like e follower sono indicatori, non risultati. Un video con 200 view e 3 aperture vale più di uno con 50.000 view e zero.

---

## Regole di decisione (dopo 20 video)

| Se... | Allora... |
|---|---|
| Retention 3 s sotto il 40% | Riscrivi gli hook, non cambiare argomento |
| Salvataggi sotto 5 per 1.000 view | Il contenuto è troppo promozionale: aggiungi valore pratico |
| Visite profilo sotto 3 per 1.000 view | La CTA è debole o il video non promette un "prossimo passo" |
| Codici sotto 10 per 1.000 visite profilo | Bio, commento fissato o tutorial non sono chiari |
| Un formato fa il doppio dei salvataggi | Produci 3 varianti di quel formato |
| Zero aperture dopo 20 video, ma buoni salvataggi | Il pubblico è giusto ma non ha bisogno del prodotto: cambia angolo (pubblico 25–35) |
| Commenti ostili ricorrenti | Fai un video dedicato all'obiezione, non cancellare |

**Non cambiare tutto dopo 3 video.** L'algoritmo ha bisogno di 2–3 settimane per capire a chi mostrarti.

---

## Calendario sintetico

| Settimana | Date | Focus | Video chiave |
|---|---|---|---|
| 0 | 12–16 nov | Setup e primi 2 video | Trasparenza, "non è un guadagno" |
| 1 | 17–22 nov | Lancio | Tutorial codice, 10€ |
| 2 | 23–29 nov | Obiezioni | Esclusioni, tempi, "truffa?" |
| 3 | 30 nov – 6 dic | Confronto | Quando non conviene, costi carta |
| 4 | 7–13 dic | Budget di dicembre | Carosello, "50€ nel budget" |
| 5 | 14–20 dic | Regali e ultimi acquisti | Storia personale, FAQ |
| 6 | 21–27 dic | Bassa attenzione | Riciclo, nessun lancio |
| 7 | 28 dic – 3 gen | Bilancio | "Quanto ho preso davvero" (solo se vero) |
| 8 | 4–10 gen | Nuovo anno | Ripartenza, riepilogo |
| 9 | 11–17 gen | Ultimi giorni | Urgenza vera, codice fino al 17 |
| 10 | 18–20 gen | Chiusura | 2 video, poi stop |

Il dettaglio slot per slot è in `calendario-editoriale.csv`.

---

## Dopo il 20 gennaio

La promo finisce. Se il profilo si chiama "bonus buddybank", muore. Se si chiama "Due Conti", continua.

Tre contenuti di transizione già pronti:
1. "Cosa cambia ora che la promo è finita" (e cosa resta: canone, carta, costi).
2. "Come scelgo un conto: le 5 voci che guardo" (evergreen, nessun codice).
3. "Le promo che stanno arrivando" (solo se verificate, nessun anticipo inventato).

Il pubblico guadagnato con la trasparenza resta se continui a essere utile. Il pubblico guadagnato con "50€ GRATIS" sparisce il 21 gennaio.

---

## Budget

| Voce | Mese 1 | Mesi 2–3 |
|---|---|---|
| Microfono | 20 € | 0 |
| Software | 0 € | 0–12 € |
| Ads | 0 € | 0 € (non prima delle condizioni in `02`) |
| **Totale** | **20 €** | **0–12 €** |

Il vero costo è il tempo: 4–5 ore a settimana. Se non hai 4 ore, fai 3 video a settimana invece di 5, ma falli bene.

---

## Rituale del lunedì (10 minuti)

1. Quante aperture con codice la settimana scorsa?
2. Quale video ha prodotto più visite profilo?
3. Quale ha prodotto più salvataggi?
4. Qual è il commento che si ripete?
5. Il video di questa settimana risponde a quel commento?

Se non sai rispondere alla domanda 1, il problema non è il contenuto: è che non stai misurando.
