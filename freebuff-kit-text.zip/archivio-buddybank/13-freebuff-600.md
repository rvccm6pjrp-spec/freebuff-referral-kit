# 13 — Freebuff: campagna 600 inviti

> **Stato: confermato.** La pagina `freebuff.com/?view=rewards` riporta il traguardo: **600 inviti reali → MacBook Pro 2026 spedito**. Non era nelle fonti indicizzate perché è renderizzata lato client (JavaScript): da qui l'errore di verifica precedente. Restano da leggere le condizioni complete (cosa rende un invito "reale", scadenza, spedizione), ma la campagna parte.
>
> **Piano operativo Italia, 90 giorni:** `14-freebuff-italia-90.md`.

---

## 0. Cosa è verificato e cosa no

### Verificato

- Freebuff è un coding agent gratuito, senza carta di credito, sostenuto dalla pubblicità. Sito: `freebuff.com`.
- Esiste un programma referral: il link ha la forma `freebuff.com/get-started?ref=...&referrer=...`.
- I referral producono **sessioni extra** oltre alla quota giornaliera gratuita. Il README ufficiale dice: "Referrals and bounties earn extra sessions on top of the free daily allowance."
- Nel codice pubblico del progetto è scritto che ogni referral qualificato sblocca **una sessione GLM da un'ora al giorno**, senza limite dal 30/07/2026.
- I termini di servizio dicono che le reward referral sono soggette alle regole di eleggibilità mostrate con l'offerta e possono essere ritirate o annullate in caso di abuso.
- I termini vietano **più account per persona**, account duplicati, condivisi o alternativi.

### Da leggere sulla pagina rewards (non ancora confermato)

- **Cosa rende un invito "reale".** Iscrizione + uso? Prima sessione? Prima installazione? È la variabile che decide tutto: se basta l'iscrizione il numero si fa con la reach, se serve l'uso serve un contenuto che porti davvero dentro il prodotto.
- **Scadenza.** Senza data, il piano resta a 90 giorni.
- **Limiti.** Paesi eleggibili, un premio per persona, cosa succede se in più arrivano a 600.
- **Spedizione.** Chi paga dogana e consegna, e in quanto tempo.

Non serve bloccare la campagna. Serve scrivere i contenuti in modo che restino veri in ogni caso. La formula sicura è **"sto provando ad arrivare a 600 inviti per il MacBook"**, non "Freebuff regala un MacBook a chi invita 600 persone".

---

## 1. L'offerta in una frase

> **"Freebuff è un coding agent gratis, senza carta. Se ti serve, usalo. Se ti va, passa dal mio link: io ricevo sessioni extra."**

Link referral:
`https://freebuff.com/?ref=ref-f0f0c25f-722c-4afd-8fa5-a8a96d66f799&via=rewards_link`

Dove metterlo per piattaforma: `freebuff-export/07-distribuzione/REGOLE-LINK.md`.

Questa frase è vera oggi, con o senza MacBook. È la base di tutto. Il MacBook è la tua posta in gioco, non il motivo per cui la gente usa Freebuff.

**Non dire:** "Registrati e vinci un MacBook." Non è una lotteria e non è una promo ufficiale: è il tuo obiettivo personale. Dillo così: "sto provando ad arrivare a 600 inviti per il MacBook".

---

## 2. Pubblico

| Segmento | Età | Cosa vuole | Dove sta |
|---|---|---|---|
| **Studenti informatica/design** | 18–24 | Tool gratis, portfolio, progetti per il CV | TikTok, LinkedIn, Discord universitari, GitHub |
| **Junior dev e freelance** | 22–30 | Velocità, niente abbonamenti, più clienti | X, LinkedIn, Discord, YouTube |
| **Indie hacker / solopreneur** | 25–40 | Ship fast, MVP a costo zero | X, Reddit, Product Hunt, Hacker News |
| **Curiosi AI / no-code** | 20–35 | Costruire senza saper programmare | TikTok, Instagram, YouTube |

**Non è pubblico:** chi non sa cosa sia un repository, chi cerca solo un bonus in denaro, chi non ha un progetto da costruire. Freebuff non si vende con "guadagna", si vende con "costruisci".

---

## 3. La matematica dei 600

600 inviti non sono un obiettivo di contenuto. Sono un obiettivo di distribuzione.

| Conversione da visita a iscrizione | Visite necessarie per 600 |
|---|---|
| 1% | 60.000 |
| 2% | 30.000 |
| 5% | 12.000 |
| 10% (community calda) | 6.000 |

E questo assume che ogni iscritto sia "qualificato". Se per qualificato serve un progetto avviato, il numero di click necessari sale ancora.

**Se il programma conta solo gli inviti diretti**, ti servono 600 persone che passano dal tuo link. **Se conta anche il passaparola**, ogni invito può generarne altri:

| Coefficiente virale (inviti per iscritto) | Inviti diretti necessari per arrivare a 600 totali |
|---|---|
| 0,2 | ~500 |
| 0,5 | ~400 |
| 1,0 | ~300 |

Conclusione onesta: **600 inviti in 30 giorni da zero, da solo, con video organici, non è realistico.** È raggiungibile in 60–90 giorni con un asset che i developer condividono, presenza in 5 community e almeno un picco (Show HN, Product Hunt o un thread virale). Se qualcuno ti promette 600 inviti in una settimana, ti sta vendendo bot.

---

## 4. La strategia: asset-led, non content-led

Il contenuto convince; l'asset distribuisce. La differenza tra 50 inviti e 600 è un file che le persone salvano, usano e condividono.

### Il Freebuff Starter Kit

Costruisci, **con Freebuff stesso**, un pacchetto gratuito per chi vuole iniziare:

1. **Repo GitHub** con 10 template di prompt per: landing page, portfolio, SaaS con auth, dashboard, bot Telegram, API, e-commerce, blog, estensione browser, app mobile.
2. **Pagina web** che spiega ogni template in 3 righe e mostra il risultato.
3. **Video demo** da 60 secondi per ogni template, registrato mentre lo costruisci.
4. **README** con il link referral in fondo, non all'inizio: "Se questo kit ti è utile, puoi iniziare da qui."

Perché funziona: il kit è utile anche senza iscriversi. Chi lo usa e lo salva è esattamente il pubblico che poi condivide. Il link è un ringraziamento, non un pedaggio.

**Meta-prova:** costruisci il kit con Freebuff e mostra il processo. "Ho costruito questo repo con l'agent di cui ti sto parlando" è la dimostrazione più forte che puoi fare, e non richiede di apparire.

---

## 5. Canali

| Canale | Ruolo | Formato | Cadenza | Sforzo |
|---|---|---|---|---|
| **GitHub** | Distribuzione dell'asset | Repo, README, template | 1 lancio + aggiornamenti | Alto una volta |
| **X** | Reach dev, thread tecnici | Thread + screenshot + video 30s | 2–3/giorno | Medio |
| **LinkedIn** | Studenti e junior, Italia | Carosello, caso studio | 1/giorno | Medio |
| **TikTok** | Reach fredda, demo veloci | Screen recording 20–30s | 1/giorno | Alto |
| **YouTube Shorts** | Ricerca "free coding agent" | Tutorial 45–60s | 3/settimana | Medio |
| **Discord** | Conversione e supporto | Risposte utili, demo | 30 min/giorno | Medio |
| **Reddit** | Intento alto, regole severe | Post valore-first, no link dove vietato | 3/settimana | Medio |
| **Community universitarie** | Conversione alta | Workshop "build your first app" | 2/mese | Alto |
| **Product Hunt / HN** | Picco di traffico | Launch del kit | 1 volta | Alto |

**Lingua:** inglese per X, GitHub, Reddit e Product Hunt; italiano per TikTok, LinkedIn e community locali. Se punti a 600, l'inglese non è opzionale: il mercato italiano da solo è troppo piccolo per un numero così.

---

## 6. Dieci contenuti

1. **"Ho costruito un SaaS in 18 minuti con un agent gratis."** Screen recording velocizzato, timer a schermo, risultato finale funzionante. Nessun volto.
2. **"Freebuff vs Cursor: stesso task, due agent."** Confronto onesto, stesso prompt, stesso repo. Mostra tempi e differenze, non un vincitore assoluto.
3. **"Il coding agent che non ti chiede la carta."** Hook sul costo: "Zero euro, zero carta, zero abbonamento." Demo di 20 secondi.
4. **"10 prompt per costruire la tua prima app."** Carosello o thread. Ogni prompt è copiabile. Il decimo è il link al kit.
5. **"Studenti: come avere un agent gratis senza carta."** Angolo studentesco, forte su LinkedIn e TikTok.
6. **"Ho dato 5 task in parallelo a 5 agent."** Demo tecnica, per X e YouTube. Mostra il desktop, non il volto.
7. **"Dal prompt al deploy: il mio workflow."** Tutorial completo, 60 secondi. Alto salvataggio.
8. **"Quanto costa davvero il vibe coding?"** Confronto costi: abbonamenti vari vs Freebuff 0. Solo dati verificabili.
9. **"Ho pubblicato 10 template gratis: usali."** Lancio del kit. Il post più importante della campagna.
10. **"La matematica di 600 inviti."** Meta e trasparente, solo se la reward è confermata. Racconta il percorso, non il premio.

**Hook che funzionano senza volto:** "Questo sito l'ho fatto in 12 minuti", "Non ho pagato niente", "Guarda cosa succede se gli do 5 task insieme". Sempre con il risultato nei primi 2 secondi.

---

## 7. Piano 90 giorni

### Giorni 1–7 — Verifica e asset
- Ottieni le condizioni scritte della reward. Se non esistono, togli il MacBook da ogni testo.
- Crea l'account X e TikTok dedicati (non usare "Soldi HQ": è un pubblico diverso).
- Costruisci il Freebuff Starter Kit con Freebuff. Registra il processo.
- Apri il repo GitHub e la pagina del kit.

### Settimana 2 — Lancio
- Pubblica il repo, il thread X, il carosello LinkedIn.
- 3 post al giorno su X, 1 su LinkedIn.
- Entra in 5 Discord di AI coding e rispondi a 10 domande al giorno, senza link.
- Milestone: **50 inviti**.

### Settimane 3–4 — Reach
- 1 video al giorno su TikTok, 3 Shorts a settimana.
- 2 post su Reddit (leggi le regole di ogni sub prima).
- Prepara il lancio su Product Hunt e Hacker News.
- Milestone: **150 inviti**.

### Mese 2 — Community
- 2 workshop universitari: "Costruisci la tua prima app in un'ora".
- 3 collaborazioni con creator dev piccoli (5–30k): dai il kit, non soldi.
- Serie "build in public" settimanale.
- Milestone: **300 inviti**.

### Mese 3 — Picco e chiusura
- Lancio Product Hunt / Show HN.
- Leaderboard pubblica del kit (stelle GitHub, non inviti).
- Case study di chi ha costruito qualcosa.
- Milestone: **450, poi 600**.

**Regola:** se al giorno 30 sei sotto 100, non insistire con TikTok. Sposta tutto su inglese, GitHub e community dev. Il contenuto non è il collo di bottiglia: la distribuzione sì.

---

## 8. Compliance

- **Un account per persona.** I termini Freebuff vietano account duplicati, alternativi o condivisi. Niente account finti per gonfiare i numeri.
- **Niente referral comprati.** Pagare qualcuno per iscriversi è abuso: le reward possono essere annullate.
- **Niente spam.** Non mandare il link in DM a chi non lo ha chiesto, non postarlo in 20 server lo stesso giorno.
- **Disclosure.** "Se usi il mio link ricevo sessioni extra" va scritto in bio e nel post. Se il MacBook è confermato, va dichiarato anche il premio.
- **Se il premio lo metti tu:** non chiamarlo "promo Freebuff". Saresti tu il promotore, con obblighi di regolamento, montepremi e fiscalità. Non improvvisare.
- **Dichiara che il premio è di Freebuff, non tuo.** "Se arrivo a 600 inviti, Freebuff mi manda un MacBook" è corretto; "ti regalo un MacBook" no.

---

## 9. Metriche

| Metrica | Dove | Frequenza |
|---|---|---|
| Click sul link | Dashboard referral / UTM | Giornaliera |
| Iscritti | Dashboard referral | Giornaliera |
| Inviti qualificati | Dashboard referral | Settimanale |
| Attivazione (primo progetto) | Chiedi in community / osservazione | Settimanale |
| Tasso di referral (inviti per iscritto) | Calcolo | Settimanale |
| Costo per invito | Ore × valore ora / inviti | Mensile |
| Canale migliore | UTM o domanda diretta | Settimanale |

**Un solo numero conta davvero:** inviti qualificati. Click, view e follower sono indicatori, non risultati.

---

## 10. Cosa fare oggi

1. Leggi le condizioni sulla pagina rewards e annota cosa rende un invito "reale": cambia il piano, non lo blocca.
2. Apri l'account dev (X + TikTok) con un nome diverso da quello banking.
3. Metti in bio il contatore: **0/600 → MacBook**.
4. Gira il primo video della serie (script in `14-freebuff-italia-90.md`, sezione 2).
5. Apri il repo del kit, anche vuoto, con il README e il link referral in fondo.

Il MacBook è un ottimo hook. Ma l'hook da solo non basta: serve una storia che le persone vogliano seguire fino alla fine. Il piano operativo è nel file 14.
