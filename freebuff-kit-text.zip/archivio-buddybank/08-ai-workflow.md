# 08 — Workflow AI

L'AI non serve a "fare più video". Serve a fare **meglio** le parti noiose: varianti di hook, riscritture, adattamenti per piattaforma, analisi dei commenti. La strategia, la faccia e il giudizio restano tuoi.

**Regola:** nessun numero, data o condizione della promo può uscire da un modello senza essere verificato sul PDF. I modelli inventano i dettagli con una sicurezza impressionante.

---

## Stack consigliato

| Strumento | A cosa serve davvero | Costo | Verdetto |
|---|---|---|---|
| **Claude o ChatGPT** | Hook, script, adattamento didascalie, analisi commenti | Free tier sufficiente | **Sì, il più utile** |
| **CapCut** | Montaggio, sottotitoli automatici (da correggere a mano) | Free | **Sì** |
| **Canva** | Caroselli e copertine | Free | **Sì** |
| **Fogli/Notion** | Calendario e dashboard | Free | **Sì** |
| **Submagic** | Sottotitoli animati, se vuoi alzare la resa | ~12 €/mese | Opzionale |
| **ElevenLabs** | Voce per formato faceless | Free tier limitato | Solo se non vuoi la tua voce |
| **OpusClip** | Clip da contenuti lunghi | Free limitato | Non serve: non hai long-form |
| **Avatar AI (HeyGen, Synthesia)** | Presenter sintetico | 20–100 €/mese | **No** per questo progetto |
| **Generatori "video completo automatico"** | Pubblicazione automatica | 30–250 €/mese | **No**: rischiano claim non verificati |

**Perché no agli avatar:** in un contenuto che dice "fidati, ho letto il regolamento", un volto sintetico è esattamente il segnale opposto. La ricerca sul settore è chiara: l'AI funziona come acceleratore di produzione, non come sostituto della credibilità. E i video generati vanno comunque montati, perché le clip durano pochi secondi.

---

## Cosa l'AI fa bene (e cosa no)

| Fa bene | Fa male |
|---|---|
| Generare 20 varianti di hook in 30 secondi | Sapere se il bonus è 50 o 80 € oggi |
| Riscrivere lo stesso concetto per 3 livelli di competenza | Giudicare la conformità pubblicitaria |
| Estrarre condizioni da un PDF (con citazioni) | Conoscere il tuo pubblico meglio dei commenti |
| Trasformare i commenti in idee di contenuto | Prevedere quali video funzioneranno |
| Adattare una didascalia da TikTok a Instagram | Sostituire la tua voce in camera |
| Controllare se un testo contiene claim vietati | Garantire che una promo bancaria sia ancora attiva |

---

## Il workflow settimanale (90 minuti di AI, 2 ore di te)

### Step 1 — Estrazione dei fatti (10 min)
Incolla nel modello il testo del regolamento o i passaggi rilevanti. Chiedi una **tabella di fatti con citazioni**. Poi verifica ogni riga sul PDF. Non saltare questo passaggio: è quello che impedisce di pubblicare un video con la cifra sbagliata.

### Step 2 — Angoli (10 min)
Chiedi 10 angoli diversi sullo stesso fatto. Scegline 3 che non siano "il bonus è fantastico". Un buon angolo è un'**obiezione**: "non è per tutti", "non arriva subito", "non è un guadagno".

### Step 3 — Hook (15 min)
Chiedi 20 hook, poi scegline 5 con un criterio: specificità, tensione, credibilità. Scarta quelli che suonano come un annuncio. Un hook buono si capisce senza audio.

### Step 4 — Script (15 min)
Struttura in 5 battute: hook → promessa → prova → condizione → CTA. Massimo 150 parole per 40 secondi. Chiedi **due versioni**: una da 25 s e una da 45 s, poi scegli in base al ritmo.

### Step 5 — Shot list e testi a schermo (10 min)
Chiedi una tabella tempo / inquadratura / testo / voce. È il documento che usi mentre giri, non il copione da leggere.

### Step 6 — Didascalie (10 min)
Una passata per TikTok (breve, keyword), una per Instagram (più lunga, prima riga forte), una per YouTube (titolo cercabile). Non copiare-incollare la stessa.

### Step 7 — Controllo compliance (10 min)
Usa il prompt P7. Chiede al modello di elencare i claim rischiosi. Poi decidi tu. Il modello non è un avvocato.

### Step 8 — Analisi (10 min)
Incolla numeri e commenti della settimana. Chiedi **tre ipotesi** e un esperimento per ciascuna. Non chiedere "come diventare virale": è una domanda senza risposta.

---

## Prompt pronti

### P1 — Estrattore di fatti
```
Sei un analista che lavora su prodotti bancari. Ti incollo il testo delle istruzioni di una promozione.
Estrai solo i fatti esplicitamente presenti, in una tabella con 3 colonne: Voce | Dato | Citazione esatta.
Se un dato non c'è, scrivi "non presente". Non dedurre, non arrotondare, non aggiungere informazioni esterne.

Testo:
[INCOLLA QUI IL TESTO]
```

### P2 — Generatore di angoli
```
Pubblico: italiani 20-35 anni, interessati a conti correnti e risparmio, diffidenti verso le promo bancarie.
Fatto centrale: [DESCRIVI LA PROMO IN 3 RIGHE, SOLO DATI VERIFICATI].
Genera 10 angoli per video da 30 secondi. Ogni angolo deve essere un'obiezione o un malinteso da correggere, non un invito all'acquisto.
Per ogni angolo: titolo di lavoro, obiezione del pubblico, cosa impara chi guarda.
Evita: "guadagno facile", "soldi gratis", toni da venditore.
```

### P3 — Hook
```
Scrivi 20 hook per un video verticale di 30 secondi sull'angolo: [ANGOLO].
Regole:
- massimo 12 parole
- devono funzionare scritti a schermo, senza audio
- niente domande retoriche generiche ("sapevi che...?")
- niente maiuscole urlate, niente emoji
- devono essere verificabili con il regolamento
Dividi in 3 gruppi: tensione, numero concreto, ammissione di un limite.
```

### P4 — Script in 5 battute
```
Scrivi uno script di 40 secondi (max 150 parole) per TikTok.
Angolo: [ANGOLO]. Hook scelto: [HOOK].
Struttura: 1) hook, 2) promessa di cosa impara, 3) prova o numero, 4) condizione o limite, 5) CTA.
Lingua: italiano parlato, frasi brevi, nessun anglicismo inutile.
Vincoli: non promettere guadagni; cita "10 € di spesa entro 30 giorni" e "fino a 90 giorni lavorativi"; chiudi dicendo che è pubblicità e che ricevi un bonus se usano il codice.
Produci anche una tabella tempo | inquadratura | testo a schermo | voce.
```

### P5 — Adattamento per piattaforma
```
Trasforma questa didascalia in tre versioni.
TikTok: max 500 caratteri, 5-7 hashtag, prima riga = hook, "ADV" all'inizio.
Instagram: max 1.500 caratteri, prima riga forte, blocchi brevi, condizioni in elenco, "ADV — Pubblicità" all'inizio.
YouTube Shorts: titolo max 70 caratteri con la keyword di ricerca, descrizione con le condizioni e il link al regolamento.
Non cambiare i fatti. Non aggiungere cifre.

Didascalia originale:
[INCOLLA]
```

### P6 — Dai commenti ai contenuti
```
Ti incollo 30 commenti ricevuti su video che parlano di un bonus per aprire un conto.
Raggruppa per obiezione ricorrente, conta quante volte appare, e per i 3 gruppi più frequenti proponi un video di 30 secondi che risponda senza difendere la banca.
Per ogni video: hook, risposta in 3 punti, prova da mostrare (documento o schermata), CTA.

Commenti:
[INCOLLA]
```

### P7 — Controllo claim
```
Agisci come revisore pubblicitario. Ti do un testo destinato ai social che promuove un conto corrente con bonus referral.
Elenca ogni frase che:
1) promette un risultato non garantito
2) omette una condizione necessaria
3) può far credere che ci sia un rapporto ufficiale con la banca
4) usa "gratis", "sicuro", "garantito" senza qualificazione
Per ogni frase: problema, riscrittura corretta. Se il testo è conforme, dillo e non inventare problemi.

Testo:
[INCOLLA]
```

### P8 — Riciclo
```
Questo video ha funzionato: [DESCRIVI: hook, argomento, durata, cosa ha prodotto in termini di salvataggi e visite profilo].
Proponi 5 modi di riutilizzare lo stesso contenuto senza ripubblicarlo identico:
- un cambio di formato (carosello, screen recording, whiteboard)
- un cambio di angolo (stessa informazione, obiezione diversa)
- un cambio di pubblico (18-24 vs 25-35)
Per ognuno: hook e prima riga di didascalia.
```

---

## Guardrail: cinque cose che l'AI non deve fare

1. **Inventare cifre o date.** Se il dato non è nel testo che hai incollato, non esiste.
2. **Scrivere recensioni o testimonianze.** Un "utente soddisfatto" generato è pubblicità ingannevole, oltre che volgare.
3. **Clonare la voce di una persona reale.** Il tuo timbro va bene; quello di uno youtuber famoso, no.
4. **Generare volti presentati come clienti veri.** Se usi un avatar, non dire che è una persona che ha ricevuto il bonus.
5. **Pubblicare senza revisione.** Un video automatico che sbaglia una condizione ti costa più di quanto ti fa guadagnare.

---

## Nota su Reddit

r/ItaliaPersonalFinance vieta esplicitamente i **contenuti generati da AI** (regola 7), oltre a referral e pubblicità (regola 4). Non usare output AI, nemmeno rielaborato, per postare lì. È un altro motivo per trattare Reddit come canale di ascolto, non di pubblicazione.

---

## Checklist qualità prima di pubblicare un output AI

- [ ] Ogni numero corrisponde al PDF o alla pagina ufficiale, verificato a mano.
- [ ] Non ci sono frasi della lista vietata (`07-compliance.md`).
- [ ] La disclosure ADV è presente e visibile.
- [ ] Il testo suona come lo diresti tu, non come un comunicato.
- [ ] C'è una condizione esplicita, non solo il beneficio.
- [ ] Se togli il codice, il contenuto resta utile.

Se una voce è "no", non pubblichi. Non si corregge in editing: si riscrive.
