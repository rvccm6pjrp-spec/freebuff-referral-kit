# 15 — Toolkit skill per creare e pubblicare

> Verificato il **13 novembre 2026**. Solo repository vivi (push nelle ultime due settimane) e strumenti con un piano gratuito reale. Le stelle sono indicative al momento della verifica. Obiettivo: produrre contenuti per **Freebuff** (pubblico dev) e **buddybank** (pubblico risparmio) senza volto e senza budget.

---

## 0. Come si installano su Freebuff

Freebuff legge le skill da queste cartelle, in ordine di priorità:

1. `~/.agents/skills/` — globali
2. `~/.claude/skills/` — globali, compatibili Claude
3. `.agents/skills/` — di progetto, **massima priorità**
4. `.claude/skills/` — di progetto

Ogni skill è una cartella con dentro un `SKILL.md`:

```
.agents/skills/mia-skill/SKILL.md
```

Poi diventa un comando `/skill:mia-skill`. Il comando standard per installare è:

```bash
npx skills add <owner/repo> -g
```

Se il CLI non riconosce Freebuff, clona il repo e copia la cartella della skill a mano:

```bash
git clone --depth 1 https://github.com/<owner>/<repo>.git /tmp/skill
mkdir -p ~/.agents/skills
cp -r /tmp/skill/skills/<nome-skill> ~/.agents/skills/
```

**Regola:** installa 5–8 skill, non 106. Ogni skill occupa contesto e l'agente perde precisione. Tieni il resto nel repo e attivale quando servono.

### Stato: installate il 13/11/2026

In `.agents/skills/` ci sono 14 skill, tutte validate (frontmatter corretto, nome cartella = nome skill, nessun symlink):

`brand-profile`, `voice-builder`, `hook-writer`, `tiktok-script`, `reels-script`, `carousel-writer`, `content-calendar`, `cross-platform-repurposing`, `social-seo`, `link-in-bio-and-traffic`, `copywriting`, `social`, `offers`, `launch`.

Riavvia Freebuff perché compaiano i comandi `/skill:<nome>`. `brand-profile` e `voice-builder` vanno compilate per prime: le altre otto le leggono e senza di loro producono hook generici.

---

## 1. Scrivere: i tre pacchetti migliori

| Repo | Stato | Cosa dà | Per cosa usarlo |
|---|---|---|---|
| [social-media-skills/skills](https://github.com/social-media-skills/skills) | MIT, 106 skill | Hook, script TikTok/Reels, caroselli, calendario, repurposing, SEO social, pubblicazione | Il coltellino svizzero. Prendi solo le 8 skill che ti servono |
| [coreyhaines31/marketingskills](https://github.com/coreyhaines31/marketingskills) | ~60k stelle, push 11/11/2026 | Copywriting, social, ad creative, offerta, lancio, PR | Il copy che vende, non solo quello che piace |
| [aaaronmiller/create-viral-content](https://github.com/aaaronmiller/create-viral-content) | v3.0.0, aggiornata 10/11/2026 | Hook, titoli, regole piattaforma, rimozione dei "tell" AI | Far sembrare i testi scritti da una persona |

### Le 8 skill da installare dal primo repo

```bash
npx skills add social-media-skills/skills -g -s hook-writer
npx skills add social-media-skills/skills -g -s tiktok-script
npx skills add social-media-skills/skills -g -s reels-script
npx skills add social-media-skills/skills -g -s carousel-writer
npx skills add social-media-skills/skills -g -s content-calendar
npx skills add social-media-skills/skills -g -s cross-platform-repurposing
npx skills add social-media-skills/skills -g -s social-seo
npx skills add social-media-skills/skills -g -s link-in-bio-and-traffic
```

Per installarle tutte in una volta (sconsigliato, satura il contesto):

```bash
npx skills add social-media-skills/skills -g -s '*' -y
```

### Dal pacchetto marketing

```bash
npx skills add coreyhaines31/marketingskills --skill copywriting social offers launch
```

`offers` è quello che ti serve per buddybank: insegnare all'agente a costruire l'offerta (50 € + 50 €, scadenza, requisiti) senza promesse false. `social` copre la strategia, non la pubblicazione.

---

## 2. Video senza volto: due strade

### A. La più forte: video-shotcraft

[video-shotcraft](https://github.com/Vincentwei1021/video-shotcraft) — ~19k stelle, Apache-2.0, push 11/11/2026.

Non è un generatore di video: disegna ogni frame con Remotion partendo dai tuoi screenshot reali. Gli dici "fai un promo di questa app" e lui:

- cattura le pagine del prodotto,
- sceglie tra 124 schede di shot (camera, transizioni, tipografia, UI, dati),
- monta a tempo di musica,
- esporta un MP4 e un progetto Remotion modificabile,
- opzionalmente esporta una bozza CapCut.

**Perché ti serve:** è esattamente il formato "guarda cosa ho costruito" senza volto, ma con un aspetto da prodotto serio invece del solito screen recording grezzo.

**Limiti da sapere:**
- richiede Node, npm e ffmpeg; il primo render scarica Chrome headless;
- l'output di default è **1920×1080**: per TikTok devi rifare la composition in 9:16, non è un flag;
- la pubblicazione opzionale passa da Upload-Post, un servizio esterno: non serve, carica a mano.

```bash
npx skills add Vincentwei1021/video-shotcraft -g
```

### B. La più leggera: video-agent-skills

[Melvynx/video-agent-skills](https://github.com/Melvynx/video-agent-skills) — repo piccolo (~150 stelle), solo Markdown, gratuito.

Skill per scrivere, ricercare e montare short-form. Non produce il video da solo: ti dà struttura, beat e checklist. Buono se video-shotcraft è troppo pesante per il tuo computer.

### La base gratuita

- **Screen recording:** OBS Studio (gratis) o il registratore di sistema.
- **Montaggio e sottotitoli automatici:** CapCut desktop, piano gratuito.
- **Voiceover:** la tua voce, oppure ElevenLabs free (circa 10 minuti al mese: sufficiente per 15 video da 40 secondi).
- **Caroselli:** Canva free.

---

## 3. Pubblicare: dove si perde tempo e denaro

### La regola d'oro

**Pubblica nativamente.** TikTok ha lo scheduler nel pannello web (fino a 10 giorni avanti). X ha la programmazione nativa nel composer. Zero API, zero audit, zero costi.

### Se vuoi automatizzare: Postiz

[gitroomhq/postiz-app](https://github.com/gitroomhq/postiz-app) — AGPL-3.0, ~35k stelle, sviluppo quotidiano.

- Supporta TikTok (post diretto o upload nella inbox), X, Instagram, YouTube, LinkedIn, Reddit.
- Ha server MCP e CLI: un agente può creare e programmare post.
- Self-host gratuito, ma serve un server (5–10 €/mese) e la tua app developer per ogni piattaforma.

**I due costi nascosti che nessuno dice:**

1. **TikTok richiede una compliance audit** prima che i post di un'app di terze parti siano visibili a tutti. Fino ad allora pubblichi solo per te.
2. **X fa pagare l'API per post:** circa 0,015 $ per un post semplice, **0,20 $ se contiene un link**. Un link costa tredici volte tanto. Con 30 post-link al mese sono 6 $ solo di API.

Conclusione: **per due account e 5 post a settimana, la programmazione nativa è superiore**. Postiz ha senso quando gestisci 4+ piattaforme e 3+ post al giorno, e comunque non per i post con link su X.

| Strumento | Costo | Quando usarlo |
|---|---|---|
| TikTok web + X nativo | 0 € | Sempre, come base |
| Postiz self-host | Server 5–10 €/mese | Da 3 piattaforme in su, post senza link |
| Typefully free | 0 €, 10 post/mese | Solo thread X occasionali |
| Buffer free | 0 €, 3 canali | Alternativa semplice, verifica il supporto X |

---

## 4. YouTube e Reddit: cosa guardare, cosa ignorare

### Tre video recenti che valgono il tempo

1. **Nafay 3D — "How To Make Faceless YouTube Shorts with Claude"** (1 novembre 2026, ~167k view). Mostra una skill gratuita che scrive script, genera visuals, voiceover e sottotitoli sincronizzati, e con Zapier pubblica in automatico. Guardalo per la **struttura della pipeline**, non per il genere: i suoi stili (misteri, scienza) non sono il tuo.
2. **HubSpot / Karl — "I Built an AI Marketing Team With 5 Claude Skills"** (14 settembre 2026). I cinque ruoli: Brand Voice Writer, Social Content Producer, SEO Blog Writer, Email Writer, Reporting Analyst. È il modello giusto per te: **una skill per brand**, non una skill per tutto.
3. **Sabrina Ramonov — "I Made 200 Social Posts in 10 Minutes With Claude + Canva"** e "Connect Claude to Instagram and 9 platforms". Utile per il flusso caroselli + pubblicazione.

### Reddit

Il thread più utile è in **r/FacelessVideos**: "What I learned from over a year of making faceless shorts" (circa 30k follower su TikTok). Il consiglio che conta: **scrivi scena per scena, un beat ogni 3–5 secondi di voce**, con la descrizione visiva accanto. Non un monologo unico.

### L'avvertimento

I video YouTube che offrono "skill gratis" spesso distribuiscono uno ZIP su Google Drive. Non installarlo senza aver letto il `SKILL.md`: una skill può contenere script eseguibili. Preferisci i repo GitHub, che puoi ispezionare prima.

---

## 5. Lo stack consigliato: 3 installazioni, 0 €

```bash
# 1. Scrittura social (8 skill)
npx skills add social-media-skills/skills -g -s hook-writer

# 2. Copy e offerta
npx skills add coreyhaines31/marketingskills --skill copywriting social offers launch

# 3. Video promo (opzionale, richiede Node + ffmpeg)
npx skills add Vincentwei1021/video-shotcraft -g
```

Per buddybank bastano la 1 e la 2. Per Freebuff servono tutte e tre.

---

## 6. Setup in 7 giorni

| Giorno | Cosa fai | Output |
|---|---|---|
| 1 | Installa le skill, crea `.agents/skills/` nel progetto | Comandi `/skill:` attivi |
| 2 | Compila `brand-profile` e `voice-builder` per **due brand separati** | `brand-freebuff.md`, `brand-buddy.md` |
| 3 | 10 hook per Freebuff, 10 per buddybank | Banca hook |
| 4 | 5 script completi per la serie 0/600 | Video pronti da girare |
| 5 | Registra 5 screen recording (fatture, preventivi, menu QR) | Materiale grezzo |
| 6 | Monta con CapCut, sottotitoli bruciati | 5 video finiti |
| 7 | Programma la settimana su TikTok e X nativi | Buffer di 7 giorni |

---

## 7. Regole che valgono più delle skill

- **Due brand, due voci.** Freebuff parla a sviluppatori; buddybank parla a chi vuole 50 €. Non mescolare gli account.
- **La skill scrive, tu giudichi.** Nessuna skill pubblica da sola: la revisione è il tuo vantaggio.
- **Nessun automatismo sui DM.** Le skill di growth che promettono DM automatici violano i termini e bruciano l'account.
- **Disclosure sempre.** Per buddybank "ADV" nei primi secondi; per Freebuff "se passi dal mio link ricevo sessioni extra".
- **Non postare link via API su X.** Costa 0,20 $ per post e riduce la reach: metti il link in bio o nel primo commento.
