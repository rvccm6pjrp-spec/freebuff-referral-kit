# 12 — Naming hype: Soldi HQ

**Verifica handle: 12 novembre 2026.** Da riconfermare al momento della registrazione.

La richiesta era: niente nomi da consulente, più carattere. Ho guardato i pattern usati dai nuovi account finance e AI su Instagram, poi ho verificato quali handle sono davvero liberi su TikTok e X.

---

## Cosa usano oggi i nuovi account

Dai risultati 2026 sul naming Instagram emergono cinque pattern ricorrenti:

1. **Parola singola, minuscola, evocativa.** "Una parola singola sembra premium", ma quasi tutte quelle comuni sono già occupate.
2. **Un solo separatore, meglio il punto.** `nome.qualcosa` è lo standard aesthetic. Ma X e Twitch **rifiutano il punto**: se vuoi lo stesso handle ovunque, il punto è escluso.
3. **Suffissi da brand.** `hq`, `co`, `studio`, `club`, `feed`, `lab`, `files`. Servono a rendere disponibile una parola già presa senza aggiungere numeri.
4. **Nomi composti o inventati.** `economika`, `finvestire`, `talkabout.finance`. Più facili da rendere disponibili, più distintivi.
5. **Slang e ironia.** Nel finance italiano funzionano i nomi che non si prendono sul serio: "MoneyLab", "The Bull", "Mr. Rip". Il tono hype vince sul tono bancario.

Il panorama italiano è diviso tra **brand personali** (Chiara Pieralli, Mr. Rip, Andrea Bertoni, Matteo Napoletano) e **nomi inglesi/descrittivi** (Starting Finance, Io Investo, Finance Playbook, The Bull, MoneyLab). Un ibrido **slang italiano + suffisso da brand** è uno spazio libero.

---

## Perché lo slang puro non funziona

Ho verificato i nomi più naturali. Su X sono tutti già occupati:

| Handle | X | TikTok | Esito |
|---|---|---|---|
| `@euri` | Occupato (account fandom, 834 follower) | — | Scartato |
| `@sghei` | Occupato (0 post, 2 follower) | — | Scartato |
| `@eurotti` | Occupato (0 post) | — | Scartato |
| `@soldoni` | Occupato (26 follower) | — | Scartato |
| `@spiccioli` | Occupato (0 post) | — | Scartato |
| `@conticlub` | Occupato | — | Scartato |
| `@eurihq` | Libero | **Occupato** (profilo privato, 19 follower) | Scartato |
| `@soldios` | Occupato | — | Scartato |

Le parole corte e comuni sono le prime a essere squatting. Non è un problema di creatività: è un problema di disponibilità.

Sui nomi composti con suffisso, invece, le porte sono aperte.

---

## Verifica dei finalisti

| Handle | X | TikTok | Esito |
|---|---|---|---|
| **`@soldihq`** | Libero | Libero | **Usabile** |
| `@soldiclub` | Libero | Libero | Usabile |
| `@sgheihq` | Libero | Da verificare | Opzione regionale |
| `@soldiexe` | Libero | Da verificare | Opzione tech |
| `@soldifeed` | Libero | Da verificare | Opzione editoriale |

"Libero" = pagina profilo pubblica non esistente al momento della verifica. Non è una prenotazione.

---

## Il nome scelto: **Soldi HQ**

**Handle: `@soldihq`** — 7 caratteri, libero su TikTok e X, nessun punto, nessun underscore.

### Perché vince

1. **È hype senza essere cringe.** "HQ" dà l'idea di un quartier generale, di un posto dove le cose vengono decise. Non è l'ennesimo "finanza" o "investo".
2. **È cortissimo.** Sette caratteri: si scrive, si tagga e si ricorda senza sforzo. Nel wordmark diventa un blocco grafico forte.
3. **Tiene l'italiano.** "Soldi" è la parola che usa la gente. "HQ" è il codice visivo internazionale dei brand digitali. Il mix funziona.
4. **Non promette ricchezza.** Non c'è "guadagno", "cash", "rich", "milione". Il nome è cool, non truffaldino. Per un contenuto su bonus bancari è la differenza tra attirare curiosi e attirare cacciatori di soldi facili.
5. **Funziona dopo la promo.** A febbraio puoi continuare con costi, conti, risparmio. "Soldi HQ" non scade il 20 gennaio.
6. **Ha l'handle pulito su entrambe le piattaforme.** È il dato che ha eliminato Euri HQ, che pure era più slang.

### Il contrasto strategico

Nome hype, contenuto sobrio. Il nome ferma lo scroll; il video che dice "50 − 10 = 40" e "fino a 90 giorni lavorativi" costruisce fiducia. È una combinazione più forte di un nome serio con contenuti seri, che nessuno guarda, o di un nome hype con contenuti hype, che nessuno crede.

---

## Setup esatto

### TikTok
| Campo | Valore |
|---|---|
| Nome | `Soldi HQ \| bonus e conti` (24 caratteri) |
| Username | `@soldihq` |
| Bio | `Il quartier generale dei tuoi soldi. Codice in bio: ci guadagno.` |
| Link | pagina ufficiale buddy |

### X
| Campo | Valore |
|---|---|
| Nome | `Soldi HQ` |
| Handle | `@soldihq` |
| Bio | `Il quartier generale dei tuoi soldi. Regolamenti delle banche letti per te, bonus e conti spiegati. Se usi i miei codici ricevo un bonus. ADV.` |
| Location | `Italia` |

### Identità visiva senza volto
- **Wordmark:** `SOLDI HQ` in bianco, sans-serif condensato, tutto maiuscolo, su fondo nero o verde bosco.
- **Dettaglio:** la "Q" con la coda che diventa una freccia verso l'alto, oppure un blocco giallo dietro "HQ". Un solo dettaglio, non tre.
- **Banner X:** `50 − 10 = 40` a sinistra, `Il resto sono chiacchiere` a destra.
- **Non usare:** simboli di euro giganti, salvadanai, grafici azionari, fiamme, emoji di soldi. Sono i cliché che fanno sembrare un account una truffa.

---

## Le alternative, in ordine

**Soldi Club** — `@soldiclub`, libero su entrambi. Più community, più caldo, meno tagliente. "Club" implica appartenenza: ottimo se vuoi costruire una newsletter o un gruppo. Difetto: è un suffisso molto usato e allunga l'handle a 10 caratteri.

**Sghei HQ** — `@sgheihq`, libero su X, TikTok da verificare. Massimo carattere, ma "sghei" è milanese e parte del pubblico nazionale non lo riconosce. Sceglilo solo se il target è Milano o se vuoi un tono da strada.

**Soldi.exe** — `@soldiexe`, libero su X, TikTok da verificare. Molto Gen Z, molto tech. Invecchia più in fretta e può sembrare un account di meme, non di informazioni.

**Soldi Feed** — `@soldifeed`, libero su X. Editorialissimo, ma "feed" è più debole di "HQ" come wordmark.

---

## Se `@soldihq` viene occupato prima che ti registri

In ordine, tutti entro i 15 caratteri di X:

1. `@soldihq_ita` (11)
2. `@soldihqit` (10)
3. `@soldi_hq` (8)

Non cambiare nome per un underscore: cambia solo l'handle. Il nome visualizzato resta "Soldi HQ".

---

## Da non fare

- **Non usare `@euri`, `@sghei`, `@soldoni`**: occupati e, nel caso di "soldoni", con un tono da soldi facili che attira il pubblico sbagliato.
- **Non usare il punto** se vuoi lo stesso handle su X: `soldi.hq` non è valido.
- **Non aggiungere numeri** (`soldihq2026`, `soldihq1`): sembra un account usa e getta.
- **Non cambiare handle dopo due settimane**: perdi la ricerca e la memoria di chi ti segue.
- **Non usare "ufficiale", "real", "official"**: sembra un fan account o un imitatore.
