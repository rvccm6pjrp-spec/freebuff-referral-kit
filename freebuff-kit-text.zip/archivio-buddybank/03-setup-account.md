# 03 — Setup account

Non posso creare l'account al posto tuo: servono il tuo numero, la tua email e la verifica dell'età. Posso però darti i campi esatti da copiare, nell'ordine giusto, con le scelte che ti eviteranno problemi tra tre mesi.

**Tempo necessario: 20 minuti + 7 giorni di warm-up.**

---

## Decisione 1 — Dove aprire

**TikTok + Instagram, stesso handle.** Un solo formato video, due didascalie diverse. TikTok porta reach fredda, Instagram porta il pubblico 25–35 che apre davvero il conto.

**Inforge:** un thread nella sezione "Guadagnare con Promozioni", con account personale. Non è un social: è un forum con intento d'acquisto altissimo.

**Reddit:** nessun account brand. Se ce l'hai già, usalo per leggere e rispondere senza link.

**Discord/Telegram:** solo dopo, e solo dove esiste un canale dedicato.

---

## Decisione 2 — Il nome

### Criteri
- Non deve contenere **buddybank**, **UniCredit**, **buddy** o varianti: è marchio altrui e sembra un account ufficiale.
- Non deve contenere **"bonus50"**, **"guadagnafacile"**, **"soldifacili"**: attira la persona sbagliata e invecchia male.
- Deve funzionare **dopo gennaio 2027**, quando la promo finisce.
- Deve essere pronunciabile al telefono e cercabile senza errori.
- Deve stare in 24 caratteri (limite TikTok) e in 30 (Instagram).

### Le tre opzioni, in ordine di preferenza

| Nome | Handle base | Pro | Contro |
|---|---|---|---|
| **Due Conti** | `@dueconti` | Doppio senso perfetto ("farsi due conti" / due conti correnti), breve, non urlato, sopravvive alla promo | Probabile che la base sia occupata: serve un suffisso |
| **Conto Chiaro** | `@contochiaro` | Dice esattamente il posizionamento: chiarezza sui conti | Meno memorabile, più "servizio" |
| **Soldi Chiari** | `@soldichiari` | Più ampio, permette di parlare di risparmio e non solo di banche | Più generico, molta concorrenza |

**Consiglio: Due Conti.** Se la base è occupata, in ordine di preferenza:
`@dueconti.ita` → `@dueconti_ita` → `@dueconti.it` → `@imparaidueconti` → `@duecontisoldi`

**Nome visualizzato (display name), 30 caratteri:**
> `Due Conti | conti e bonus spiegati`

Contiene le keyword che la gente cerca ("conti", "bonus") senza sembrare spam. Su TikTok il nome visualizzato è indicizzato nella ricerca: vale più dell'handle.

**Da evitare assolutamente:** `@buddybank_bonus`, `@unicredit_promo`, `@bonus50euro`, `@referral_italia`, nomi con emoji, nomi che iniziano con "Il/La" e sembrano una testata giornalistica.

---

## Decisione 3 — Foto e identità visiva

- **Foto profilo:** il tuo volto, mezzo busto, sfondo neutro, luce naturale. Non un logo. Non un'immagine stock. Non l'icona della banca.
- **Perché:** nel contenuto finanziario la faccia è l'unico segnale di responsabilità. Un logo anonimo che parla di soldi viene letto come truffa.
- **Colore:** uno solo, usato in tutti i testi a schermo. Consiglio un blu scuro o un verde bosco, non il rosso (urla "offerta").
- **Font:** uno solo, leggibile su mobile, con contorno nero o fondo semi-trasparente.

---

## Setup TikTok — campi esatti

1. **Crea l'account** con email dedicata (non quella personale piena di notifiche). Meglio una nuova Gmail tipo `dueconti.campagna@gmail.com`.
2. **Nome visualizzato:** `Due Conti | conti e bonus spiegati`
3. **Username:** vedi sopra.
4. **Bio (max 80 caratteri):**
   > `Conti e bonus, regolamento alla mano. Codice in bio: ne guadagno anch'io.`
   (78 caratteri. Dice tutto: cosa fai, dove sta il codice, che ci guadagni.)
5. **Link:** la pagina ufficiale della promo. **Non** un link shortener, **non** un sito tuo che raccoglie email.
6. **Impostazioni:**
   - Attiva la verifica in due passaggi.
   - Imposta la lingua italiana e la regione Italia.
   - Non attivare i regali/gift se non vuoi complicazioni fiscali.
7. **Prima di pubblicare:** guarda 20 minuti al giorno di contenuti su conti correnti e risparmio, salva 10 video, commenta 5 volte in modo utile. Per 7 giorni. Serve a far capire all'algoritmo di cosa parli, e a te a capire il linguaggio del niche.

---

## Setup Instagram — campi esatti

1. **Converti in account professionale → "Creator"** (non "Business": il Creator ha accesso ai trend audio e agli insight che ti servono).
2. **Nome (30 caratteri):** `Due Conti | conti e bonus`
3. **Username:** lo stesso di TikTok.
4. **Bio (max 150 caratteri), con a capo:**
   > `Conti e bonus spiegati con il regolamento alla mano.`
   > `Non lavoro per le banche. Se usi i miei codici, a volte guadagno.`
   > `ADV quando promuovo.`
   (Circa 140 caratteri. La seconda riga è la disclosure più importante che puoi scrivere.)
5. **Link:** pagina ufficiale della promo.
6. **Highlight:** tre, con copertine dello stesso colore:
   - `Bonus` → cos'è, quanto vale, chi è escluso
   - `Come si fa` → tutorial inserimento codice
   - `Domande` → risposte alle obiezioni frequenti
7. **Primo contenuto da fissare:** il video "Sì, se usi il mio codice io ricevo 50 €" (script 8). Va in alto, non in fondo.

---

## Il codice: dove metterlo senza sembrare spam

Non esiste un link referral: il codice si inserisce a mano durante l'apertura. Quindi:

- **In bio:** `Codice: [INSERIRE CODICE]` su una riga separata. È il posto che la gente cerca.
- **Nel commento fissato di ogni video:** codice + tre condizioni in due righe.
- **Nella didascalia:** solo nei video tutorial, non in tutti (altrimenti sembra un volantino).
- **Nel video:** puoi mostrarlo a schermo negli ultimi 3 secondi, mai come primo frame.

**Non scrivere il codice in maiuscolo gigante, non ripeterlo tre volte, non metterlo nell'handle.** Sono tutti segnali che abbassano la fiducia e aumentano il rischio di rimozione.

---

## Warm-up: i primi 7 giorni

| Giorno | Cosa fare | Cosa NON fare |
|---|---|---|
| 1–2 | Consuma contenuti del niche, salva, osserva i commenti | Pubblicare |
| 3–4 | Commenta 5 video al giorno con qualcosa di utile (non "bel video") | Mettere il codice nei commenti altrui |
| 5 | Gira 3 video di prova, guardali senza pubblicarli | Pubblicare il primo video "a caso" |
| 6 | Pubblica il video 8 (trasparenza), senza CTA aggressiva | Chiedere follow |
| 7 | Pubblica il video 1 (il bonus non è un guadagno) | Postare 4 video in un giorno |

Il primo video deve essere **il più utile**, non il più promozionale. È quello che l'algoritmo userà per capire a chi mostrarti.

---

## Inforge — account e thread

- Serve un account attivo, non nuovo di zecca. La sezione "Guadagnare senza Investimento" richiede almeno **Utente Bronze** o Access Pass: verifica i requisiti prima di scrivere.
- Leggi il **Regolamento Money Area** e la discussione ufficiale sulle modifiche al regolamento: è la fonte delle regole di sezione.
- Il thread va nel formato usato dalla sezione: bonus promozione, bonus aggiuntivo, data di scadenza, numero massimo inviti, link al regolamento.
- **Non** offrire bonus extra tuoi. È la pratica più diffusa lì, ed è esattamente quella che ti espone.
- Un solo thread. Niente bump ossessivi. Rispondi alle domande e aggiorna il titolo quando la promo cambia.

Template completo in `05-copy-social.md`.

---

## Reddit — se vuoi usarlo

- **Non** creare un account con il nome del progetto.
- **Non** inserire link o codici, nemmeno nei commenti.
- Usa un account personale, con storico, che partecipi da almeno 30 giorni.
- Le regole del sub italiano vietano pubblicità, referral e contenuti AI. Rispettale alla lettera.

A cosa serve allora: a leggere le obiezioni reali ("mi hanno bloccato il conto", "il bonus non arriva", "conviene davvero?") e trasformarle in video. È ricerca utente gratuita, non distribuzione.

---

## Tabella di controllo

| Elemento | Pronto quando... |
|---|---|
| Nome | Non contiene marchi altrui e si capisce cosa fai |
| Handle | Stesso su TikTok e Instagram, senza numeri casuali |
| Bio | Dice cosa fai, dove sta il codice, che ci guadagni |
| Foto | È una persona riconoscibile, non un logo |
| Link | Porta alla pagina ufficiale, non a un raccoglitore di dati |
| Disclosure | È scritta in bio **e** nei video **e** nelle didascalie |
| Warm-up | Hai passato 7 giorni a consumare e commentare, non solo a pubblicare |
| Video fissato | Il primo pinned è la trasparenza sul guadagno |

---

## Quello che NON devi fare con l'account

- Non comprare follower o like: il rapporto views/follower crolla e il profilo muore.
- Non cambiare handle dopo 2 settimane: perdi la ricerca e la memoria di chi ti segue.
- Non cancellare i commenti critici (a meno che siano offensivi): rispondi con i fatti, sono proof.
- Non pubblicare lo stesso video su 5 piattaforme lo stesso minuto: adatta la didascalia.
- Non usare un nickname che sembra un consulente finanziario se non lo sei.
