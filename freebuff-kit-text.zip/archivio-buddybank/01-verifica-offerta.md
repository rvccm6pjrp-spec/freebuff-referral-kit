# 01 — Verifica dell'offerta

**Data di verifica: 12 novembre 2026.**
Fonti primarie:
- Pagina ufficiale: https://www.buddy.unicredit.it/promo-e-vantaggi/promo-bonus-5050/ (oggi apre "buddy Club 100")
- Istruzioni PDF: https://www.unicredit.it/content/dam/ucpublic/it/footer/doc/Manifestazioni%20a%20premio/MGM_buddy_club_100-new.pdf

> Nota metodologica: dove la pagina web e il PDF dicono cose diverse, ho segnato la differenza. Per i contenuti pubblici vale il PDF, tranne per il bonus extra da 30 € che esiste solo in pagina.

---

## Scheda verificata

| Voce | Dato | Fonte |
|---|---|---|
| Nome iniziativa | "buddy Club 100" | Pagina + PDF |
| Bonus invitato | **50 € netti** | PDF §6.1 a |
| Bonus invitante | **50 € netti** per amico | PDF §6.1 b |
| Bonus extra invitato | **+30 €**, totale **80 €**, accredito separato | Solo pagina web |
| Finestra bonus extra | Diventi cliente dal 04/09/26 al 04/10/26, **prorogato fino al 16/11/26** | Solo pagina web |
| Netto / lordo | I 50 € sono **già netti**: ritenuta fiscale 26% applicata | PDF §6.3 |
| Requisito di spesa | Una o più transazioni per **almeno 10 € complessivi** | PDF §5.2 b II |
| Tempo per la spesa | Entro **30 giorni di calendario** dall'apertura (o dall'emissione carta) | PDF §5.2 b II |
| Metodi validi | POS fisico, POS virtuale/e-commerce, wallet Apple Pay / Google Pay / Samsung Pay | PDF §5.2 b III |
| Metodi NON validi | Bonifici, giroconti, ricariche verso carte prepagate | PDF §5.2 b III |
| Prodotto | Genius buddy, Genius Care buddy, Genius Care Top buddy, carta Genius Pay (**esclusa versione minori**) | PDF §3, §4.2 |
| Come si apre | Dal sito buddy.unicredit.it o dall'app, **prima volta**, inserendo il codice durante la richiesta | PDF §5.2 b I |
| Dove si trova il codice | App buddy UniCredit, sezione "iniziative e promo" | PDF §5.1 |
| Condizione sul codice | La pagina indica: visibile solo ai clienti con **saldo contabile ≥ 0** | Pagina web |
| Età / residenza | **18+**, residenti in Italia | PDF §4.1–4.2 |
| Esclusi come invitati | Chi ha avuto rapporti con la banca **dal 01/01/2020** in poi | PDF §4.4 |
| Esclusi del tutto | Dipendenti in servizio del Gruppo UniCredit | PDF §4.5 |
| Massimo inviti | **100** per invitante = **5.000 €** | PDF §6.1 b |
| Accredito | Entro **90 giorni lavorativi** dalla transazione | PDF §6.2 |
| Condizione mantenimento | Conto/carta **aperto e non bloccato** alla data dell'accredito | PDF §6.2 |
| Periodo | **20/01/2026 – 20/01/2027** | PDF §1 |
| Codice disponibile fino a | **3 giorni prima della fine** (quindi 17/01/2027) | PDF §5.1 |
| Cumulabilità | Con altre iniziative in corso | PDF §11 |
| Costi dichiarati | Canone 0 €; carta digitale 0 € di emissione; carta fisica 3,50 € emissione + 5,70 € spedizione ordinaria; prelievi ATM UniCredit 0 €; bonifici SEPA online 0 € | Pagina web |

---

## Le tre cose che quasi nessuno dice (e che sono il tuo vantaggio)

1. **Il bonus è al netto, non al lordo.** I 50 € sono già tassati. Chi scrive "50 € lordi" sbaglia. Chi scrive "67 € di bonus" inventa.
2. **10 € non sono un deposito, sono spesa reale.** Non bastano bonifici o ricariche: serve un pagamento con carta. È il punto in cui si perde più bonus.
3. **"Fino a 5.000 €" è il tetto teorico, non un risultato.** Servono 100 amici che aprono e spendono. Raccontarlo come "guadagno" è la scorciatoia che distrugge la credibilità.

---

## Punti da confermare prima di promettere l'80 €

Il bonus extra da 30 € **non compare nelle Istruzioni PDF**. Compare solo nella pagina web. Prima di fare contenuti che promettono 80 €:

- [ ] Apri la chat in app buddy e chiedi per iscritto: "Il bonus aggiuntivo di 30 € per l'invitato è valido per chi apre entro il 16/11/2026? La spesa di 10 € può avvenire nei 30 giorni successivi?"
- [ ] Salva screenshot della risposta e della pagina con la data visibile.
- [ ] Se la risposta è ambigua, pubblica solo il dato dei 50 €, che è nel regolamento.

Lo stesso vale per la frase "saldo contabile ≥ 0": serve a te per vedere il codice, non è una condizione per il bonus dell'amico. Non confonderle nei contenuti.

---

## Cosa c'è di sbagliato online (materiale per contenuti)

Cercando la promo si trovano informazioni vecchie o imprecise. Sono un'ottima fonte di video "correggo le bufale", ma vanno verificate una per una:

| Affermazione trovata online | Cosa dice la fonte ufficiale |
|---|---|
| "Devi spendere entro il 29° giorno" | Il PDF dice **30 giorni di calendario** |
| "Serve una sola transazione da 10 €" | Il PDF dice **una o più transazioni** per almeno 10 € complessivi |
| "Bonus 40 €" / "fino a 240 €" | Importi di campagne precedenti, non di questa |
| "Puoi invitare 30 amici" | Il limite attuale è **100** |
| "Il bonus arriva in 15 giorni" | Il PDF dice **entro 90 giorni lavorativi** |
| "Apri con SPID e sei a posto" | Non è una condizione del bonus; non aggiungerla e non consigliarla come scorciatoia |

Non copiare questi errori: correggerli è già un format.

---

## Checklist di ri-verifica (5 minuti, prima di ogni batch)

Le promo cambiano. Prima di girare un blocco di video:

- [ ] La pagina ufficiale esiste ancora e l'importo è lo stesso?
- [ ] La finestra del bonus extra è ancora aperta? Se no, elimina ogni riferimento a 80 €.
- [ ] La data di fine è ancora 20/01/2027?
- [ ] I requisiti (10 €, 30 giorni, metodi validi) sono gli stessi?
- [ ] Le esclusioni (già clienti dal 2020, dipendenti) sono le stesse?
- [ ] Il tuo codice è ancora visibile in app e il saldo è ≥ 0?

Se una risposta è "no", aggiorna i file e **non** ripubblicare i contenuti vecchi.

---

## Come citare la fonte nei contenuti

Formula breve, corretta e verificabile:

> "Condizioni: iniziativa buddy Club 100, valida fino al 20/01/2027. Bonus 50 € netti per invitato e invitante; serve apertura con codice e almeno 10 € di spesa con carta entro 30 giorni. Accredito fino a 90 giorni lavorativi. Esclusi i già clienti UniCredit/buddy dal 2020. Regolamento su buddy.unicredit.it."

Questa frase è lunga per un video, ma va messa **per intero in descrizione o nel commento fissato**. Nel video puoi dire la versione da 8 secondi e rimandare al commento.
