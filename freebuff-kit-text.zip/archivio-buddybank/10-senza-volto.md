# 10 — Campagna senza volto, senza video

Se non vuoi apparire (e non vuoi girare), questa è la strada. Nessun volto, nessuna voce se non la vuoi, nessun set. Solo schermate, testo, immagini e post scritti.

**Il formato numero uno per questa offerta è il carosello foto di TikTok.** È nativo, non richiede montaggio, si salva molto e si legge due volte. Si fa in 30 minuti con Canva gratis.

---

## I 6 formati, in ordine di efficacia

| # | Formato | Dove | Tempo | Reach | Conversione | Appare qualcuno? |
|---|---|---|---|---|---|---|
| 1 | **Carosello foto** (6–8 slide) | TikTok, Instagram | 30 min | Alta | Media | No |
| 2 | **Screen recording + voce sintetica** | TikTok, Reels | 40 min | Media-alta | Alta | No |
| 3 | **Mani + regolamento evidenziato** | TikTok, Reels | 20 min | Media | Alta | Solo mani |
| 4 | **Thread X + card numerica** | X | 15 min | Media | Media | No |
| 5 | **Thread forum / gruppi** | Inforge, Facebook, Telegram | 20 min | Bassa | Molto alta | No |
| 6 | **Commenti utili** | TikTok, Reddit, YouTube | 15 min/giorno | Bassa | Media | No |

**Da evitare:** avatar AI che parla in camera, voci clonate, testimonianze generate. In un contenuto su una banca sembrano truffa e ti fanno perdere più di quanto ti danno.

---

## 1. Carosello TikTok — "80 € in 6 schermate"

Formato: 1080×1920, fondo scuro, testo bianco, un concetto per slide, massimo 2 righe. Musica lo-fi a volume basso. TikTok → "Carica" → "Foto" → seleziona le slide → 7 secondi ciascuna.

### Slide 1 (copertina)
> **80 € PER APRIRE UN CONTO**
> Fino a lunedì 16/11.
> *Scorri →*
> `ADV` in alto a sinistra, piccolo ma leggibile.

### Slide 2
> **COS'È**
> Bonus buddybank per chi apre un conto o una carta con un codice invito.
> 50 € + 30 € extra per l'invitato.

### Slide 3
> **COSA DEVI FARE**
> 1. Apri con il codice, durante la richiesta.
> 2. Spendi almeno 10 € con la carta entro 30 giorni.

### Slide 4
> **COSA NON VALE**
> Bonifici.
> Giroconti.
> Ricariche verso carte.
> Solo pagamenti con carta, fisica o wallet.

### Slide 5
> **CHI È ESCLUSO**
> Già cliente UniCredit o buddy dal 2020.
> Under 18.
> Non residenti in Italia.

### Slide 6
> **QUANDO ARRIVANO**
> Entro 90 giorni lavorativi.
> Non sono immediati.

### Slide 7
> **TRASPARENZA**
> Se usi il mio codice ricevo 50 €.
> Non lavoro per la banca.
> Condizioni sul sito ufficiale.

### Slide 8 (CTA)
> **CODICE IN BIO**
> Prima di usarlo, leggi la slide 3.
> Salva il post.

**Didascalia:**
```
ADV | 80€ per chi apre un conto buddybank entro lunedì 16/11.

50€ + 30€ extra per l'invitato. Serve: apertura con codice + 10€ di spesa con carta entro 30 giorni. Accredito fino a 90 giorni lavorativi. Esclusi i già clienti UniCredit/buddy dal 2020.

Codice in bio. Se lo usi ricevo 50€.
#adv #buddybank #bonus #contocorrente #soldi
```

### Variante B — "Quanto costa davvero"
6 slide: "Il canone è 0 €. La carta no." → 3,50 € emissione + 5,70 € spedizione → digitale 0 € → "Il bonus è 50 € netti" → "10 € di spesa" → "Se apri solo per il bonus, fai due conti". Utile anche a chi non usa il codice.

### Variante C — "Chi non può partecipare"
5 slide sulle esclusioni. È il carosello che genera condivisioni e commenti "io sono escluso". Meno conversione, più reach.

---

## 2. Screen recording + voce sintetica

Nessun volto. Registri lo schermo del telefono mentre fai il percorso, aggiungi testo e una voce TTS (TikTok o CapCut). 25–35 secondi.

**Script "Dove si mette il codice":**
1. **0–2 s** — Home del sito. Testo: **"QUI SI PERDE IL BONUS"**. TTS: "Uno dei motivi più comuni per cui il bonus non arriva è questo."
2. **2–8 s** — Tap su "Apri il conto". Testo: **"1. APRI"**. TTS: "Apri dal sito o dall'app, non da un link che ti manda un amico: non esiste."
3. **8–18 s** — Compilazione, zoom sul campo codice. Testo: **"2. CERCA IL CAMPO"**. TTS: "Durante la richiesta c'è un campo per il codice. Se non lo vedi, fermati e apri la chat."
4. **18–25 s** — Incolla il codice. Testo: **"3. INCOLLA"**. TTS: "Incolla, non riscrivere. Controlla che non ci siano spazi."
5. **25–32 s** — Testo: **"POI 10 € CON CARTA / 30 GIORNI"**. TTS: "Poi hai 30 giorni per spendere 10 euro con la carta. Codice nel commento fissato. Se lo usi ricevo 50."

**Script "Il bonus non è un guadagno":** screen recording di un foglio di calcolo con 50 − 10 = 40, poi 90 giorni. TTS sopra. 25 secondi. Nessun volto.

**Come registrare:** iOS → Centro di controllo → Registrazione schermo. Android → utility del produttore o app gratuita. Registra in verticale, oscura i dati personali con un rettangolo nero.

---

## 3. Mani + regolamento evidenziato

Il formato più credibile che esista senza volto. Stampi le istruzioni (o le apri su tablet), evidenzi la clausola con un pennarello, la tocchi con il dito.

**Script 20 secondi:**
- **0–2 s** — Foglio sul tavolo, penna che cerchia "50 €". Testo: **"C'È SCRITTO QUI."**
- **2–9 s** — Evidenzi "una o più transazioni... almeno 10 €". Testo: **"10 € CON CARTA. NON BONIFICI."**
- **9–15 s** — Evidenzi "entro 30 giorni di calendario". Testo: **"30 GIORNI, NON 90."**
- **15–20 s** — Giri il foglio. Testo: **"80 € FINO AL 16/11. CODICE IN BIO."**

Solo mani, tavolo, luce finestra. Costo: un pennarello e due fogli.

---

## 4. X: thread e post senza video

X è testo: è il canale perfetto per chi non vuole apparire.

### Thread 1 — "Chi ti manda il codice"
```
Se ti hanno mandato un codice buddybank, chi te lo manda prende 50€.

Tu, fino a lunedì 16/11, puoi prenderne 80.

Ho letto il regolamento: 4 cose che la home non mette in evidenza. 🧵
```
Poi:
```
1. Gli 80€ sono 50 + 30. Il bonus extra spetta solo all'invitato. Chi invita riceve 50€ per amico.
```
```
2. Servono almeno 10€ di spesa con la carta entro 30 giorni. Bonifici e ricariche non contano.
```
```
3. Chi è già cliente UniCredit o buddy dal 2020 è escluso. Non dipende dal codice.
```
```
4. L'accredito arriva entro 90 giorni lavorativi. Non è immediato.
```
```
Come si fa: apri dal sito o dall'app, inserisci il codice durante la richiesta, spendi 10€ con carta entro 30 giorni.

Codice: [INSERIRE CODICE]
Se lo usi ricevo 50€. ADV.
Regolamento: buddy.unicredit.it
```

### Post singoli (uno al giorno, non tutti insieme)
1. `80€ per aprire un conto, fino a lunedì. Ma 10€ li devi spendere. Il netto reale è 70, non 80.`
2. `"Bonus garantito" non esiste. Esiste "bonus condizionato a tre requisiti". Se te lo vendono come garantito, scappa.`
3. `La carta fisica di buddybank: 3,50€ di emissione + 5,70€ di spedizione. Quella digitale: 0€. Se non ti serve il plastico, risparmi 9,20€.`
4. `Se sei già cliente UniCredit dal 2020, il bonus referral non lo prendi. Non è il codice sbagliato: sei escluso tu.`
5. `Quanto ci vuole per avere 50€ da un referral bancario? Fino a 90 giorni lavorativi. Quasi quattro mesi. Se hai fretta, non è lo strumento.`

**Immagine per X:** card 1200×675 con quattro numeri — **80 / 10 / 30 / 90** — e sotto "bonus · spesa · giorni · accredito". Canva gratis. Stesso font e colore del profilo.

---

## 5. Community: dove il testo basta

### Inforge — "Guadagnare con Promozioni"
Il template completo è in `05-copy-social.md`. È il canale con la conversione più alta perché chi legge è già intenzionato. Un thread, non cinque. Nessun bonus extra offerto da te.

### Facebook — gruppi offerte e codici
Chiedi prima all'admin. Post breve, con l'immagine dei quattro numeri:
```
ADV | buddybank: 80€ per chi apre entro il 16/11 (50 + 30 extra).

Serve: apertura con codice + almeno 10€ di spesa con carta entro 30 giorni. Accredito fino a 90 giorni lavorativi. Esclusi i già clienti UniCredit/buddy dal 2020.

Codice: [INSERIRE CODICE]
Se lo usi ricevo 50€. Regolamento: buddy.unicredit.it
```

### Telegram
Solo canali esistenti, mai DM a freddo. Messaggio da 6 righe, codice, condizioni, link. Se non hai un canale, non aprirlo per 50 €: non ha senso.

---

## 6. Commenti: distribuzione gratuita

15 minuti al giorno, senza pubblicare nulla.

**Dove:** video TikTok e Reel che parlano di conti correnti, bonus, "migliori banche", stipendio, prima casa. Anche thread X e Reddit.

**Cosa scrivere:** una correzione utile o un dettaglio che manca. Mai il codice, mai il link, mai "scrivimi".

Esempi:
- "Occhio che sul bonus buddybank i bonifici non contano: serve spesa con carta."
- "Il bonus è riservato a chi non è già cliente dal 2020, se lo sei non lo prendi."
- "L'accredito è fino a 90 giorni lavorativi, non arriva in una settimana."
- "La carta fisica ha 3,50 € + 5,70 € di costi: la digitale è gratis."
- "Se apri solo per il bonus, metti in conto 10 € di spesa: il netto è più basso."

**Regola:** un commento ogni 10 video guardati. Chi commenta "codice?" sotto un video altrui sta facendo spam, non marketing.

---

## Piano 7 giorni, zero riprese

| Giorno | Cosa pubblichi | Tempo |
|---|---|---|
| **Gio 12** | Carosello "80 € in 6 schermate" su TikTok + Instagram | 45 min |
| **Ven 13** | Thread X + card numerica | 20 min |
| **Sab 14** | Screen recording "dove si mette il codice" con TTS | 40 min |
| **Dom 15** | Carosello variante "chi non può partecipare" | 30 min |
| **Lun 16** | Post "ultimo giorno per gli 80 €" + storia | 15 min |
| **Mar 17** | Aggiorna tutto a 50 €, thread "cosa resta" | 20 min |
| **Ogni giorno** | 5 commenti utili su contenuti altrui | 15 min |

**Kit visivo:** un fondo, un colore, un font. Se cambi stile ogni giorno non ti riconoscono. Canva → crea un template → duplicalo.

---

## Cosa NON fare senza volto

- **Avatar AI che parla.** In finanza sembra una truffa, e le piattaforme limitano i contenuti finanziari sintetici.
- **Voci clonate.** Il tuo timbro va bene, quello di un creator famoso no.
- **Finte chat con la banca.** Non inventare screenshot di assistenza o di accrediti.
- **Testimonianze generate.** "Giulia, 24 anni, ha ricevuto 80 €" con un volto AI è pubblicità ingannevole.
- **Caroselli con 12 slide.** Nessuno arriva in fondo. Massimo 8.
- **Lo stesso carosello su 5 gruppi lo stesso giorno.** Ti bannano prima di convertire.

---

## Checklist prima di pubblicare

- [ ] "ADV" sulla prima slide e a inizio didascalia.
- [ ] "Fino a 80 €", non "80 € garantiti".
- [ ] È chiaro che gli 80 € sono dell'invitato e che tu ricevi 50 €.
- [ ] Ci sono le tre condizioni: apertura con codice, 10 € con carta, 30 giorni.
- [ ] C'è la frase sui 90 giorni lavorativi.
- [ ] C'è l'esclusione dei già clienti dal 2020.
- [ ] Il codice è quello giusto.
- [ ] Dopo il 16/11, ogni slide con "80" viene aggiornata a "50".
