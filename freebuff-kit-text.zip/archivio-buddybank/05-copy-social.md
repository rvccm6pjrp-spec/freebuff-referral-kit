# 05 — Copy per piattaforma

Tutto il testo è pronto. Sostituisci `[INSERIRE CODICE]` e pubblica.

**Regola:** la disclosure "ADV" va all'inizio della didascalia, non in fondo. Su TikTok e Instagram è la prima cosa che deve essere visibile.

---

## TikTok — didascalie

### Video 1 — Il bonus non è un guadagno
```
ADV | Il bonus da 50€ non è un guadagno: è un rimborso condizionato.

Devi spendere almeno 10€ con la carta entro 30 giorni. L'accredito arriva fino a 90 giorni lavorativi. Se sei già cliente UniCredit o buddy dal 2020, sei escluso.

Codice in bio. Se lo usi io ricevo 50€: te lo dico per trasparenza.

#adv #buddybank #bonuscontocorrente #contocorrente #finanzapersonale #risparmio
```

### Video 2 — Ho letto il regolamento
```
ADV | Tre cose che la pagina della promo non mette in prima pagina.

1. Chi è già cliente UniCredit/buddy dal 2020 è escluso.
2. Bonifici e ricariche non valgono: serve un pagamento con carta.
3. Il codice si inserisce solo durante l'apertura, non dopo.

Bonus 50€ netti, spesa minima 10€ entro 30 giorni, accredito fino a 90 giorni lavorativi. Regolamento su buddy.unicredit.it

#adv #buddybank #contocorrente #bonus #finanzapersonale
```

### Video 3 — Tutorial codice
```
ADV | Dove si inserisce il codice, passo per passo.

Il campo "codice invito" compare durante la richiesta di apertura. Se non lo vedi, fermati e apri la chat: dopo l'apertura non si può più inserire.

Poi hai 30 giorni per spendere almeno 10€ con la carta.

Codice nel commento fissato. Se lo usi ricevo 50€.
#adv #buddybank #tutorial #contocorrente #bonus
```

### Video 4 — Dieci euro
```
ADV | Il requisito è 10€ in totale, non 10€ al giorno.

Una o più transazioni con carta per almeno 10€ complessivi, entro 30 giorni dall'apertura. Bonifici e ricariche non contano.

Salva il video, serve prima di aprire.
#adv #buddybank #bonus #contocorrente #risparmio
```

### Video 7 — Quando non conviene
```
ADV | Ti dico quando NON conviene, anche se ci guadagno se usi il mio codice.

Non conviene se sei già cliente UniCredit/buddy, se ti serve una filiale fisica, se cerchi un conto titoli, se ti servono i 50€ subito.

Conviene se sei senza conto o paghi un canone e usi la carta ogni mese.

Non è un consiglio finanziario personalizzato.
#adv #buddybank #contocorrente #finanzapersonale
```

### Video 8 — Trasparenza (fissato)
```
ADV | Sì: se usi il mio codice io ricevo 50€. Te lo dico prima.

Tu prendi 50€ netti se apri il conto e spendi almeno 10€ con la carta entro 30 giorni. Io prendo 50€ quando tu rispetti quelle condizioni. A te non costa nulla in più.

Non lavoro per buddybank, non sono UniCredit. Sono un cliente che ha letto il regolamento.

Regolamento: buddy.unicredit.it
#adv #buddybank #trasparenza #contocorrente
```

**Hashtag:** usa 5–7, non 20. Mix: 2 ampi (#finanzapersonale, #risparmio), 2 specifici (#buddybank, #bonuscontocorrente), 1 identitario (#dueconti). Non usare hashtag di truffe o di guadagno facile.

---

## Instagram Reels — didascalie

Instagram premia il testo lungo **solo se la prima riga ferma lo scroll**. La prima riga deve essere l'hook, non "Ciao a tutti".

### Reel 1
```
ADV — Il bonus da 50€ non è un guadagno. È un rimborso condizionato.

Per prenderlo devi aprire un conto e spendere almeno 10€ con la carta entro 30 giorni. Se quei 10€ li avresti spesi comunque, il bonus vale 50. Se compri solo per il bonus, ne valgono 40.

E l'accredito arriva fino a 90 giorni lavorativi: quasi quattro mesi.

Le condizioni in breve:
• 18+ e residenti in Italia
• non già clienti UniCredit/buddy dal 2020
• apertura con codice invito
• spesa ≥ 10€ con carta entro 30 giorni
• accredito fino a 90 giorni lavorativi
• massimo 100 inviti

Se ti serve un conto nuovo, è un buon motivo. Se stai aprendo un conto solo per i 50€, fai due conti prima.

Trasparenza: se usi il mio codice ricevo 50€. Non lavoro per la banca.
Regolamento: buddy.unicredit.it

#adv #pubblicità #buddybank #contocorrente #finanzapersonale #risparmio
```

### Reel 7
```
ADV — Ti dico quando NON conviene aprire questo conto, anche se ci guadagno qualcosa se usi il mio codice.

Non conviene se:
• sei già cliente UniCredit o buddy (sei escluso)
• ti serve una filiale fisica
• cerchi un conto per investire (questo è un conto corrente)
• hai bisogno dei 50€ subito

Conviene se:
• sei senza conto o paghi un canone
• usi la carta ogni mese
• ti va bene gestire tutto da app

Non è un consiglio finanziario personalizzato: è il regolamento letto ad alta voce.

Codice in bio, con tutte le condizioni.
#adv #buddybank #contocorrente #finanzapersonale
```

### Reel 3 — Tutorial
```
ADV — Il passaggio in cui si perde più bonus: il codice invito.

Va inserito durante la richiesta di apertura, non dopo. Se non vedi il campo, fermati e apri la chat.

Poi: 10€ di spesa con carta entro 30 giorni. Bonifici e ricariche non contano.

Codice nel commento fissato. Se lo usi ricevo 50€.
#adv #buddybank #tutorial #contocorrente
```

---

## Carosello Instagram — "Il bonus in 8 slide"

**Slide 1 (copertina)**
> **50 € per te, 50 € a chi ti invita.**
> Ma non è per tutti.
> *Scorri →*

**Slide 2**
> **Cos'è**
> La promo "buddy Club 100" di buddybank (UniCredit).
> Apri un conto Genius buddy o una carta Genius Pay inserendo un codice invito.

**Slide 3**
> **Quanto vale**
> 50 € netti all'invitato.
> 50 € netti all'invitante.
> (Solo se pubblichi entro il 16/11: l'invitato può ricevere 30 € in più, totale 80 €. Dopo quella data, elimina questa riga.)

**Slide 4**
> **Cosa devi fare**
> 1. Apri il conto con il codice.
> 2. Spendi almeno 10 € con la carta entro 30 giorni.
> 3. Tieni il conto aperto fino all'accredito.

**Slide 5**
> **Cosa NON vale**
> Bonifici.
> Giroconti.
> Ricariche verso carte prepagate.
> Servono pagamenti con carta: POS, e-commerce o wallet.

**Slide 6**
> **Chi è escluso**
> Chi ha avuto rapporti con la banca dal 01/01/2020.
> Under 18.
> Non residenti in Italia.
> Dipendenti del gruppo UniCredit.

**Slide 7**
> **Quando arrivano i soldi**
> Entro 90 giorni lavorativi dalla spesa.
> Non sono immediati. Non sono garantiti se il conto viene chiuso o bloccato prima dell'accredito.

**Slide 8**
> **Trasparenza**
> Se usi il mio codice, io ricevo 50 €.
> Non lavoro per buddybank e non sono UniCredit.
> Condizioni complete: buddy.unicredit.it
> *Salva il post.*

**Didascalia:** "ADV — Il riassunto in 8 slide della promo buddy Club 100. 50 € netti a testa, ma con condizioni precise: spesa minima di 10 € con carta entro 30 giorni, accredito fino a 90 giorni lavorativi, esclusi i già clienti dal 2020. Se usi il mio codice ricevo 50 €. Non è un consiglio finanziario. Regolamento: buddy.unicredit.it #adv #buddybank #contocorrente #finanzapersonale"

---

## Commento fissato (uguale su TikTok e Instagram)

```
CODICE: [INSERIRE CODICE]

Prima di usarlo, tre cose:
1) serve per aprire un conto nuovo (non vale se sei già cliente UniCredit/buddy dal 2020)
2) spesa minima 10€ con carta entro 30 giorni
3) accredito fino a 90 giorni lavorativi

Se lo usi ricevo 50€. Regolamento: buddy.unicredit.it
```

Perché funziona: dà il codice subito, mette le condizioni **prima** che vengano chieste, e dichiara il guadagno. È l'opposto del commento spam.

---

## Inforge — thread completo

**Sezione:** Guadagnare con Promozioni (verifica di avere i requisiti di grado richiesti dal regolamento dell'area Money).

**Titolo:**
```
BUDDYBANK (UniCredit) - 50€ all'apertura + 50€ ad invito | 100 inviti | Scade 20/01/2027
```

**Corpo:**

```
BONUS PROMOZIONE: 50€ per l'invitato + 50€ per l'invitante
BONUS AGGIUNTIVO: +30€ per l'invitato fino al 16/11/2026 (totale 80€, accredito separato) - ELIMINA QUESTA RIGA SE PUBBLICHI DOPO IL 16/11
DATA DI SCADENZA: 20/01/2027 (codice disponibile fino al 17/01/2027)
NUMERO MASSIMO DI INVITI: 100 (5.000€)
REGOLAMENTO: [link Istruzioni PDF ufficiali]

CODICE: [INSERIRE CODICE]

CHI PUÒ PARTECIPARE
- Maggiorenni residenti in Italia
- Non già clienti UniCredit/buddy: esclusi coloro che hanno avuto un rapporto con la banca dal 01/01/2020
- Esclusi i dipendenti del gruppo UniCredit

COME FUNZIONA
1. Apri il conto Genius buddy (o Genius Care / Genius Care Top) oppure richiedi la carta Genius Pay, dal sito buddy.unicredit.it o dall'app.
2. Inserisci il codice invito durante la richiesta. Non dopo: non è recuperabile.
3. Effettua una o più transazioni con carta per almeno 10€ totali entro 30 giorni dall'apertura.
4. L'accredito arriva entro 90 giorni lavorativi dalla transazione.

COSA NON CONTA
- Bonifici e giroconti
- Ricariche verso carte prepagate
Contano solo POS fisico, e-commerce e wallet (Apple Pay, Google Pay, Samsung Pay).

COSA SAPERE PRIMA
- I 50€ sono già netti (ritenuta 26% applicata).
- Il conto deve restare aperto e non bloccato alla data dell'accredito.
- Canone 0€; carta digitale 0€ di emissione; carta fisica 3,50€ + 5,70€ di spedizione (verifica in fase di apertura).
- Non offro bonus extra miei: la promo è quella ufficiale.

TRASPARENZA
Sono un cliente buddy, non un dipendente e non un promoter di UniCredit. Se usi il codice ricevo 50€, esattamente come previsto dal regolamento.

Per dubbi scrivi nel thread: rispondo con il regolamento alla mano.
```

**Nota:** alcuni thread della sezione offrono "20€ extra da parte mia". Non farlo: crea un accordo parallelo non coperto dalla promo, complica il fisco e può essere letto come alterazione della partecipazione.

---

## Gruppi Facebook — post (solo con permesso dell'admin)

**Versione breve, per gruppi "offerte e codici":**
```
ADV | Promo buddybank (UniCredit), con le condizioni scritte.

50€ netti per chi apre il conto con il codice e 50€ per chi invita. (Fino al 16/11 l'invitato può ricevere 30€ in più, 80€ totali: elimina questa frase se pubblichi dopo.)

Per partecipare: apertura con codice + almeno 10€ di spesa con carta entro 30 giorni. L'accredito arriva fino a 90 giorni lavorativi. Esclusi i già clienti UniCredit/buddy dal 2020.

Codice: [INSERIRE CODICE]
Regolamento: buddy.unicredit.it

Se usi il codice ricevo 50€. Non lavoro per la banca.
```

**Cosa non fare:** postare lo stesso testo in 10 gruppi in un'ora, taggare persone, scrivere "affrettatevi" se mancano due mesi. I moderatori lo vedono e ti bannano.

**Prima di postare:** scrivi in privato all'admin. Testo:
> "Ciao, gestisco un profilo che spiega i bonus dei conti correnti. Posso pubblicare un post con la promo buddybank, dichiarando che è pubblicità e che ricevo un bonus referral? Se preferisci, te lo mando prima per approvazione."

---

## Telegram — messaggi

**Canale (solo se hai già un pubblico):**
```
ADV | buddybank: 50€ netti a testa.

Codice: [INSERIRE CODICE]
Serve: apertura conto con codice + 10€ di spesa con carta entro 30 giorni.
Accredito: fino a 90 giorni lavorativi. Esclusi i già clienti dal 2020.
Regolamento: buddy.unicredit.it

Se usi il codice ricevo 50€.
```

**Risposta a chi chiede informazioni (solo su richiesta esplicita):**
```
Ciao! Sì, è la promo buddy Club 100. Ti lascio il codice, ma prima le tre cose che contano: devi essere nuovo cliente (non vale se hai già UniCredit/buddy dal 2020), devi spendere almeno 10€ con carta entro 30 giorni, e il bonus arriva fino a 90 giorni lavorativi. Se ti torna, il codice è [INSERIRE CODICE]. Se lo usi io ricevo 50€.
```

---

## Reddit — risposte senza promozione

Non inserire codice, link o nome del profilo. Risposte utili, punto.

**Se chiedono "conviene buddybank per il bonus?"**
```
Dipende da tre cose, e sono tutte nel regolamento:

1. Sei già cliente UniCredit o buddy? Se hai avuto un rapporto dal 01/01/2020 sei escluso, quindi il bonus non lo prendi.
2. Il requisito non è un deposito: servono almeno 10€ di spesa con carta entro 30 giorni. Bonifici e ricariche non contano.
3. L'accredito è entro 90 giorni lavorativi, non immediato, e il conto deve restare aperto.

Se ti serve un conto e usi la carta comunque, ha senso. Se apri solo per i 50€, metti in conto che 10€ li spendi e che i tempi possono essere lunghi.
```

**Se chiedono il codice:** non rispondere pubblicamente. Se proprio vuoi, rispondi solo in privato a chi te lo chiede esplicitamente, sapendo che il sub vieta referral anche nei commenti. Il rischio di ban è tuo.

---

## Risposte ai commenti (template)

| Commento | Risposta |
|---|---|
| "È una truffa" | "Capisco la diffidenza. Non è una truffa: è una promo UniCredit con regolamento pubblico. I tempi però sono lunghi, fino a 90 giorni lavorativi, e se sei già cliente sei escluso. Se vuoi ti linko il PDF." |
| "A me non è arrivato niente" | "Può succedere se la spesa non rispetta i requisiti (bonifici e ricariche non valgono) o se il conto non era attivo. Con il regolamento alla mano: 10€ con carta entro 30 giorni. Se hai i requisiti, apri un ticket in app e fatti dire per iscritto cosa manca." |
| "Quanto ci guadagni?" | "50€ per ogni persona che apre con il mio codice e spende 10€. È scritto nel regolamento e lo dico in bio. A te non costa niente in più." |
| "Posso usarlo se ho già UniCredit?" | "No, sei escluso: il regolamento esclude chi ha avuto un rapporto con la banca dal 2020. Non dipende dal codice." |
| "Mandami il codice in privato" | "Te lo scrivo qui: [INSERIRE CODICE]. Prima leggi le condizioni nel commento fissato, così non sbagli." |

Rispondere in pubblico è meglio che in DM: crea prova sociale e non sembra un approccio aggressivo.

---

## Bio e testi fissi

**TikTok:**
```
Conti e bonus, regolamento alla mano. Codice in bio: ne guadagno anch'io.
```

**Instagram:**
```
Conti e bonus spiegati con il regolamento alla mano.
Non lavoro per le banche. Se usi i miei codici, a volte guadagno.
ADV quando promuovo.
```
