# 14 — Freebuff Italia: 600 inviti reali in 90 giorni

> Piano operativo. La verifica della reward e la strategia generale sono in `13-freebuff-600.md`. Questo file risponde a una sola domanda: **cosa pubblico, dove e quando, per arrivare a 600.**

---

## 0. Il numero, letto bene

600 inviti **reali**. La parola pesa più del numero: se Freebuff valida l'uso e non la semplice iscrizione, ogni iscritto che non apre mai il prodotto è un invito perso. Assumi una conversione iscrizione → utente reale del 40–60%. Significa **1.000–1.500 iscrizioni**.

In Italia ci sono circa **350.000 sviluppatori professionisti** e **150.000 studenti ICT**. Seicento su 350.000 è lo **0,17%**. Non devi conquistare l'Italia: devi raggiungere 600 persone dentro un mercato che esiste già. Il collo di bottiglia non è il prodotto, è la distribuzione.

E c'è un vantaggio raro: **in italiano non ne parla nessuno.** Cerca "freebuff" su TikTok, YouTube o Google in italiano: non trovi una guida, non trovi un video, non trovi un articolo. Chi arriva primo si prende la query. Per 90 giorni, "freebuff italiano" può essere tu.

---

## 1. Quante persone devi raggiungere

| Tipo di reach | Conversione realistica | Persone da raggiungere |
|---|---|---|
| Fredda (TikTok/Reels) | 0,2% | 300.000 |
| Tiepida (LinkedIn, YouTube, X) | 0,5% | 120.000 |
| Calda (community, Discord, gruppi) | 2% | 30.000 |
| Dal vivo (workshop, meetup) | 5% | 12.000 |

Un mix realistico è **60% fredda + 40% calda**: circa **150.000–250.000 persone distinte in 90 giorni** (le visualizzazioni sommate sui canali sono molte di più), cioè 1.700–2.800 al giorno. Con 5 contenuti a settimana e presenza in 10 community è un obiettivo di lavoro, non di fortuna.

Il numero da guardare ogni settimana non è "quanti inviti", è **iscritti per 1.000 visualizzazioni**. Se è sotto 0,5, il contenuto non converte: cambi formato, non aumenti il volume.

---

## 2. Il motore narrativo: la serie "0/600"

Il MacBook non è il premio per il tuo pubblico. È la **posta in gioco** della storia. La differenza è tutto.

Nessuno guarda un video "usa il mio link". Milioni di persone guardano qualcuno che prova a fare una cosa difficile in pubblico, con un numero che sale.

**Come funziona la serie:**

- Ogni domenica un recap: "Settimana 3: 47/600". Numeri veri, anche quando sono brutti.
- Ogni video ha in basso il contatore aggiornato.
- Ogni milestone (50, 100, 250, 500) è un video a sé.
- Il tono è sperimentale, non lamentoso: "questa settimana ho provato X, ha funzionato Y, la prossima provo Z".

**Perché funziona:**

- La trasparenza disinnesca la diffidenza verso i referral.
- Chi ti segue vuole sapere come finisce: è una serie, non un annuncio.
- Il contatore dà urgenza senza scarsità finta.
- Attira creator e giornalisti: "l'italiano che prova a vincere un MacBook invitando 600 persone" è una storia, un link no.

**La regola:** se il numero si blocca, la storia non è "sto fallendo", è "sto capendo cosa funziona". Il contenuto resta utile anche a chi non si iscrive: è un diario di growth, non un volantino.

**Sei post già scritti:**

1. **Giorno 1.** "0/600. Ho 90 giorni per portare 600 sviluppatori italiani su un coding agent gratis. Se arrivo a 600, mi mandano un MacBook. Non lavoro per loro. Documento tutto, numeri veri, anche se va male."
2. **Giorno 7.** "47/600 nella prima settimana. Il video che ha funzionato non era quello che pensavo. Ecco i numeri."
3. **Giorno 30.** "100/600. Cosa ho sbagliato: ho parlato a sviluppatori come se fossero influencer."
4. **Giorno 45.** "Il contatore è fermo da 9 giorni. Ecco cosa ho cambiato."
5. **Giorno 60.** "300/600. La cosa che ha svoltato: i workshop universitari, non TikTok."
6. **Giorno 90.** "600/600 (o quello che è). Cosa rifarei, cosa no, e perché l'Italia è un buon mercato per i tool AI."

---

## 3. I tre contenuti che solo tu puoi fare in Italia

La reach fredda non si conquista con "ecco un tool". Si conquista con un problema che il pubblico riconosce come suo.

### A. Build italiane

Non "un SaaS demo". Cose che un italiano riconosce in un secondo:

- Visualizzatore di **fatture elettroniche XML** (FatturaPA). Dolore universale di freelance e PMI.
- Generatore di preventivi per **partita IVA forfettaria**.
- Bot Telegram per le **scadenze fiscali**.
- **Menu QR** per ristoranti.
- App per dividere le spese tra **coinquilini**, in italiano.
- Calcolatore **IMU/TARI**.
- Dashboard per freelance con fatturato e tasse stimate.

Un video che si chiama "Ho costruito un lettore di fatture elettroniche in 12 minuti" vale dieci "Ho costruito un SaaS".

### B. Il costo in euro

"Cursor costa 20 €/mese. Copilot 10. Questo è 0, finanziato dalla pubblicità." Confronto onesto, senza denigrare: mostra il conto, non il vincitore. In Italia il prezzo è l'argomento.

### C. Studenti

"Agent gratis, senza carta, senza abbonamento." È il pubblico più ricettivo e più social: condivide in gruppo e porta altri tre.

---

## 4. Canali, con numeri attesi

| Canale | Contenuto | Cadenza | Reach 90gg | Iscritti attesi |
|---|---|---|---|---|
| TikTok | Build italiane, 25–40s | 4/settimana | 80–150k | 150–300 |
| Instagram Reels | Repost TikTok + caroselli | 4/settimana | 30–60k | 60–120 |
| LinkedIn | Recap, caso studio, opinione | 3/settimana | 40–80k | 150–300 |
| YouTube Shorts | Tutorial + ricerca | 2/settimana | 20–40k | 60–120 |
| X | Thread tecnici, italiani e inglesi | 4/settimana | 30–80k | 60–120 |
| Community | Risposte utili, no link | 30 min/giorno | 10–20k | 100–200 |
| Università | Workshop dal vivo | 6 in 90gg | 500 persone | 150–250 |
| Creator | 5 micro-collaborazioni | 5 in 90gg | 50–100k | 100–200 |
| GitHub | Starter Kit | 1 lancio + update | 5–10k | 50–100 |

Totale conservativo: **~880–1.700 iscritti**. Nella parte bassa non arrivi a 600 reali; nella parte alta sì. Per questo servono **tutti** i canali, non il migliore.

**Priorità se hai poco tempo:** LinkedIn + università + community. Sono i tre con la conversione più alta e i più sottovalutati.

---

## 5. Le community italiane

Non sono "canali". Sono stanze con regole. La regola numero uno: **prima dai, poi chiedi.**

Dove stare:

- Discord e Telegram di programmazione italiana (cerca "programmatori italiani", "developers italia", "coding italia").
- Gruppi Facebook: sviluppatori web, informatica universitaria, freelance.
- Subreddit: r/ItalyInformatica, r/programmazione. Leggi le regole: molti vietano l'autopromozione. Se è vietato, non mettere il link, rispondi e basta.
- Meetup: React Milano, Python Italia, GDG, Coding Italia, community locali a Torino, Bologna, Roma, Napoli.
- Server internazionali di AI coding: lì parli in inglese e il link vale doppio.

Cosa fai: **10 risposte utili al giorno, per 20 giorni. Nessun link.** Poi, quando qualcuno chiede "con cosa lo faccio gratis?", rispondi con il nome e lascia che siano gli altri a chiederti il link. È lento, ma è l'unico modo che non ti fa bannare.

---

## 6. Università: il canale che converte di più

Un workshop dal vivo converte al 30–50%. Un video allo 0,2%. Cento volte tanto.

**Format: 60 minuti, "Costruisci la tua prima app con un agent gratis".**

- 5 min: chi sei e perché lo fai (la serie 0/600, in due frasi).
- 10 min: demo dall'inizio alla fine, risultato funzionante.
- 30 min: ognuno costruisce la sua, tu giri tra i tavoli.
- 10 min: domande.
- 5 min: come continuare, link, gruppo.

**Come entrare:** scrivi ai docenti di informatica, ai rappresentanti degli studenti, alle associazioni studentesche (IEEE, AISA, studenti di ingegneria). Non serve un budget: serve una data e una stanza. Porta il kit, non vendere niente.

**Dove:** Politecnico di Milano e Torino, Bocconi, LUISS, Sapienza, Bologna, Padova, Napoli Federico II, Bari, Catania. Sei bastano.

---

## 7. Creator: l'offerta che non costa niente

Con budget zero non compri sponsorizzazioni. Puoi offrire tre cose che valgono:

1. **Un build su misura per il loro canale.** "Dimmi un'idea, te la costruisco in diretta e te la regalo."
2. **Accesso anticipato al kit** e citazione nel repo.
3. **La storia.** "Sto facendo 0/600, mi aiuti a raccontarlo?" È un contenuto pronto per loro.

Cerca creator italiani da 5.000 a 30.000 follower: dev, AI, no-code, studenti. Non i grandi: costano e convertono meno. Cinque collaborazioni buone valgono più di una grande.

---

## 8. Calendario 90 giorni

### Giorni 1–3 — Setup

Account, bio con contatore, kit (10 template), 10 video girati in batch, prima settimana di post pronta. Non pubblichi niente finché non hai 10 video in cassetta: la costanza è il primo fattore di crescita.

### Giorni 4–30 — Test di formato

4 TikTok/Reels a settimana, 3 LinkedIn, 2 Shorts, 4 X, 30 min/giorno in community, 1 recap la domenica.
Obiettivo: capire quale formato converte. Milestone: **100 iscritti**.

### Giorni 31–60 — Community e università

2 workshop, 3 collaborazioni, presenza fissa in 10 community, serie build italiane.
Obiettivo: alzare la conversione, non la reach. Milestone: **300**.

### Giorni 61–90 — Spinta finale

3 workshop, 2 collaborazioni, un pitch a 3 testate tech italiane, lancio pubblico del kit, recap quotidiano nell'ultima settimana.
Milestone: **450, poi 600**.

### Cadenza settimanale tipo (10–12 ore)

- **Domenica:** 3 ore. Giro 5 video, scrivo i copy della settimana.
- **Lun–Ven:** 1 ora/giorno. Pubblicazione, commenti, 10 risposte in community.
- **Sabato:** 1 ora. Recap numeri e decisione della settimana.

---

## 9. Quindici video, con hook

| # | Hook (primi 2 secondi) | Payoff |
|---|---|---|
| 1 | "Giorno 1: 0/600." | La sfida, il MacBook, come funziona |
| 2 | "Questa è una fattura elettronica. Fa schifo." | La trasformo in un'app leggibile in 12 min |
| 3 | "Cursor costa 20 euro al mese." | Lo stesso task, gratis, senza carta |
| 4 | "Gli ho dato 5 task insieme." | 5 agent in parallelo sullo stesso repo |
| 5 | "Il prompt che uso per ogni landing." | Prompt copiabile + risultato |
| 6 | "Studenti, smettete di pagare." | Setup in 3 minuti, zero carta |
| 7 | "Il ristorante sotto casa non ha il menu online." | Menu QR in 8 minuti |
| 8 | "Stesso bug, due agent." | Confronto onesto con Cursor |
| 9 | "L'agent ha rotto tutto." | Cosa è andato storto e come si recupera |
| 10 | "10 prompt che uso ogni giorno." | Carosello/thread, salvataggio alto |
| 11 | "Il mio portfolio era del 2019." | Rifacimento completo in 15 min |
| 12 | "Quanto costa davvero il vibe coding." | Conti in euro, abbonamenti vs zero |
| 13 | "Settimana 1: 47/600." | Recap con numeri veri |
| 14 | "Mi mancano 43 inviti." | Countdown, CTA diretta |
| 15 | "Come divido l'affitto con 3 coinquilini." | App italiana, utile, condivisibile |

**Struttura di ogni video:** risultato nei primi 2 secondi → 20 secondi di processo veloce → 5 secondi di payoff → CTA in una frase. Sottotitoli sempre, audio opzionale, nessun volto.

---

## 10. Tre copy pronti

**TikTok/Reels — Giorno 1**

> 0/600.
> Ho 90 giorni per portare 600 sviluppatori italiani su Freebuff, un coding agent gratis e senza carta. Se arrivo a 600, mi mandano un MacBook Pro.
> Non lavoro per loro. Se ti iscrivi dal mio link io ricevo sessioni extra e mi avvicino al premio: a te non costa niente.
> Ogni domenica pubblico i numeri veri. Anche quelli brutti.
> #programmazione #ai #coding #freebuff #italia

**LinkedIn**

> In Italia nessuno parla di coding agent gratuiti, in italiano. Zero video, zero guide, zero articoli.
> Ho 90 giorni per portare 600 sviluppatori su Freebuff, che è gratis e finanziato dalla pubblicità. È un esperimento pubblico: settimana per settimana, numeri veri.
> Se costruisci software, il link è nel primo commento. Se non ti serve, ignora pure: il diario resta utile lo stesso.
> #sviluppo #ai #italia

**Community (solo dove i link sono ammessi)**

> Ho costruito un lettore di fatture elettroniche con un agent gratis, in 12 minuti. Il codice è qui: [repo]. Se ti serve provarlo, il tool è freebuff.com — io ho un link referral, quindi se passi da lì mi dai una mano con la loro promo. Se sei contro i referral, nessun problema: usalo dal sito diretto.

---

## 11. Metriche e regole di decisione

Ogni domenica, quattro numeri:

1. Iscritti totali e **inviti reali**.
2. Iscritti per 1.000 visualizzazioni, per canale.
3. Miglior contenuto della settimana e perché.
4. Ore investite e iscritti per ora.

**Regole:**

- Dopo 20 video, se un canale sta sotto **0,5 iscritti per 1.000 visualizzazioni**, lo tagli e sposti le ore su LinkedIn/community/università.
- Se dopo 30 giorni sei sotto 100, il problema è il messaggio, non la frequenza: cambia hook, non aumentare i post.
- Se un video supera 5 volte la media, lo rifai in 3 varianti nella settimana.
- Se un invito è "reale" solo con l'uso, misura anche l'attivazione: chiedi in community chi ha aperto il prodotto e cosa ha costruito.

---

## 12. Cosa fai stasera (2 ore)

1. Apri l'account e metti in bio il contatore: "0/600 → MacBook".
2. Gira il video 1 con il telefono in verticale: screen recording + voce o sottotitoli.
3. Pubblica su TikTok e Reels.
4. Scrivi il post LinkedIn.
5. Apri il repo del kit, anche vuoto, con il README e il link in fondo.

Domani: 10 risposte utili in 3 community, senza link.
