# 11 — Naming: ricerca e decisione

**Verifica effettuata il 12 novembre 2026.** Gli handle cambiano: ricontrolla al momento della registrazione.

---

## Metodo

Ho usato i criteri ricorrenti della letteratura sul naming, adattati a un creator account:

1. **Memorabilità** — si ricorda dopo averlo sentito una volta?
2. **Distintività** — si distingue dai nomi già presenti nel settore?
3. **Significato** — evoca il posizionamento giusto?
4. **Pronuncia e spelling** — si scrive correttamente dopo averlo sentito?
5. **Handle** — esiste identico su TikTok e X, entro i limiti delle piattaforme?
6. **Durata** — funziona ancora quando la promo è finita?
7. **Rischio di collisione** — quante probabilità ci sono di confusione o problemi di marchio?

X accetta al massimo **15 caratteri**, solo lettere, numeri e underscore, e **non** accetta il punto. TikTok arriva a 24 e accetta il punto. Se vuoi lo stesso handle ovunque, il vincolo è X.

---

## Il panorama competitivo

I creator finance italiani sono dominati da due pattern:

- **Brand personali:** Mr. Rip, Andrea Bertoni, Matteo Napoletano, Pietro Michelangeli, Riccardo Zanetti, Chiara Anzuino.
- **Nomi inglesi o descrittivi:** Starting Finance, Io Investo, Finance Playbook, The Bull, Ingegneri in Borsa, Investiamo, Finvestire.

C'è uno spazio vuoto: **una frase idiomatica italiana, breve, consumer, che non parla di investimenti ma di conti e spese quotidiane.** È esattamente il posizionamento di questo progetto. Un nome inglese sarebbe invisibile in mezzo agli altri; un nome personale non è possibile, perché non vuoi apparire.

---

## Verifica degli handle

| Handle | TikTok | X | Esito |
|---|---|---|---|
| `faiiconti` | Libero | Libero | **Usabile** |
| `contiintasca` | Libero | Libero | Usabile |
| `fattiticonti` | Da verificare | Libero | Verificare |
| `contiallamano` | Da verificare | Libero | Verificare |
| `acontifatti` | Occupato (profilo privato, 2.237 follower) | Occupato | Scartato |
| `cartacanta` | Occupato (0 video) | Occupato | Scartato |
| `dueconti` | Da verificare | Occupato | Scartato |
| `contiinchiaro` | Da verificare | Occupato | Scartato |

"Libero" significa che la pagina profilo pubblica non esisteva al momento della verifica. Non è una prenotazione: va confermato in fase di registrazione.

---

## Matrice di valutazione

Punteggio 1–5. Per "Rischio collisioni" e "Handle", **5 è il valore migliore**.

| Nome | Memoria | Distintività | Significato | Pronuncia | Handle | Durata | Collisioni | Totale /35 |
|---|---|---|---|---|---|---|---|---|
| **Fai i Conti** | 4 | 4 | 5 | 5 | 5 | 5 | 4 | **32** |
| Conti in Tasca | 5 | 3 | 5 | 5 | 5 | 5 | 3 | 31 |
| Fatti i Conti | 3 | 3 | 4 | 5 | 4 | 5 | 4 | 28 |
| A Conti Fatti | 4 | 3 | 5 | 5 | 2 | 5 | 3 | 27 |
| Conti alla Mano | 3 | 3 | 4 | 4 | 4 | 4 | 4 | 26 |
| Carta Canta | 5 | 3 | 5 | 5 | 1 | 4 | 3 | 26 |
| Due Conti | 4 | 2 | 4 | 5 | 1 | 5 | 2 | 23 |

La matrice è un framework di giudizio, non una misura scientifica. Serve a rendere esplicito perché una scelta vince.

---

## Il nome scelto: **Fai i Conti**

### Perché vince

1. **È un'azione, non una categoria.** "Fai i conti" è ciò che farai in ogni video: 50 − 10 = 40, 90 giorni lavorativi, 3,50 € + 5,70 €. Il nome è già la promessa del contenuto.
2. **È italiano e idiomatico.** In un mare di "Finance", "Investo" e "Playbook", si ricorda e si pronuncia senza sforzo.
3. **Funziona dopo la promo.** Non contiene "bonus", "80" o "buddybank". A febbraio puoi continuare a parlare di costi, conti e risparmio senza cambiare identità.
4. **Ha l'handle pulito.** `@faiiconti` è libero su TikTok e su X, 9 caratteri, nessun punto, nessun underscore. È raro trovare un nome così corto con entrambe le porte aperte.
5. **Non sembra una banca.** Non promette soldi, non imita un istituto, non usa il logo di nessuno. Riduce il rischio di essere percepito come spam o come account ufficiale.

### Il rischio

"Fai i conti" è una frase comune, quindi è **debole come marchio registrabile**: facile da usare, difficile da proteggere. Per un progetto personale va bene. Se un giorno vuoi registrarlo, serve una verifica UIBM/EUIPO nella classe 36 (servizi finanziari): non dare per scontato che sia libero solo perché il dominio o l'handle lo sono.

---

## Setup esatto

### TikTok
| Campo | Valore |
|---|---|
| Nome | `Fai i Conti \| bonus e conti` (28 caratteri) |
| Username | `@faiiconti` |
| Bio | `Leggo i regolamenti. Tu fai i conti. Codice in bio: ci guadagno.` |
| Link | pagina ufficiale buddy |

### X
| Campo | Valore |
|---|---|
| Nome | `Fai i Conti` |
| Handle | `@faiiconti` |
| Bio | `Leggo i regolamenti delle banche e ti faccio i conti. Bonus, conti correnti, costi veri. Se usi i miei codici ricevo un bonus. ADV.` |
| Location | `Italia` |

### Immagine profilo senza volto
Non vuoi apparire, quindi niente foto. Serve un **wordmark**, non un'icona generica:

- Sfondo verde bosco o blu notte.
- Testo `FAI I CONTI` in bianco, font sans-serif condensato, su due righe.
- Il punto della "i" in giallo, come unico dettaglio di colore.
- Nessun simbolo di euro, nessun salvadanaio, nessuna freccia. Sembrano tutti uguali.

**Banner X:** `50 − 10 = 40` a sinistra, `Il resto sono chiacchiere` a destra. Stesso font, stesso verde.

---

## Se `@faiiconti` viene occupato prima che ti registri

In ordine di preferenza, tutti entro i 15 caratteri di X:

1. `@faiiconti_ita` (13)
2. `@faiicontiit` (12)
3. `@faiiconti_` (10)

Non cambiare nome per un underscore: cambia solo l'handle, il nome visualizzato resta "Fai i Conti". Un suffisso è meglio di un nome nuovo.

---

## Le alternative, se non ti convince

**Conti in Tasca** — `@contiintasca`, libero su entrambi. Più caldo e più "da persona", meno action-oriented. Difetto: somiglia a "Conti in Chiaro", un account budgeting già attivo su X.

**Fatti i Conti** — `@fattiticonti`, libero su X, da verificare su TikTok. Più colloquiale, ma "fatti i conti" può suonare come "arrangiati", che è l'opposto della fiducia che vuoi costruire.

**A Conti Fatti** — il significato migliore, ma `@acontifatti` è occupato su entrambi. Servirebbe `@acontifatti_ita` (15). Accettabile solo se quel nome ti rappresenta davvero.

---

## Da non fare

- Non usare `buddybank`, `UniCredit`, `buddy` o varianti: marchio altrui e rischio di impersonificazione.
- Non usare `bonus80`, `bonus50`, `guadagnafacile`, `soldifacili`: attirano il pubblico sbagliato e invecchiano in una settimana.
- Non mettere l'anno nel nome (`bonus2026`): tra due mesi è vecchio.
- Non scegliere un nome che non sai pronunciare al telefono in tre secondi.
- Non cambiare handle dopo due settimane: perdi la ricerca e la memoria di chi ti segue.
