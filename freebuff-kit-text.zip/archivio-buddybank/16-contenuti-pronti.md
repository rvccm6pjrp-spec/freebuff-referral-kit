# 16 — Contenuti pronti: Freebuff e buddybank

> **Superato da `17-contenuti-v2.md`.** Questa versione resta come archivio: la v2 è costruita sui pattern virali verificati a novembre 2026.

> Prodotto con le skill installate in `.agents/skills/` (hook-writer, tiktok-script, carousel-writer, offers, copywriting). Ogni script segue lo stesso schema: hook su tre canali, beat da 3–5 secondi, loop finale, caption con keyword. Le immagini si generano senza testo: i testi si aggiungono in CapCut o Canva, perché i modelli sbagliano l'italiano dentro l'immagine.

---

## 0. Il principio che decide tutto

Per Freebuff, **un'iscrizione che non apre il prodotto non è un invito reale**. Quindi la CTA di ogni contenuto non è "iscriviti": è **"fai questa cosa"**. Il link serve a completarla, non a sostituirla.

Per buddybank vale l'opposto: l'invitato deve **spendere 10 € con la carta**, altrimenti il bonus non parte. Quindi la CTA è "apri e fai la prima spesa", non "apri il conto".

Se il contenuto non fa fare l'azione che genera il bonus, è intrattenimento.

---

## 1. I due profili di brand

### 1.1 Freebuff Italia

**Identità.** Un coding agent gratuito, senza carta, finanziato dalla pubblicità. In italiano non ne parla nessuno.

**Pubblico.** Sviluppatori 20–35, studenti ICT, freelance, indie hacker. Gente che paga o ha smesso di pagare un abbonamento per scrivere codice.

**Punto di vista.** Il costo degli strumenti AI è diventato una tassa sul lavoro dei developer. Un agent gratis e illimitato cambia chi può costruire.

**Voce.** Frasi da 6–12 parole. Prima persona. Numeri concreti. Un'ironia asciutta, mai entusiasta. Si dice "ho fatto", non "abbiamo rivoluzionato".

**Lessico:** repo, prompt, build, gira, bug, deploy, gratis davvero, sessione.

**Vietato:** rivoluzionario, game changer, segreto, magia, il migliore, guadagna, "semplicissimo".

**Prova:** $0, unlimited, nessuna carta; community pubblica di centinaia di migliaia di developer; modelli frontier; referral = sessioni extra.

**Guardrail:** disclosure del referral in ogni caption. Un account per persona. Nessun benchmark inventato. Il MacBook è un traguardo personale, non una promo ufficiale.

### 1.2 Soldi HQ (buddybank)

**Identità.** Un account che spiega i bonus bancari con i numeri e le condizioni. Non fa il tifo per la banca.

**Pubblico.** 25–40 anni, lavoratori dipendenti, studenti fuori sede, chi apre il primo conto o ne cambia uno.

**Punto di vista.** I bonus si leggono dalle condizioni, non dalla pubblicità. Se ti serve un conto, il bonus è un extra. Se apri solo per il bonus, fai i conti prima.

**Voce.** Dai del tu. Frasi brevi. Cifre esatte. "Ecco cosa dice il regolamento". Nessun punto esclamativo.

**Vietato:** soldi facili, guadagno garantito, trucco, hack, il migliore conto, consulenza finanziaria.

**Prova:** pagina buddy Club 100, 50 € a testa, 30 € extra all'invitato fino al 16/11/2026, massimo 100 inviti.

**Guardrail:** ADV a inizio didascalia. 18+, residenti in Italia, non già clienti UniCredit/buddy dal 01/01/2020. Spesa minima 10 € con carta entro 30 giorni. Accredito entro 90 giorni lavorativi.

---

## 2. Freebuff: otto script TikTok/Reels

### 2.1 Giorno 1 — 0/600

**Hook**
- Visivo: schermo nero, un contatore che si scrive da solo: `0/600`.
- Testo a schermo: `0/600`.
- Voce: "Mi sono dato 90 giorni per portare 600 sviluppatori italiani su Freebuff."

**Produzione**

| Tempo | Shot | Testo a schermo | Voce |
|---|---|---|---|
| 0–3s | Contatore che si scrive | `0/600` | "Mi sono dato 90 giorni per portare 600 sviluppatori italiani su Freebuff." |
| 3–7s | Homepage, scroll veloce | `gratis, senza carta` | "È un coding agent gratis, finanziato dalla pubblicità. Non chiede la carta." |
| 7–13s | Terminale che builda, timelapse | `funziona davvero` | "Non è una demo. Ci costruisco le cose che vedi qui." |
| 13–18s | Griglia di 600 caselle vuote | `90 giorni` | "Ogni domenica pubblico i numeri. Anche quelli brutti." |
| 18–22s | Freccia verso il link in bio | `link in bio` | "Se ti iscrivi dal mio link mi avvicini al traguardo. A te non costa niente." |

**Loop.** L'ultima frase è "si parte da zero", che si aggancia al contatore iniziale.

**Caption**
> Giorno 1: 0/600.
> 90 giorni per portare 600 sviluppatori italiani su Freebuff, che è gratis e senza carta.
> Se arrivo a 600 mi mandano un MacBook Pro.
> Ogni domenica i numeri veri.
> Link in bio.
> ADV: se ti iscrivi dal mio link ricevo sessioni extra.
> #programmazione #coding #ai #freebuff #sviluppatore #italia

**Perché funziona.** Specificità (600), posta in gioco (MacBook), prova immediata (build). La serie crea il motivo per tornare.

---

### 2.2 La fattura elettronica illeggibile

**Hook**
- Visivo: XML a schermo, zoom su una riga chilometrica.
- Testo: `12 minuti`.
- Voce: "Questa è una fattura elettronica. Nessun essere umano dovrebbe leggerla."

**Produzione**

| Tempo | Shot | Testo a schermo | Voce |
|---|---|---|---|
| 0–3s | XML, zoom | `12 minuti` | "Questa è una fattura elettronica. Nessun essere umano dovrebbe leggerla." |
| 3–7s | Prompt scritto nel terminale | `importo, fornitore, scadenza` | "Gli chiedo tre cose: importo, fornitore, scadenza." |
| 7–15s | Build velocizzata, 8x | `sto costruendo` | "Nessun codice scritto a mano." |
| 15–20s | Pagina pulita sul telefono | `leggibile` | "Tempo: dodici minuti." |
| 20–23s | Scroll della pagina | `ora la leggo dal telefono` | "La prossima la faccio in sei." |

**Loop.** "La prossima la faccio in sei" riporta al timer iniziale.

**Caption**
> Una fattura elettronica in XML, trasformata in una pagina leggibile in 12 minuti.
> Importo, fornitore e scadenza, senza aprire dieci file.
> Se lavori con le Partite IVA, salvalo.
> Tool: Freebuff, gratis e senza carta. Link in bio.
> ADV: referral personale.
> #fatturaelettronica #partitaiva #freelance #programmazione #ai

**Perché funziona.** È un dolore italiano specifico, non l'ennesima todo list. Nessuno lo copre in italiano.

---

### 2.3 Cursor costa 240 dollari l'anno

**Hook**
- Visivo: due finestre affiancate, a sinistra il prezzo di Cursor, a destra `0`.
- Testo: `240 $/anno → 0`.
- Voce: "Venti dollari al mese per un tool che uso tre ore al giorno sono duecentoquaranta dollari l'anno."

**Beat**
1. Mostra il prezzo reale, senza modificarlo.
2. Stesso task sulle due finestre, timer.
3. Risultato.
4. Onestà: "Sui task lunghi qualche volta sbaglia. Per il 90% di quello che faccio, basta."
5. CTA: "Provalo sullo stesso task e giudica tu."

**Loop.** "Rifallo con il tuo task e guarda il timer" riporta al confronto.

**Caption**
> Stesso bug, due agent, stesso repo.
> Cursor: 20 $/mese. Freebuff: 0, finanziato dalla pubblicità.
> Non sono identici. Sui task lunghi uno dei due sbaglia più spesso, e lo dico nel video.
> Provalo sul tuo codice prima di credermi.
> Link in bio. ADV: referral.
> #cursor #coding #ai #programmazione #freebuff

**Perché funziona.** Il confronto onesto è più credibile della pubblicità. Il nome di un concorrente porta ricerca.

---

### 2.4 Tre task insieme

**Hook**
- Visivo: tre terminali che partono nello stesso secondo.
- Testo: `3 task, 1 repo`.
- Voce: "Gli ho dato tre task nello stesso momento, sullo stesso repository."

**Beat**
1. Elenca i tre task in testo.
2. Split screen dei tre agent.
3. `git diff` finale con tre cartelle modificate.
4. Un errore visibile, non tagliato.
5. CTA: "Il quarto lo lascio a te."

**Loop.** "Tre insieme, il quarto da solo" riporta all'inizio.

**Caption**
> Tre task in parallelo sullo stesso repo.
> Un conflitto c'è stato, e si vede.
> Il quarto lo provi tu: link in bio, è gratis.
> ADV: referral.
> #coding #ai #git #programmazione #dev

---

### 2.5 Il prompt della landing

**Hook**
- Visivo: il prompt appare parola per parola, poi la pagina finita.
- Testo: `copia questo`.
- Voce: "Questo è il prompt che uso per ogni landing. Non è magico, è specifico."

**Beat**
1. Prompt in 6 righe, leggibile, fermo 3 secondi.
2. Build.
3. Scroll del risultato.
4. CTA: "È in descrizione, salvalo."

**Loop.** "Riscrivilo con il tuo prodotto" riporta al prompt.

**Caption**
> Il prompt che uso per ogni landing:
> "Costruisci una landing per [prodotto] per [pubblico]. Sezioni: problema, come funziona in 3 passi, prova, prezzo, FAQ. Tono diretto, frasi brevi, nessun aggettivo."
> Salvalo. Ti serve.
> Tool gratis, link in bio. ADV: referral.
> #prompt #landingpage #coding #ai

---

### 2.6 Studenti, smettete di pagare

**Hook**
- Visivo: carta di credito che viene messa via.
- Testo: `0 €, senza carta`.
- Voce: "Se studi informatica e paghi un abbonamento per scrivere codice, stai pagando per una cosa che oggi è gratis."

**Beat**
1. `npm install -g freebuff`, tre secondi.
2. Login con GitHub.
3. Primo progetto creato.
4. "È gratis e finanziato dalla pubblicità, senza trial."
5. CTA: "Fallo adesso, prima di studiare per l'esame."

**Loop.** "Tre comandi e zero euro" riporta alla carta messa via.

**Caption**
> Tre comandi:
> `npm install -g freebuff`
> `cd progetto`
> `freebuff`
> Nessuna carta, nessun trial.
> Se studi, inizia da qui. Link in bio.
> ADV: referral.
> #studenti #università #coding #informatica #ai

---

### 2.7 Il menu del ristorante sotto casa

**Hook**
- Visivo: menu di carta spiegazzato, luce calda.
- Testo: `8 minuti`.
- Voce: "Il ristorante sotto casa non ha il menu online. Gliel'ho fatto in otto minuti."

**Beat**
1. Foto del menu reale.
2. Prompt: "leggi questo menu e crea una pagina con QR".
3. Build.
4. QR stampato sul tavolo, menu aperto dal telefono.
5. CTA: "Se conosci un ristoratore, mandagli questo video."

**Loop.** "Otto minuti, un QR" riporta al menu di carta.

**Caption**
> Il ristorante sotto casa non aveva il menu online.
> Otto minuti e un QR sul tavolo.
> Se conosci un ristoratore, mandagli questo video.
> Fatto con Freebuff, gratis. Link in bio.
> ADV: referral.
> #ristorante #menuqr #smallbusiness #coding #italia

---

### 2.8 Settimana 1 — 47/600

**Hook**
- Visivo: barra che si riempie fino a 47.
- Testo: `47/600`.
- Voce: "Settimana uno: quarantasette. E il video che ha funzionato non era quello che pensavo."

**Beat**
1. Numeri: visualizzazioni, click, iscritti.
2. Il video migliore e quello peggiore.
3. La lezione in una frase.
4. Cosa provo la settimana prossima.
5. CTA: "Se vuoi vedere se funziona, seguimi."

**Loop.** "La prossima settimana si riparte da 47" chiude il cerchio.

**Caption**
> Settimana 1: 47/600.
> Il video sulle fatture ha portato più iscritti di quello sul confronto.
> La lezione: in Italia vince il problema concreto, non il tool.
> La prossima provo i preventivi per forfettari.
> ADV: referral.
> #buildinpublic #coding #ai #italia

---

## 3. Freebuff: X e LinkedIn

### 3.1 Thread X di lancio

1/ Ho 90 giorni per portare 600 sviluppatori italiani su Freebuff. Se ci arrivo, mi mandano un MacBook. Documento tutto, numeri veri.

2/ Cos'è: un coding agent gratis, senza carta, finanziato dalla pubblicità. `npm install -g freebuff`, poi `freebuff` nella cartella del progetto.

3/ Cosa ci costruisco: lettore di fatture elettroniche, menu QR, preventivi per forfettari. Roba italiana, non la solita todo list.

4/ Cosa non è: non è Claude Code. Sui task lunghi sbaglia. Per il 90% di quello che faccio, basta.

5/ Se ti iscrivi dal mio link ricevo sessioni extra. A te non costa niente. Link nel primo commento.

6/ Ogni domenica i numeri. Anche quelli brutti.

### 3.2 Quattro post X brevi

- "Ho trasformato una fattura elettronica in una pagina leggibile in 12 minuti. Il codice è nel thread."
- "Il prompt che uso per ogni landing è in descrizione. Copialo, non ringraziarmi."
- "Oggi 47/600. Il video che ha portato più iscritti parlava di fatture, non di AI."
- "Se paghi 20 $/mese per scrivere codice, prova la versione gratis sullo stesso task. Poi decidi."

### 3.3 LinkedIn — post 1

> In Italia nessuno parla di coding agent gratuiti, in italiano. Zero video, zero guide, zero articoli.
>
> Ho 90 giorni per portare 600 sviluppatori su Freebuff, che è gratis e finanziato dalla pubblicità. È un esperimento pubblico: ogni domenica pubblico numeri, errori e cosa ha funzionato.
>
> La prima settimana ha insegnato una cosa: vince il problema concreto. Un video sulle fatture elettroniche ha portato più iscritti di un confronto tra tool.
>
> Se costruisci software, il link è nel primo commento. Se non ti serve, ignora: il diario resta utile lo stesso.
>
> #sviluppo #ai #italia

### 3.4 LinkedIn — post 2 (studenti)

> Se studi informatica e paghi un abbonamento per scrivere codice, oggi hai un'alternativa gratuita.
>
> Freebuff è un coding agent senza carta, finanziato dalla pubblicità. Tre comandi e parte.
>
> Non è identico ai tool a pagamento: sui task lunghi sbaglia. Per i progetti dell'università basta.
>
> Se ti serve, il link è nel primo commento. ADV: referral.
>
> #studenti #università #coding #ai

### 3.5 Carosello LinkedIn — 7 slide

1. **Copertina:** "Programmare con l'AI: quanto costa davvero in Italia"
2. I prezzi reali: Cursor 20 $/mese, Copilot 10 $/mese, Claude Pro 20 $/mese.
3. Il conto annuale: da 120 a 240 $ per persona.
4. Per un freelance sono 240 $ prima della prima riga di codice.
5. Esiste un'opzione a 0, finanziata dalla pubblicità.
6. Cosa non aspettarti: non è identica ai tool a pagamento.
7. CTA: "Salva il carosello e prova il tuo task."

Design: fondo crema, testo nero, un solo accento verde. Numeri grandi, una frase per slide.

---

## 4. buddybank: script e copy

> **Date.** Fino al **16/11/2026** l'invitato può ricevere 80 € (50 + 30 extra). Dal **17/11** torna a 50 €. Ogni contenuto qui sotto ha la versione A e la versione B. Se pubblichi dopo il 16, usa la B.

### 4.1 Script A — "80 euro per 10 euro di spesa" (fino al 16/11)

**Hook**
- Visivo: una banconota da 10 € accanto a un telefono con l'accredito.
- Testo: `10 € → 80 €`.
- Voce: "Fino a domenica buddybank dà ottanta euro a chi apre un conto e spende dieci euro con la carta."

**Beat**
1. "Ottanta euro all'invitato, cinquanta a chi invita."
2. "Servono tre cose: maggiore età, residenza in Italia, non aver avuto un conto UniCredit o buddy dal 1° gennaio 2020."
3. "Spendi almeno dieci euro con la carta entro trenta giorni."
4. "I soldi arrivano entro novanta giorni lavorativi. Non sono immediati."
5. "Codice in bio. Se lo usi, io ricevo cinquanta euro."

**Loop.** "Dieci euro di spesa, ottanta di bonus" riporta all'apertura.

**Caption**
> Fino al 16 novembre: 80 € all'invitato, 50 € a chi invita.
> Servono 18 anni, residenza in Italia e nessun conto UniCredit o buddy dal 01/01/2020.
> Spendi almeno 10 € con la carta entro 30 giorni.
> Accredito entro 90 giorni lavorativi.
> Codice in bio. ADV: se lo usi ricevo 50 €.
> #buddybank #bonus #conto #risparmio #italia

### 4.2 Script B — versione dal 17/11

Stesso schema, con una differenza: "Dal 17 novembre il bonus è cinquanta euro a testa. L'extra da trenta è finito."

### 4.3 Script C — "Le tre cose che nessuno legge"

**Hook**
- Visivo: un PDF di condizioni che scorre velocissimo.
- Testo: `nessuno legge queste`.
- Voce: "Prima di aprire un conto per un bonus, leggi tre righe."

**Beat**
1. "Devi essere maggiorenne e residente in Italia."
2. "Non devi aver avuto un conto UniCredit o buddy dal 1° gennaio 2020."
3. "Devi spendere almeno dieci euro con la carta entro trenta giorni."
4. "Se una di queste manca, il bonus non arriva."
5. "Il resto sono dettagli. Queste sono le condizioni."

**Loop.** "Tre righe, poi decidi" riporta al PDF.

**Caption**
> Prima di aprire un conto per un bonus, controlla tre cose.
> Età e residenza. Non essere già cliente dal 2020. Dieci euro di spesa entro 30 giorni.
> Se manca una, il bonus non parte.
> ADV: uso un codice invito, se lo usi ricevo 50 €.
> #conto #bonus #buddybank #finanzapersonale

### 4.4 Script D — "Non aprirlo se"

**Hook**
- Testo: `non farlo per 50 euro`.
- Voce: "Se stai aprendo un conto solo per cinquanta euro, ascolta trenta secondi."

**Beat**
1. "Se non spendi dieci euro con la carta, il bonus non arriva."
2. "Se sei già cliente dal 2020, non rientri."
3. "Se i soldi ti servono questa settimana, non aspettare: l'accredito arriva entro novanta giorni lavorativi."
4. "Se il conto ti serve comunque, il bonus è un extra sensato."
5. "Se lo apri solo per il bonus, fai i conti prima."

**Loop.** "Cinquanta euro non valgono un conto inutile" chiude.

**Caption**
> Un bonus non è un motivo sufficiente per aprire un conto.
> Se ti serve comunque, meglio prenderlo.
> Se lo fai solo per i 50 €, controlla le condizioni e fai i conti.
> ADV: referral.
> #buddybank #conto #bonus #finanzapersonale

### 4.5 Carosello buddybank — 8 slide

1. **Copertina:** "50 € per te, 50 € per chi ti invita"
2. Come funziona: apri con il codice, spendi 10 €, ricevi il bonus.
3. Chi può: 18+, residente in Italia, non cliente dal 2020.
4. I 10 €: devono essere spesi con la carta entro 30 giorni.
5. Quando arrivano: entro 90 giorni lavorativi.
6. Fino al 16/11: 30 € extra per l'invitato, quindi 80 €.
7. È un bonus una volta sola.
8. CTA: "Codice in bio. ADV: se lo usi ricevo 50 €."

### 4.6 Copy per Facebook e Telegram

**Facebook (solo in gruppi con permesso)**
> Ho verificato le condizioni del bonus buddybank, così non dovete farlo voi.
> 50 € all'invitato e 50 € a chi invita. Fino al 16/11 l'invitato riceve 30 € in più.
> Servono 18 anni, residenza in Italia, non essere clienti UniCredit o buddy dal 2020, e 10 € di spesa con la carta entro 30 giorni.
> L'accredito arriva entro 90 giorni lavorativi.
> Se vi serve un conto, il codice è [INSERIRE CODICE]. Io ricevo 50 € se lo usate. Se non vi serve, ignorate.

**Telegram**
> Bonus buddybank: 50 + 50, più 30 extra all'invitato fino al 16/11.
> Condizioni: 18+, Italia, non clienti dal 2020, 10 € di spesa entro 30 giorni.
> Accredito entro 90 giorni lavorativi.
> Codice: [INSERIRE CODICE]. ADV: referral personale.

---

## 5. Prompt per GPT Image

**Regola:** genera **senza testo**. L'italiano dentro le immagini esce spesso sbagliato. Testi e numeri si aggiungono in Canva o CapCut, con un font tuo.

### Freebuff

**1. Copertina serie 0/600** — 9:16
> Vertical photo, over-the-shoulder view of a developer at a dark wooden desk at night, a laptop glowing with a terminal full of green code, a paper grid of 600 empty checkboxes pinned on the wall, warm desk lamp, shallow depth of field, cinematic realism, 35mm, no text, no logos, no people's faces.

**2. Fattura elettronica** — 9:16
> Top-down vertical photo of a crumpled paper invoice next to a smartphone showing a clean minimal dashboard with one large number, soft morning light, neutral desk, all text blurred and illegible, no logos, editorial photography.

**3. Confronto costi** — 9:16
> Split vertical composition, left side a stack of subscription receipts and coins, right side an empty clean desk with an open laptop, muted green and cream palette, soft shadows, no text, no logos.

**4. Tre task in parallelo** — 9:16
> Overhead shot of one monitor split into three glowing terminal windows in a dark room, mechanical keyboard, coffee cup, cables, cinematic teal and amber lighting, no text, no faces.

**5. Studente** — 9:16
> Vertical photo of a small university dorm desk, inexpensive laptop, notebooks, Italian morning light through a window, unmade bed in the background, no people, no text, warm realistic tones.

**6. Menu QR** — 9:16
> Vertical photo of a small Italian trattoria table, paper menu, small wooden QR stand, espresso cup, red checkered napkin, warm afternoon light, no people, no readable text.

### buddybank

**7. Copertina bonus** — 4:5
> Editorial still life, two espresso cups on a marble counter, a folded receipt, soft window light, Italian bar atmosphere, cream and deep green palette, no people, no text, no logos.

**8. Conto e telefono** — 4:5
> Close-up of a hand holding a smartphone with a minimal banking app interface, all text blurred, warm neutral background, shallow depth of field, realistic, no logos.

**9. Le condizioni** — 4:5
> Close-up of a printed contract with a pen and a highlighter, three lines highlighted, soft desk light, neutral background, all text illegible, no logos.

**10. Sfondo carosello** — 4:5
> Minimal gradient background, warm cream fading into deep green, subtle paper grain, soft vignette, no objects, no text.

---

## 6. Calendario dei primi 7 giorni

Due account separati. Non mescolare le campagne.

| Giorno | Freebuff | buddybank |
|---|---|---|
| Ven 13/11 | TikTok script 1 (0/600), Reels, thread X 1, LinkedIn post 1 | TikTok script A (80 €), storie |
| Sab 14/11 | TikTok script 2 (fatture), 10 risposte in community | Script C (tre cose) |
| Dom 15/11 | TikTok script 8 (recap 47/600) | Script D (non aprirlo se) |
| Lun 16/11 | TikTok script 3 (costi), carosello LinkedIn | Ultimo giorno 80 €: script A in mattinata |
| Mar 17/11 | TikTok script 5 (prompt), thread X 2 | Script B (50 €) |
| Mer 18/11 | TikTok script 7 (menu QR), community | Carosello 8 slide |
| Gio 19/11 | TikTok script 6 (studenti), LinkedIn post 2 | Script "condizioni" versione 50 € |

**Ogni giorno, 30 minuti:** rispondi ai commenti, non mettere link dove non sono richiesti, e annota quanti iscritti arrivano da quale video.

---

## 7. Come misurare se il contenuto funziona

| Metrica | Dove | Soglia |
|---|---|---|
| Iscritti per 1.000 visualizzazioni | TikTok/Reels | 0,5 minimo |
| Prima build completata | Community, domanda diretta | 1 su 3 iscritti |
| Inviti reali | Dashboard referral | Settimanale |
| Spesa con carta | buddybank | 1 su 2 aperture |

Se un video supera cinque volte la media, rifallo in tre varianti la settimana dopo. Se sta sotto 0,5 iscritti per 1.000 visualizzazioni dopo venti video, cambia formato, non aumentare la frequenza.
