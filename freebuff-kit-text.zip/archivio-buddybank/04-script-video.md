# 04 — Script video

Otto script completi, girati con un telefono. Formato verticale 9:16, 25–45 secondi, sottotitoli sempre.

**Prima di girare, leggi `07-compliance.md`.** Ogni video ha bisogno di "ADV" a schermo nei primi 2 secondi e nella didascalia.

---

## Regole di produzione (valgono per tutti)

- **Hook:** la prima frase deve funzionare anche senza audio, quindi va scritta a schermo.
- **Un video, un'idea.** Se stai spiegando due cose, sono due video.
- **Parlato:** frasi da massimo 12 parole. Niente "in questo video vi spiego".
- **Ritmo:** un cambio di inquadratura o un testo nuovo ogni 2–3 secondi.
- **Sottotitoli:** grandi, bianchi con bordo nero, in basso ma sopra la UI di TikTok.
- **Codice:** solo negli ultimi secondi, mai come primo frame.
- **Fonte:** la dicitura "Regolamento: buddy.unicredit.it" va a schermo quando citi una condizione.
- **Set:** finestra alla tua sinistra, telefono all'altezza degli occhi, microfono a clip a 15 cm. Il microfono da 20 € è il salto di qualità più grande che puoi fare.
- **B-roll:** screenshot dell'app e del sito, registrati in verticale. Oscura i dati personali.

---

## Script 1 — "Il bonus non è un guadagno"

**Obiettivo:** fermare la corsa al "50 € gratis" e posizionarti come quello che dice la verità.
**Durata:** 32 s. **Formato:** talking head + testo a schermo.

| Tempo | Video | Voce / testo |
|---|---|---|
| 0–3 s | Primo piano, sguardo in camera. Testo grande: **"50 € NON SONO 50 €"** | "Il bonus da 50 euro non è un guadagno. È un rimborso. E ti spiego perché." |
| 3–10 s | Taglio laterale, stesso set. Compare **"50 − 10 = 40"** | "Per averlo devi aprire il conto e spendere almeno 10 euro con la carta entro 30 giorni." |
| 10–18 s | Torni in primo piano | "Quei 10 euro escono davvero dal tuo conto. Se dovevi comunque comprare qualcosa, il bonus vale 50. Se compri solo per il bonus, vale 40." |
| 18–26 s | Testo: **"FINO A 90 GIORNI LAVORATIVI"** | "E non arrivano subito: l'accredito può richiedere fino a 90 giorni lavorativi. Quasi quattro mesi." |
| 26–32 s | Testo: **"UTILE SE TI SERVE UN CONTO"** + ADV in alto a sinistra | "Quindi: se ti serve un conto nuovo, 40 euro netti sono un buon motivo. Se stai aprendo un conto solo per i 50 euro, stai facendo un affare da 40. Scegli tu." |

**CTA:** "Nel prossimo video ti mostro il passaggio che, se sbagliato, annulla tutto."
**Nota:** non dire "perdi 10 euro". Non li perdi: li spendi. La distinzione è tutto.

---

## Script 2 — "Ho letto il regolamento"

**Obiettivo:** dimostrare competenza in 30 secondi. È il video che genera follow.
**Durata:** 38 s. **Formato:** talking head + PDF a schermo.

| Tempo | Video | Voce / testo |
|---|---|---|
| 0–3 s | Tieni in mano un foglio stampato. Testo: **"3 COSE CHE IL SITO NON DICE"** | "Ho letto le istruzioni della promo al posto tuo. Tre cose che sul sito non vedi in prima pagina." |
| 3–12 s | Primo piano. Testo: **"1. GIÀ CLIENTE = ESCLUSO"** | "Uno: non vale per chi è già cliente UniCredit o buddy. Se hai avuto un rapporto con la banca dal 2020 in poi, sei escluso. Non dipende dal codice." |
| 12–22 s | Taglio. Testo: **"2. BONIFICI NON VALGONO"** | "Due: non valgono bonifici né ricariche. Servono pagamenti con carta: POS, acquisti online o wallet." |
| 22–31 s | Taglio. Testo: **"3. CODICE SOLO ALL'APERTURA"** | "Tre: il codice si inserisce solo durante l'apertura. Se lo aggiungi dopo, non si recupera. Non esiste un link che lo inserisce da solo." |
| 31–38 s | Primo piano, sorriso. ADV a schermo | "Se ti serve un conto, il codice è in bio e ci guadagno qualcosa. Se non ti serve, hai imparato tre cose gratis." |

**CTA:** "Salva il video: sono le tre cose che fanno perdere il bonus."
**Nota:** il foglio in mano non deve essere un finto contratto: stampa davvero la prima pagina delle istruzioni.

---

## Script 3 — Tutorial: dove si inserisce il codice

**Obiettivo:** convertire. È il video con il tasso di salvataggio più alto.
**Durata:** 45 s. **Formato:** screen recording verticale + voiceover.

| Tempo | Video | Voce / testo |
|---|---|---|
| 0–3 s | Schermata home del sito buddy. Testo: **"QUI SI PERDE IL BONUS"** | "Uno dei motivi più comuni per cui il bonus non arriva è questo passaggio." |
| 3–10 s | Tap su "Apri il conto". Testo: **"1. APRI IL CONTO"** | "Apri il conto dal sito o dall'app. Non da un link che ti manda un amico: non esiste." |
| 10–20 s | Compilazione dati (oscura i dati veri). Testo: **"2. CERCA IL CAMPO CODICE"** | "Durante la richiesta c'è un campo per il codice invito. Se non lo vedi, fermati e apri la chat: non completare e inserirlo dopo, perché non si può." |
| 20–30 s | Zoom sul campo, incolla il codice. Testo: **"3. INCOLLA E VERIFICA"** | "Incolla il codice, non riscriverlo a memoria. Poi controlla che sia scritto esattamente com'è, senza spazi." |
| 30–38 s | Schermata di conferma. Testo: **"4. PROSEGUI"** | "Solo quando il codice è confermato, prosegui con la verifica dell'identità." |
| 38–45 s | Primo piano. Testo: **"POI: 10 € DI SPESA IN 30 GIORNI"** + ADV | "Dopo l'apertura hai 30 giorni per spendere almeno 10 euro con la carta. Il codice è nel commento fissato. Se lo usi, io ricevo 50 euro: te lo dico prima." |

**CTA:** "Commento fissato con codice e tre condizioni. Copia, non scrivere."
**Nota:** registra lo schermo con il telefono in verticale, non con la registrazione desktop: viene tagliata male.

---

## Script 4 — "Dieci euro"

**Obiettivo:** spiegare il requisito che fa perdere più bonus. Altissimo salvataggio.
**Durata:** 24 s. **Formato:** whiteboard o foglio sulla scrivania.

| Tempo | Video | Voce / testo |
|---|---|---|
| 0–3 s | Scrivi **"10 €"** su un foglio con un pennarello. Testo: **"IL PREZZO È DIECI EURO"** | "Dieci euro. È questo il prezzo per prendere cinquanta." |
| 3–11 s | Cerchi "10 €". Testo: **"NON 10 AL GIORNO. 10 IN TOTALE."** | "Il regolamento chiede una o più transazioni per almeno 10 euro in totale, entro 30 giorni dall'apertura. Non 10 al giorno. Non 10 al mese. Dieci in tutto." |
| 11–19 s | Barrate le parole "bonifico" e "ricarica". Testo: **"BONIFICI E RICARICHE NON CONTANO"** | "Attenzione: bonifici e ricariche non contano. Deve essere un pagamento con carta, fisica o wallet." |
| 19–24 s | Foglio girato, sorriso. Testo: **"UN ACQUISTO E HAI FINITO"** + ADV | "Quindi: fai la spesa, paghi col telefono, hai finito. Sembra banale, ed è il punto in cui si perde più bonus." |

**CTA:** "Salva questo video: è la parte che tutti dimenticano."

---

## Script 5 — "Questo bonus non è per tutti"

**Obiettivo:** trust + condivisione. Chi è escluso condivide il video a chi gli ha mandato un codice.
**Durata:** 22 s. **Formato:** talking head, tono diretto.

| Tempo | Video | Voce / testo |
|---|---|---|
| 0–3 s | Testo: **"NON È PER TUTTI"** | "Questo bonus non è per tutti. E se sei già cliente UniCredit o buddy, non puoi averlo." |
| 3–12 s | Primo piano. Testo: **"DAL 2020 IN POI = ESCLUSO"** | "Il regolamento esclude chi ha avuto un rapporto con la banca dal primo gennaio 2020. Quindi se sei già cliente, non perdere tempo: non è colpa del codice, sei escluso tu." |
| 12–18 s | Taglio. Testo: **"18+ / RESIDENTI IN ITALIA"** | "Servono almeno 18 anni e residenza in Italia. Sono esclusi anche i dipendenti del gruppo UniCredit." |
| 18–22 s | Primo piano. Testo: **"SE NON SEI CLIENTE, PUOI"** + ADV | "Se invece non lo sei, puoi aprire con il codice di un amico. Il mio è in bio." |

**CTA:** "Giralo a chi ti ha mandato un codice senza dirti che ci guadagnava."
**Nota:** è il video più "condivisibile". Non metterci il codice a schermo: la CTA è la condivisione, non la conversione.

---

## Script 6 — "Quanto tempo ci vuole"

**Obiettivo:** gestire le aspettative e ridurre i commenti ostili.
**Durata:** 33 s. **Formato:** timeline disegnata a mano o in overlay.

| Tempo | Video | Voce / testo |
|---|---|---|
| 0–3 s | Testo: **"DAL CLICK AL BONUS: QUANTO?"** | "Quanto tempo ci vuole per vedere i 50 euro? Più di quanto pensi." |
| 3–11 s | Compare "GIORNO 0". Testo: **"APRI IL CONTO"** | "Giorno zero: apri il conto con il codice." |
| 11–19 s | Compare "GIORNI SUCCESSIVI". Testo: **"ARRIVA LA CARTA"** | "Nei giorni successivi arriva la carta, se la chiedi fisica: 3,50 € di emissione e 5,70 € di spedizione ordinaria." |
| 19–26 s | Compare "ENTRO 30 GIORNI". Testo: **"SPENDI 10 €"** | "Entro 30 giorni devi fare almeno 10 euro di spesa con la carta." |
| 26–33 s | Compare "FINO A 90 GIORNI LAVORATIVI". Testo: **"ACCREDITO"** + ADV | "Da lì, l'accredito arriva entro 90 giorni lavorativi. Dal click al bonifico possono passare quattro mesi. Se hai urgenza di quei soldi, non è lo strumento giusto." |

**CTA:** "Il calendario esatto è nel commento fissato."

---

## Script 7 — "Quando NON conviene"

**Obiettivo:** il video che ti distingue da tutti gli altri. È quello che le persone salvano e mandano agli amici.
**Durata:** 42 s. **Formato:** talking head, elenco a schermo.

| Tempo | Video | Voce / testo |
|---|---|---|
| 0–3 s | Testo: **"NON APRIRLO SE..."** | "Ti dico quando non conviene aprire buddybank, anche se ci guadagno qualcosa se lo fai." |
| 3–14 s | Testo: **"1. SEI GIÀ CLIENTE"** | "Non conviene se sei già cliente UniCredit o buddy: sei escluso e non prendi nulla. Non conviene se ti serve una filiale fisica per operazioni che l'app non copre. Non conviene se non vuoi usare una carta di debito." |
| 14–24 s | Testo: **"2. CERCHI INVESTIMENTI"** | "Non conviene se stai cercando un conto per investire: questo è un conto corrente, non un conto titoli. E non conviene se hai bisogno di quei 50 euro subito." |
| 24–36 s | Testo: **"QUANDO INVECE HA SENSO"** | "Ha senso se sei senza conto o paghi un canone, se usi la carta ogni mese e se ti va bene gestire tutto da app. In quel caso 50 euro netti sono un motivo concreto per cambiare." |
| 36–42 s | Primo piano. Testo: **"NON È UN CONSIGLIO FINANZIARIO"** + ADV | "Questo non è un consiglio finanziario personalizzato. È il regolamento letto ad alta voce. Se rientri nel secondo gruppo, il codice è in bio." |

**CTA:** "Dimmi nei commenti quale dei due gruppi sei."
**Nota:** è il video che risponde all'obiezione "mi stai solo vendendo". Non attenuarlo: la parte "non conviene" deve durare più della parte "conviene".

---

## Script 8 — "Sì, ci guadagno" (video fissato)

**Obiettivo:** disclosure che costruisce fiducia invece di distruggerla. Va fissato in cima al profilo.
**Durata:** 26 s. **Formato:** talking head, set neutro, tono calmo.

| Tempo | Video | Voce / testo |
|---|---|---|
| 0–3 s | Testo: **"SÌ, CI GUADAGNO. TE LO DICO PRIMA."** + ADV | "Sì, se usi il mio codice io ricevo 50 euro. Te lo dico prima, non dopo." |
| 3–12 s | Primo piano | "Funziona così: tu prendi 50 euro netti se apri il conto e fai almeno 10 euro di spesa entro 30 giorni. Io prendo 50 euro quando tu rispetti quelle condizioni." |
| 12–19 s | Taglio. Testo: **"A TE NON COSTA NULLA IN PIÙ"** | "A te non costa niente in più: il bonus per te è lo stesso, con o senza di me. Non lavoro per buddybank e non sono UniCredit." |
| 19–26 s | Primo piano. Testo: **"SE NON TI VA, I VIDEO RESTANO UTILI"** | "Sono un cliente che ha letto il regolamento e te lo sta spiegando. Se ti va, il codice è in bio. Se non ti va, i video restano utili lo stesso." |

**CTA:** "Domande? Scrivimi nei commenti, rispondo."
**Nota:** non sorridere in modo forzato e non usare un tono da scusa. È una dichiarazione, non un pentimento.

---

## Quattro concept extra (solo hook + trattamento)

### 9. "Il conto è gratis. La carta no."
Hook: "Il canone è zero. La carta fisica, però, non è gratis."
Trattamento: 25 s. Mostri la pagina costi: 3,50 € di emissione + 5,70 € di spedizione. Poi la digitale a 0 €. CTA: "Se non ti serve il plastico, scegli la digitale." Utile, concreto, nessuna promessa.

### 10. "POV: ti mandano un codice senza spiegarti niente"
Hook: testata sul cuscino, messaggio a schermo: *"ehi, usa il mio codice che prendiamo 50€ a testa"*.
Trattamento: 15 s. Sketch. Poi voce fuori campo: "Prima di usarlo, chiedi tre cose: quanto vale, cosa devi fare, chi ci guadagna." CTA: "Le tre domande sono nel video precedente."

### 11. "Le tre domande prima di usare un codice"
Hook: "Prima di inserire il codice di uno sconosciuto, fai queste tre domande."
Trattamento: 30 s. (1) Il bonus è condizionato a cosa? (2) Quanto tempo per l'accredito? (3) Chi ci guadagna? CTA: "Se non sanno rispondere, non usare il codice."

### 12. "Il bonus più noioso d'Italia"
Hook: "Questa è la promo più noiosa d'Italia. E proprio per questo funziona."
Trattamento: 28 s. Ironia sul regolamento di 11 pagine, sulla ritenuta del 26%, sui 90 giorni. Poi: "Nessuno ti regala niente: ti danno 50 euro per aprire un conto e usarlo. Se ti serve, è un buon motivo." CTA: "Il riassunto in 8 slide è nel carosello."

---

## Produzione: il batch da 2 ore

Fai così una volta a settimana, invece di girare ogni giorno.

| Blocco | Tempo | Cosa fai |
|---|---|---|
| 1. Setup | 15 min | Luce alla finestra, telefono su treppiede all'altezza occhi, microfono, due magliette neutre |
| 2. Gira | 45 min | 4 script. Due take a testa. Non rileggere: parla come spiegheresti a un amico |
| 3. B-roll | 20 min | Registrazioni schermo di sito e app, mani che scorrono, foglio e pennarello |
| 4. Montaggio | 30 min | CapCut: taglia i silenzi, sottotitoli automatici, un testo grande per concetto |
| 5. Copertine | 10 min | Stesso font, stesso colore, 3–5 parole. La copertina è il 50% del click |

**Editing:** niente transizioni strane, niente musica forte sotto la voce. Una traccia lo-fi al 10% di volume basta. I sottotitoli devono essere corretti a mano: gli errori automatici su "accredito" e "domiciliazione" sono garantiti.
