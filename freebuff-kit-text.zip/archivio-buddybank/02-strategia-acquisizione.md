# 02 — Strategia di acquisizione

## La scommessa

Il mercato del referral bancario è saturo di post uguali: "50 € GRATIS, codice in bio". Funzionano per chi è già a caccia di bonus, non per chi non ci ha mai pensato. Il nostro vantaggio non è il codice: è **la competenza percepita**.

Posizionamento in una frase:

> **"Sono il tizio che legge i regolamenti delle banche, così tu non devi farlo."**

Da qui discendono tre conseguenze operative:
- Il contenuto deve avere valore anche senza codice (altrimenti è volantino).
- Devi dire anche quando **non** conviene (è ciò che genera fiducia e salvataggi).
- Devi dichiarare il tuo guadagno prima che lo chiedano (è ciò che ti protegge e ti distingue).

---

## Pubblico

### Segmento 1 — "Primo conto" (18–24)
Studentesse e studenti, primo lavoro, primo affitto. Spesso hanno già una carta prepagata o il conto dei genitori. Non confrontano i canoni: confrontano la friction (app, Apple Pay, carta che arriva a casa).

- **Cosa cercano:** "conto gratis per studenti", "carta per acquisti online", "come aprire un conto a 18 anni".
- **Dove sono:** TikTok, Instagram, YouTube Shorts.
- **Cosa li blocca:** non capiscono cosa sia un codice invito e temono di sbagliare.
- **Angolo:** tutorial passo-passo, zero matematica, linguaggio semplice.
- **Valore per te:** reach e condivisione, conversione media.

### Segmento 2 — "Il conto che costa" (25–35)
Giovani lavoratori, già bancarizzati, che pagano 5–10 € al mese di canone e non ci pensano più. Sono il pubblico con **più valore**: possono aprire davvero e usare la carta.

- **Cosa cercano:** "quanto costa il mio conto", "conviene cambiare banca", "conto a canone zero".
- **Dove sono:** TikTok (ricerca), Instagram, Google, YouTube.
- **Cosa li blocca:** paura di cambiare, domiciliazioni, stipendio.
- **Angolo:** confronto onesto, "quando NON conviene", costi nascosti (carta fisica 3,50 € + 5,70 €), checklist.
- **Valore per te:** conversione alta, meno views.

### Segmento 3 — "Cacciatori di bonus" (25–45)
Conoscono già la promo, cercano il codice migliore, confrontano forum. Sono su Inforge, Telegram, gruppi Facebook.

- **Cosa cercano:** "buddybank bonus 50", "codice invito valido".
- **Cosa li blocca:** diffidenza, esperienze passate di accrediti lenti.
- **Angolo:** trasparenza su tempi e condizioni, nessuna promessa.
- **Valore per te:** volume rapido, ma spesso già clienti (quindi esclusi) e poco reach. Non è il pubblico su cui costruire.

**Non è pubblico:** minorenni, residenti all'estero, chi è già cliente UniCredit/buddy dal 2020, dipendenti del gruppo. Dillo nei contenuti: ti evita commenti arrabbiati e segnalazioni.

---

## Canali: dove sì, dove no

| Canale | Ruolo | Sforzo | Regole da rispettare | Verdetto |
|---|---|---|---|---|
| **TikTok** | Reach principale, ricerca interna | 50% | Disclosure ADV, no claim ingannevoli, no branded content finanziario senza brand approvato | **Sì, primario** |
| **Instagram Reels** | Reach + fiducia, pubblico 25–35 | 25% | Disclosure "ADV" a inizio didascalia, entro i primi 3 hashtag | **Sì, secondario** |
| **YouTube Shorts** | Ricerca ("come funziona bonus buddybank") | 10% | Titolo onesto, descrizione con condizioni | **Sì, riciclo** |
| **Inforge — "Guadagnare con Promozioni"** | Intento altissimo, thread strutturato | 5% | Regolamento area Money, formato del thread, nessun compenso extra | **Sì, un thread** |
| **Gruppi Facebook offerte/bonus** | Volume, pubblico più adulto | 5% | Permesso dell'admin, no link non richiesti, no flood | **Sì, se autorizzato** |
| **Telegram** | Codice e aggiornamenti per chi già ti segue | 5% | Solo canali esistenti, mai DM a freddo | **Sì, dopo 300 follower** |
| **Reddit** | Ascolto, domande, reputazione | 0% promo | r/ItaliaPersonalFinance: regola 4 vieta referral e pubblicità, regola 7 vieta contenuti AI. Ban permanente | **No promo. Solo risposte senza link** |
| **Discord** | Comunità giovani | 0–5% | Solo server con canale #promo/referral esplicito; leggere #rules prima | **Solo se esiste il canale** |

### Perché Reddit non si usa per il codice
Non è una preferenza, è una regola scritta. Il subreddit italiano di finanza personale dichiara: "Sono vietate la pubblicità, i referral, le ricerche di mercato, i sondaggi... Ogni infrazione considerata spam comporta il ban permanente senza appello." Inoltre vieta i contenuti generati da AI. Un post con il codice viene rimosso e l'account bruciato in un giorno. Il costo opportunità è altissimo e il beneficio è vicino a zero.

Su Reddit puoi:
- leggere i thread "conviene buddybank?" e capire le obiezioni reali (materiale d'oro per i video);
- rispondere a domande tecniche **senza link e senza codice**;
- citare il regolamento quando qualcuno chiede.
Se poi qualcuno ti chiede il codice in privato, rispondi solo se la richiesta è esplicita: ma sappi che anche i DM non richiesti sono vietati dalle regole della piattaforma.

---

## Evidenze: cosa funziona (e cosa no)

Queste sono osservazioni tratte dalle fonti consultate, non benchmark misurati. Servono a orientare le scelte, non a promettere risultati.

| Evidenza osservata | Fonte | Cosa implica per te |
|---|---|---|
| Esiste una sezione forum dedicata alle promo di conti e carte, con oltre 1.500 discussioni e 10.500 messaggi | Inforge, sezione "Guadagnare con Promozioni" | La domanda esiste ed è concentrata. Un thread ben fatto può portare aperture, ma è pubblico di cacciatori: non costruirci sopra il brand |
| I thread che ricevono risposte hanno titolo con banca, importo, scadenza e limite inviti, e corpo con step numerati e link al regolamento | Thread Inforge su buddybank, Fineco, Revolut | Il format funziona più dell'entusiasmo. Copia la struttura, non il tono |
| Molti thread offrono un "bonus extra da parte mia" | Thread Inforge | È la pratica più diffusa e la più rischiosa: accordo parallelo non previsto dalla promo. Non farlo |
| Le regole di r/ItaliaPersonalFinance sono progressivamente diventate più severe: oggi referral e pubblicità sono vietati, con ban permanente | Regole del subreddit | Reddit non è un canale di acquisizione. Usalo per ascoltare |
| Utenti Reddit raccontano ritardi o mancati accrediti del bonus buddybank | Thread "Bonus Buddybank, tutta una truffa?" | Il tema "tempi" è una ferita aperta: affrontarlo prima che lo chiedano è un vantaggio, non un rischio |
| In Italia i contenuti finanziari su TikTok interessano anche la fascia 25–54, non solo la Gen Z | Report Intarget/TikTok "Follow the Money" | Non impostare tutto su un tono adolescente: il pubblico che apre il conto è più adulto di quanto sembri |
| Le banche italiane usano la comicità sui social (es. ING "Fun in Finance") | Comunicati ING 2025–2026 | L'umorismo funziona per un brand che ha già fiducia. Per un creator singolo, la competenza è più difendibile dell'ironia |
| Dal 2026 le linee guida AGCOM equiparano codice referral e affiliazione a pubblicità | FAQ AGCOM per influencer, marzo 2026 | La disclosure non è opzionale, anche con pochi follower |

**Il pattern che emerge:** vince chi abbassa l'aspettativa e alza la specificità. Perde chi urla l'importo. I post generici ottengono visualizzazioni e zero aperture; i post con condizioni, tempi e limiti ottengono salvataggi e domande — che sono il vero segnale di acquisto.

---

## Imbuto

```
Video (reach)
   ↓ 1–3% visita profilo
Profilo + video fissato "come guadagno"
   ↓ 5–15% legge bio / commento fissato
Codice copiato
   ↓
Apertura conto con codice
   ↓
Spesa ≥ 10 € entro 30 giorni  ← qui si perde la maggior parte
   ↓
Accredito entro 90 giorni lavorativi
```

Due punti di perdita su cui lavorare:
1. **Tra "visto il video" e "capito cosa fare".** Si risolve con il tutorial sull'inserimento del codice.
2. **Tra "aperto il conto" e "speso 10 €".** Si risolve con un contenuto dedicato alla scadenza dei 30 giorni e con un promemoria non invadente (solo a chi ti ha scritto).

---

## Numeri: come misurarli senza inventarli

Non esistono benchmark pubblici affidabili per "referral bancario da TikTok in Italia". Diffida di chi ti dà percentuali precise. Usa queste formule e costruisci il tuo dato in 3 settimane:

- **Tasso di visita profilo** = visite profilo / visualizzazioni
- **Tasso di codice** = aperture con codice / visite profilo
- **Tasso di completamento** = aperture con codice / aperture totali
- **Costo per acquisizione organica** = ore lavorate × valore ora / aperture con codice

Punto di partenza realistico da cui imparare, non da promettere: 30 video possono produrre da 0 a 10 aperture. Il numero vero lo scopri solo pubblicando. Se dopo 20 video hai zero aperture ma buoni salvataggi, il problema è la CTA o il profilo, non il canale. Se hai zero salvataggi, il problema è il contenuto.

**Soglia per valutare il paid:** non spendere in ads finché l'organico non produce almeno **1 apertura a settimana** in modo stabile. Prima di pagare per portare traffico, devi sapere che il traffico converte.

---

## Perché niente pubblicità a pagamento all'inizio

Tre motivi concreti:

1. **Chi paga è la banca, non tu.** La promo è di UniCredit. Un'inserzione a tuo nome che promuove un prodotto bancario tocca le policy sui servizi finanziari (licenza, targeting 18+, disclosure) e può essere rifiutata o rimossa.
2. **Il costo per acquisizione rischia di superare il ricavo.** Incassi 50 € netti per apertura complete. Con un CPA freddo in Italia su finanza, è facile spendere più di 50 € per un'apertura, e molte aperture non completano la spesa dei 10 €.
3. **Il profilo è giovane.** Un account senza storico che fa ads su una banca viene percepito come truffa. Prima costruisci prova (video, commenti, testimonianze), poi eventualmente paghi.

**Quando potresti valutare il paid:** dopo 8–10 settimane, con almeno 10 aperture organiche, un video con retention sopra la mediana e — prima di tutto — un **ok scritto dell'assistenza buddy** alla promozione a pagamento del tuo codice. Se manca l'ok, non si fa.

---

## Rischi e risposte

| Rischio | Probabilità | Risposta |
|---|---|---|
| Commenti "truffa" / "non arriva mai" | Alta | Video dedicato ai tempi (90 giorni lavorativi) + non cancellare i commenti negativi, rispondi con i fatti |
| Ban o rimozione per promo non dichiarata | Media | ADV nei primi 2 secondi, didascalia, bio, video "come guadagno" |
| Promo modificata o prorogata | Media | Ri-verifica prima di ogni batch, non riciclare contenuti vecchi |
| Codice non tracciato | Bassa | Un solo codice, tutorial sull'inserimento, chiedi conferma a chi apre |
| Saturazione del tema | Alta | Allarga il contenuto a conti, costi, risparmio: il profilo sopravvive alla promo |
| Esperienza utente negativa (accrediti lenti) | Media | Non promettere date, non difendere la banca, racconta il regolamento |

---

## Le 10 cose da non fare

1. Non dire "guadagno garantito", "soldi facili", "bonus sicuro".
2. Non promettere 80 € dopo il 16/11/2026.
3. Non offrire compensi tuoi ("ti rimborso 10 €"): è fuori dalle regole e può invalidare la partecipazione.
4. Non creare account finti o inviti finti.
5. Non comprare follower, like o commenti.
6. Non mandare DM a chi non ti ha chiesto nulla.
7. Non postare lo stesso testo in 10 gruppi lo stesso giorno.
8. Non usare "buddybank" o "UniCredit" nel nome o nell'handle.
9. Non fingersi la banca, un consulente o un dipendente.
10. Non pubblicare screenshot di accrediti che non hai ricevuto davvero.
