# 07 — Compliance e claim

Questa è la parte che protegge il progetto. Non è burocrazia: è ciò che ti distingue da chi viene bannato o segnalato.

**Regola unica:** se un contenuto può farti guadagnare solo perché nasconde qualcosa, quel contenuto va rifatto.

---

## 1. La disclosure è obbligatoria

Dal 2026 in Italia le linee guida AGCOM sugli influencer considerano pubblicità qualsiasi contenuto con un **beneficio economico**, inclusi **codici referral e affiliazioni**. Non esiste una soglia di follower: anche un account piccolo deve dichiarare.

**Come si dichiara, concretamente:**

| Dove | Cosa scrivere |
|---|---|
| Video | "ADV" in sovrimpressione **nelle prime scene**, non alla fine |
| Didascalia | "ADV" o "Pubblicità" **all'inizio**, prima del testo |
| Hashtag | #adv o #pubblicità **entro i primi tre** |
| Bio | "Se usi i miei codici, a volte guadagno. ADV quando promuovo." |
| Video fissato | Spiegazione esplicita del guadagno |

**Perché non basta #ad in fondo:** la norma chiede che la natura commerciale sia riconoscibile **senza click aggiuntivi**. Un hashtag sepolto in fondo a 15 hashtag non lo è.

---

## 2. Le frasi ammesse

Queste puoi usarle, perché sono verificabili sul regolamento:

- "50 € netti all'invitato e 50 € netti all'invitante, secondo il regolamento buddy Club 100."
- "Il bonus è condizionato: serve aprire con il codice e spendere almeno 10 € con carta entro 30 giorni."
- "L'accredito arriva entro 90 giorni lavorativi."
- "Sono esclusi i già clienti UniCredit/buddy con rapporti dal 01/01/2020."
- "Il limite è di 100 inviti per un massimo di 5.000 €."
- "I 50 € sono già al netto della ritenuta del 26%."
- "Non lavoro per buddybank e non sono UniCredit."
- "Se usi il mio codice ricevo 50 €."

---

## 3. Le frasi da non usare mai

| Non dire | Perché | Dì invece |
|---|---|---|
| "50 € gratis" | Nasconde la condizione della spesa | "50 € netti, con 10 € di spesa entro 30 giorni" |
| "Guadagno garantito" | È falso: il bonus è condizionato e verificato dalla banca | "Bonus condizionato al rispetto dei requisiti" |
| "Soldi facili" / "Soldi subito" | Induce aspettative false | "Accredito fino a 90 giorni lavorativi" |
| "Bonus sicuro" | Nessuna garanzia | "Se rispetti i requisiti previsti dal regolamento" |
| "Conto gratis per sempre" | Il canone zero dipende dalle condizioni contrattuali vigenti | "Canone 0 € secondo le condizioni contrattuali vigenti" |
| "Fino a 5.000 €" come promessa | È un tetto teorico con 100 inviti | "Fino a un massimo di 5.000 €, con 100 inviti" |
| "Basta aprire il conto" | Manca il requisito della spesa | "Serve anche una spesa di almeno 10 € con carta" |
| "Ti rimborso 10 €" / "ti do 20 € extra" | Accordi paralleli non previsti dalla promo, rischio di esclusione | Non farlo |
| "Sono di buddybank" | Impersonificazione | "Sono un cliente indipendente" |
| "Investi con questo conto" | È un conto corrente, non un prodotto di investimento | "È un conto corrente, non un conto titoli" |

---

## 4. Le condizioni minime in ogni contenuto

Ogni video o post che cita il bonus deve contenere, almeno in descrizione o commento fissato:

> Bonus 50 € netti per invitato e invitante. Iniziativa buddy Club 100 valida fino al 20/01/2027. Richiesta apertura conto/carta con codice invito e spesa minima di 10 € con carta entro 30 giorni. Accredito entro 90 giorni lavorativi. Esclusi i già clienti UniCredit/buddy con rapporti dal 01/01/2020. Regolamento su buddy.unicredit.it.

Puoi accorciarla nel video, ma **non può mancare nella descrizione**. È la differenza tra "informazione" e "pubblicità ingannevole".

---

## 5. Regole delle piattaforme

### TikTok
- Il **branded content** che promuove servizi finanziari richiede l'accesso al programma brand partner di TikTok. Tu non sei la banca: **non usare il toggle "contenuto commerciale sponsorizzato da un brand"** indicando UniCredit, perché dichiarerebbe un accordo che non hai.
- Usa invece la disclosure testuale "ADV" e la bio. È la pratica corretta per un referral personale.
- Non fare claim su rendimenti, non usare "investimento" per un conto corrente.
- Se un video viene rimosso, non ripubblicarlo identico: chiedi il riesame e correggi il claim.

### Instagram / Meta
- Le inserzioni su prodotti finanziari richiedono autorizzazioni e targeting 18+. Un post organico con codice referral non è un'inserzione, ma resta pubblicità: disclosure obbligatoria.
- Non usare "collaborazione" con il profilo della banca se non hai un accordo: è pubblicità ingannevole.

### Reddit
- r/ItaliaPersonalFinance vieta referral, pubblicità e contenuti AI. Rispetta la regola: nessun codice, nessun link.
- Non creare account multipli per aggirare il ban: è contro i termini di Reddit e peggiora la situazione.

### Inforge
- Rispetta il regolamento dell'area Money e il formato del thread.
- Non offrire bonus extra tuoi.
- Un thread per promo, aggiornato quando cambia.

### Gruppi Facebook
- Chiedi il permesso all'admin **prima**. Se il gruppo vieta la promozione, non pubblicare.
- Non taggare persone, non inviare DM agli iscritti.

---

## 6. Il rapporto con la banca

Non sei un promoter autorizzato. Sei un cliente che partecipa a un'iniziativa. Questo significa:

- **Non** puoi dire di essere un partner, un ambasciatore o un dipendente.
- **Non** puoi usare il logo buddybank/UniCredit come immagine del profilo o nei materiali come se fossero tuoi.
- **Non** puoi modificare il regolamento o "interpretarlo" a tuo favore.
- **Puoi** citare la promo, linkare il regolamento e condividere il tuo codice, come prevede l'iniziativa.
- **Prima di una campagna a pagamento**, chiedi conferma scritta all'assistenza. Non dare per scontato che sia consentito.

Il regolamento richiama il Codice di Condotta della banca e prevede l'esclusione in caso di partecipazione illecita, fraudolenta o non consentita. Un contenuto che promette cose false è anche un rischio contrattuale, non solo pubblicitario.

---

## 7. Fisco, in due righe

I 50 € sono già **netti**: la banca applica la ritenuta del 26% e ti accredita il netto. Non devi fare nulla per quello.

Se l'attività diventa sistematica (contenuti sponsorizzati, partita IVA, altri redditi da creator), il quadro cambia. In quel caso serve un commercialista. Non improvvisare una risposta in un video.

**Nei contenuti non parlare di tasse oltre questa frase:** "I 50 € sono già netti, la ritenuta è applicata dalla banca."

---

## 8. Privacy

- Non pubblicare screenshot con IBAN, nome, indirizzo, numero di conto o saldo.
- Se mostri l'app, oscura i dati personali con un rettangolo nero, non con una sfocatura (si può reversare).
- Non raccogliere email o dati in un form tuo: non serve e ti espone al GDPR.
- Non pubblicare conversazioni con l'assistenza che contengono i tuoi dati.

---

## 9. Cosa fare se qualcosa va storto

| Situazione | Azione |
|---|---|
| Video rimosso | Leggi il motivo, correggi il claim, chiedi riesame. Non ricaricare identico |
| Commenti "truffa" | Rispondi con il link al regolamento e i tempi reali. Non cancellare |
| Utente dice che non ha ricevuto il bonus | Non difendere la banca. Chiedi se ha rispettato i requisiti, suggerisci il ticket in app |
| Promo modificata | Aggiorna i file, metti una storia/posto di aggiornamento, non lasciare contenuti vecchi online |
| Account limitato | Sospendi le pubblicazioni 48 ore, controlla le linee guida, rimuovi i contenuti con claim forti |
| Ti chiedono il codice in DM | Rispondi solo se la richiesta è esplicita, con le condizioni allegate |

---

## 10. Blocco disclaimer pronto

Copia e incolla dove serve:

```
ADV — Contenuto pubblicitario. Se usi il mio codice invito ricevo 50 €.
Non sono un dipendente né un promoter di UniCredit/buddy.
Bonus 50 € netti per invitato e invitante, condizionato ad apertura con codice e spesa minima di 10 € con carta entro 30 giorni. Accredito entro 90 giorni lavorativi. Esclusi i già clienti UniCredit/buddy con rapporti dal 01/01/2020. Iniziativa valida fino al 20/01/2027. Regolamento: buddy.unicredit.it
Non è consulenza finanziaria.
```

Questo blocco è lungo. Va benissimo in descrizione o nel commento fissato: su temi economici, la lunghezza è un segnale di serietà, non un difetto.
