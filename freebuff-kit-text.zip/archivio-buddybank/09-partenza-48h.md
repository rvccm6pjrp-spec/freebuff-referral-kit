# 09 — Partenza 48 ore: piano €80

> Se non vuoi apparire o girare, usa `10-senza-volto.md`: stessi contenuti, formato carosello e screen recording, zero volto.

**Oggi è giovedì 12 novembre 2026. Gli 80 € valgono per chi diventa cliente entro lunedì 16/11/2026.**

Il bonus extra da 30 € è per **l'invitato**: 50 € + 30 € = 80 €. Chi invita riceve **50 € per amico**, non 80. Nei contenuti puoi dire "80 € per chi apre", mai "prendiamo 80 a testa".

Dopo lunedì 16, ogni contenuto con "80 €" va aggiornato a 50 €. Non cancellarlo: modifica la didascalia e fissa un commento con l'aggiornamento.

---

## Account: nome, handle, bio

### TikTok
| Campo | Valore |
|---|---|
| Nome visualizzato | `Due Conti \| 80€ e conti spiegati` |
| Username | `@dueconti` → se occupato `@dueconti_it` |
| Bio (80 caratteri) | `Leggo i regolamenti. Tu risparmi tempo. Codice in bio: ci guadagno.` |
| Link | pagina ufficiale buddy |

### X
| Campo | Valore |
|---|---|
| Nome | `Due Conti` |
| Handle | `@dueconti_it` (max 15 caratteri, solo lettere/numeri/underscore) |
| Bio (160 caratteri) | `Leggo i regolamenti delle banche così non devi farlo tu. Bonus, conti, costi veri. Se usi i miei codici ricevo un bonus. ADV.` |
| Location | `Italia` |

**Perché lo stesso handle:** X non accetta il punto, TikTok sì. Se vuoi lo stesso nome ovunque, usa `@dueconti_it` o `@duecontiita`. Non usare `@dueconti.ita`.

**Alternative se `dueconti` è occupato ovunque:** `@carta_canta` (Carta Canta) o `@eurotti`. Stessa logica: niente "buddybank", niente "bonus50", niente "guadagnafacile".

### Foto profilo (costo 0)
- Mezzo busto, sfondo a tinta unita (muro bianco o armadio), luce dalla finestra davanti a te.
- Testa che occupa il 60% del cerchio, sguardo in camera, espressione neutra o mezzo sorriso.
- Maglietta tinta unita, no loghi, no occhiali da sole, no filtro.
- Scatta 20 foto in 5 minuti, scegli quella in cui sembri una persona che spiega, non che vende.
- Stessa foto su TikTok e X. Riconoscibilità prima di tutto.

**Non usare:** il logo di buddybank, un'immagine stock, un avatar AI, una foto con la banca sullo sfondo.

---

## I 4 video da girare oggi

Formato: verticale, 20–35 secondi, sottotitoli grandi, "ADV" a schermo nei primi 2 secondi. Un cambio di inquadratura o di testo ogni 2 secondi.

### Video 1 — "Ci sono 80 euro sul tavolo"

**Hook (0–2 s):** testo a schermo **"80 € SUL TAVOLO. SCADONO LUNEDÌ."**
**Voce:** "Ci sono 80 euro sul tavolo. Scadono lunedì."

| Tempo | Inquadratura | Voce / testo |
|---|---|---|
| 0–2 s | Primo piano, testo grande | "80 € sul tavolo. Scadono lunedì." |
| 2–8 s | Taglio laterale | "Sono il bonus di buddybank per chi apre un conto con un codice invito: 50 euro più 30 extra, accreditati separatamente." |
| 8–16 s | Testo: **"10 € CON CARTA / 30 GIORNI"** | "Per prenderli devi aprire entro il 16 novembre e spendere almeno 10 euro con la carta entro 30 giorni. Bonifici e ricariche non contano." |
| 16–23 s | Testo: **"GIÀ CLIENTE? ESCLUSO"** | "Se sei già cliente UniCredit o buddy dal 2020, non li prendi. Non dipende dal codice." |
| 23–30 s | Testo: **"FINO A 90 GIORNI LAVORATIVI"** | "E non arrivano subito: fino a 90 giorni lavorativi. Il codice è in bio. Se lo usi io ricevo 50 euro. Hai tempo fino a lunedì." |

**Didascalia:**
```
ADV | 80€ per chi apre un conto buddybank entro lunedì 16/11.

50€ + 30€ extra per l'invitato. Per averli: apertura con codice + almeno 10€ di spesa con carta entro 30 giorni. Accredito fino a 90 giorni lavorativi. Esclusi i già clienti UniCredit/buddy dal 2020.

Codice in bio. Se lo usi ricevo 50€.

#adv #buddybank #bonus #contocorrente #soldi
```

---

### Video 2 — "Chi ti manda il codice prende 50 euro"

**Hook (0–2 s):** **"CHI TI MANDA IL CODICE PRENDE 50 €."**
**Voce:** "Se ti hanno mandato un codice per buddybank, chi te lo manda prende 50 euro."

| Tempo | Inquadratura | Voce / testo |
|---|---|---|
| 0–2 s | Primo piano, testo grande | "Chi ti manda il codice prende 50 €." |
| 2–9 s | Taglio | "Non è un segreto: è scritto nel regolamento. Per ogni amico che apre e spende 10 euro, l'invitante riceve 50 euro." |
| 9–17 s | Testo: **"TU PUOI PRENDERNE 80"** | "Tu, se apri entro lunedì 16, puoi prenderne 80: 50 più 30 extra." |
| 17–25 s | Testo: **"MA DEVI FARE QUESTO"** | "Devi aprire con il codice e spendere almeno 10 euro con la carta entro 30 giorni. Se sei già cliente dal 2020, niente." |
| 25–30 s | Primo piano | "Ora lo sai. Se ti serve, il mio codice è in bio. Se lo usi, quei 50 euro vanno a me: te lo dico prima." |

**Didascalia:**
```
ADV | Se ti mandano un codice referral, chi te lo manda prende un bonus. Ecco quanto, secondo il regolamento buddybank.

Invitato: fino a 80€ (50 + 30 extra) aprendo entro il 16/11.
Invitante: 50€ per amico.
Requisiti: apertura con codice + 10€ di spesa con carta entro 30 giorni. Accredito fino a 90 giorni lavorativi. Esclusi i già clienti UniCredit/buddy dal 2020.

Codice in bio. Se lo usi ricevo 50€.
#adv #buddybank #bonus #contocorrente
```

---

### Video 3 — Tutorial: dove si mette il codice

**Hook (0–2 s):** **"SE SBAGLI QUESTA SCHERMATA, GLI 80 € NON ARRIVANO."**
**Formato:** registrazione schermo verticale + voiceover.

| Tempo | Schermata | Voce / testo |
|---|---|---|
| 0–2 s | Home del sito buddy, testo grande | "Se sbagli questa schermata, gli 80 euro non arrivano." |
| 2–10 s | Tap su "Apri il conto" | "Apri il conto dal sito o dall'app. Durante la richiesta c'è un campo per il codice invito." |
| 10–20 s | Zoom sul campo, incolla il codice | "Incolla il codice, non riscriverlo. Controlla che non ci siano spazi." |
| 20–27 s | Testo: **"NON DOPO. DURANTE."** | "Se non vedi il campo, fermati e apri la chat. Dopo l'apertura non si può più inserire." |
| 27–35 s | Testo: **"POI: 10 € CON CARTA / 30 GIORNI"** | "Poi hai 30 giorni per spendere almeno 10 euro con la carta. Il codice è nel commento fissato. Se lo usi ricevo 50 euro." |

**Didascalia:**
```
ADV | Dove si inserisce il codice, passo per passo.

Il campo compare durante la richiesta di apertura. Dopo non è recuperabile. Poi servono almeno 10€ di spesa con carta entro 30 giorni.

Codice nel commento fissato. Se lo usi ricevo 50€.
#adv #buddybank #tutorial #bonus #contocorrente
```

---

### Video 4 — "Dieci euro"

**Hook (0–2 s):** scrivi **"10 €"** su un foglio. Testo: **"IL PREZZO È 10 €."**
**Voce:** "Dieci euro. È tutto quello che devi spendere."

| Tempo | Inquadratura | Voce / testo |
|---|---|---|
| 0–2 s | Foglio con "10 €" | "Dieci euro. È tutto quello che devi spendere." |
| 2–10 s | Cerchi la cifra | "Non 10 al giorno. Dieci in totale, con la carta, entro 30 giorni dall'apertura." |
| 10–18 s | Barri "bonifico" e "ricarica" | "Bonifici e ricariche non contano. Serve un pagamento con carta, fisica o wallet." |
| 18–24 s | Foglio girato | "Fai la spesa, paghi col telefono, hai finito. Sembra banale: è il punto in cui si perde più bonus." |
| 24–28 s | Primo piano | "80 euro se apri entro lunedì. Codice in bio. Se lo usi ricevo 50." |

**Didascalia:**
```
ADV | 10€ di spesa con carta entro 30 giorni: è questo il requisito che tutti sbagliano.

Bonifici e ricariche non valgono. Solo POS, e-commerce o wallet.

80€ per chi apre entro il 16/11. Codice in bio, se lo usi ricevo 50€.
#adv #buddybank #bonus #contocorrente
```

---

## Thread per X (copia-incolla)

**Post 1 (pin):**
```
Se ti hanno mandato un codice buddybank, chi te lo manda prende 50€.

Tu, fino a lunedì 16/11, puoi prenderne 80.

Ho letto il regolamento: ecco le 4 cose che la home non mette in evidenza. 🧵
```

**Post 2:**
```
1. Gli 80€ sono 50 + 30.

Il bonus extra da 30€ spetta solo all'invitato. Chi invita riceve 50€ per amico.
```

**Post 3:**
```
2. Per prenderli devi spendere almeno 10€ con la carta entro 30 giorni.

Bonifici e ricariche non contano: serve un pagamento con carta, fisica o wallet.
```

**Post 4:**
```
3. Se sei già cliente UniCredit o buddy dal 2020, sei escluso.

Non dipende dal codice: non puoi partecipare come invitato.
```

**Post 5:**
```
4. L'accredito arriva entro 90 giorni lavorativi.

Non è immediato. Se hai urgenza di quei soldi, non è lo strumento giusto.
```

**Post 6:**
```
Come si fa:

1. Apri dal sito o dall'app
2. Inserisci il codice durante la richiesta, non dopo
3. Spendi 10€ con carta entro 30 giorni

Codice: [INSERIRE CODICE]
Se lo usi ricevo 50€. ADV.
Regolamento: buddy.unicredit.it
```

**Immagine del thread:** una card con quattro numeri — **80 / 10 / 30 / 90** — e sotto: "80€ bonus · 10€ spesa · 30 giorni · 90 giorni lavorativi". Falla in Canva, formato 1200×675, stesso font del profilo.

---

## Commenti: cosa scrivere e come rispondere

### Commento fissato (TikTok e X)
```
CODICE: [INSERIRE CODICE]

80€ solo fino al 16/11 (50 + 30 extra).
Serve: apertura con codice + 10€ di spesa con carta entro 30 giorni.
Accredito fino a 90 giorni lavorativi.
Esclusi i già clienti UniCredit/buddy dal 2020.
Se lo usi ricevo 50€.
```

### Risposte pronte (prime 2 ore, sempre)
| Commento | Risposta |
|---|---|
| "Ho già UniCredit" | "Allora sei escluso: il regolamento esclude chi ha rapporti con la banca dal 2020. Non dipende dal codice." |
| "Quanto ci vuole?" | "Fino a 90 giorni lavorativi dalla spesa. Non è immediato." |
| "Dove lo metto?" | "Durante l'apertura, c'è un campo apposito. Dopo non si può più." |
| "È sicuro?" | "È una promo UniCredit con regolamento pubblico. Io non lavoro per la banca: ti sto spiegando le condizioni." |
| "Mandamelo in privato" | "È qui nel commento fissato, così lo vedono tutti." |
| "Non è arrivato niente" | "Controlla di aver speso 10€ **con carta** entro 30 giorni: bonifici e ricariche non valgono. Se hai rispettato tutto, apri un ticket in app." |

### Commenti su video di altri (senza codice, senza link)
Non spammare. Un commento utile ogni 10 video guardati. Esempi:
- "Occhio che sul bonus buddybank servono 10€ di spesa con carta: i bonifici non contano."
- "Il bonus è per chi non è già cliente dal 2020, se lo sei non lo prendi."
- "L'accredito è fino a 90 giorni lavorativi, non immediato."
- "La carta fisica ha 3,50€ di emissione + 5,70€ di spedizione: se non ti serve, prendi la digitale."
- "Se apri solo per il bonus, metti in conto 10€ di spesa: il netto reale è più basso."

**Mai:** "usa il mio codice", "scrivimi in privato", "guadagna facile". Sono i tre modi per farti bannare.

---

## Foto e grafiche a costo zero

1. **Copertina video:** screenshot della pagina ufficiale con "80 €" cerchiato in rosso e una freccia scritta a mano "fino al 16/11". Telefono + Canva.
2. **Card per X:** quattro numeri grandi — 80, 10, 30, 90 — su sfondo scuro, una riga di testo sotto.
3. **Carosello 5 slide:** "80 € in 5 schermate". Slide 1 hook, 2 cosa serve, 3 cosa non vale, 4 chi è escluso, 5 tempi e codice.
4. **Storia:** screenshot del campo "codice invito" con una freccia. Serve a chi ha già deciso.

Tutte con lo stesso colore (blu scuro o verde bosco), lo stesso font, la stessa faccia. La ripetizione visiva è ciò che ti rende riconoscibile in 1 secondo.

---

## Le 10 regole per provare a fare volume

1. **Hook nei primi 1,2 secondi.** Se il testo non si capisce senza audio, rifallo.
2. **Un video, un'idea.** Due idee = due video.
3. **Sotto i 30 secondi.** La retention conta più della durata.
4. **Taglio ogni 2 secondi.** B-roll, zoom, testo nuovo.
5. **Loop:** l'ultima frase riprende la prima. Chi arriva alla fine ricomincia.
6. **Domanda binaria:** "Sei già cliente UniCredit? Sì o no." I commenti sono il carburante.
7. **Rispondi a tutti nei primi 60 minuti.** Ogni risposta è un commento in più.
8. **Pubblica alle 12–14 e alle 19–21.** Testa, non fidarti.
9. **Due post al giorno, non dieci.** Il terzo abbassa la qualità e la distribuzione.
10. **Non cancellare un video dopo 2 ore.** L'algoritmo lo riprende anche dopo 48–72 ore.

**Sul "virale":** nessuno può garantirlo. Queste regole aumentano la probabilità, il volume fa il resto. Chi ti promette un video virale ti sta vendendo qualcosa.

---

## Programma 96 ore

| Giorno | Mattina | Sera |
|---|---|---|
| **Gio 12/11** | Crea account, foto, bio (30 min). Gira i video 1, 2, 3 (90 min). Monta (60 min) | Pubblica video 1 alle 20:00. Fissa il commento. |
| **Ven 13/11** | Pubblica il thread X alle 12:30 | Video 2 alle 19:30. Rispondi a tutti. |
| **Sab 14/11** | Video 3 (tutorial) alle 13:00 | Video 4 alle 20:00. Commenta 5 video di altri, senza codice. |
| **Dom 15/11** | Ripubblica il migliore con hook nuovo (non identico). Storia con il campo codice. | Rispondi alle domande, raccogli le obiezioni. |
| **Lun 16/11** | Post "oggi è l'ultimo giorno per gli 80 €" | Alle 23:59 smetti di promettere 80 €. |
| **Mar 17/11** | Aggiorna didascalie e commento fissato: "ora 50 €". | Post di transizione: "cosa resta". |

---

## Prima di pubblicare, 6 controlli

- [ ] "ADV" a schermo nei primi 2 secondi e a inizio didascalia.
- [ ] La cifra è "fino a 80 €", non "80 € garantiti".
- [ ] È chiaro che gli 80 € sono per l'invitato e che tu ricevi 50 €.
- [ ] Ci sono le condizioni: 10 € con carta, 30 giorni, 90 giorni lavorativi.
- [ ] È scritto che i già clienti dal 2020 sono esclusi.
- [ ] Il codice è quello giusto e non ci sono altri segnaposto.

Se una voce è "no", non pubblichi. Si corregge in 2 minuti, non si giustifica dopo.
