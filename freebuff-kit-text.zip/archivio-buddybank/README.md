# Archivio campagna buddybank

Questa cartella è un **archivio separato**. Non serve per la campagna Freebuff e non è
necessaria alla collega che lavora sul referral Freebuff.

I tre documenti Freebuff (`13`, `14`, `17`) sono stati spostati in
`freebuff-export/strategia/` con nomi più chiari.

## Cosa resta qui

| File | Cosa contiene |
|---|---|
| `01-verifica-offerta.md` | Verifica dell'offerta buddybank |
| `02-strategia-acquisizione.md` | Strategia di acquisizione |
| `03-setup-account.md` | Setup account |
| `04-script-video.md` | Script video |
| `05-copy-social.md` | Copy social |
| `06-piano-editoriale.md` | Piano editoriale |
| `07-compliance.md` | Compliance |
| `08-ai-workflow.md` | Workflow AI |
| `09-partenza-48h.md` | Partenza in 48 ore |
| `10-senza-volto.md` | Contenuti senza volto |
| `11-naming.md` | Naming |
| `12-naming-hype.md` | Naming hype |
| `15-toolkit-skill.md` | Toolkit skill |
| `16-contenuti-pronti.md` | Contenuti pronti |
| `calendario-editoriale.csv` | Calendario |

## Nota

La scadenza buddybank citata nei documenti è il **16 novembre 2026**. Se l'offerta è chiusa,
i documenti restano come archivio: non pubblicare nulla che la presenti come ancora attiva.
