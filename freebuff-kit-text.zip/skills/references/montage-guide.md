# Montage guide

How `clip-montage` and `montage-video` turn a client's clips or photos
into a montage: which shot goes first, how many fit, how each one moves,
what music suits it, and how to word it. Both skills read this file in
their steps 5 to 7. Edit it like `brand-voice.md` if your clients' taste
differs.

## Length and number of shots

| Length | Shots | Each shot | Good for |
|---|---|---|---|
| ~15s | 6–8 | about 2s | A teaser, "just listed", a single product, Stories |
| ~30s | 10–14 | 2–2.5s | The default listing or product reel |
| ~60s | 18–24 | 2.5–3s | A full tour, a luxury home, a product with several uses |

- Fewer, better photos beat every photo. A viewer remembers the three
  best rooms, not the hallway.
- Under about 1.5s a shot can't be taken in, and over about 4s it drags
  (`montage.js` warns at both ends). Give a hero shot, the view, or the
  best room a longer hold (`[hold: 2 bars]`) rather than slowing them all.
- A label needs time to be read, about four words a second. `montage.js`
  holds a shot longer when its text needs it.

## Property: the order

1. **The hook shot.** The strongest image, usually the front exterior at
   its best angle, or the single most striking room or view when the
   front is plain. The hook text and any status ("just listed", "open
   house sat 1–4") go on it.
2. **The way in:** the entry or the first view inside.
3. **Living spaces:** living room, then kitchen, then dining. The kitchen
   is usually the second-strongest shot.
4. **The main bedroom, then its bathroom.**
5. **Other bedrooms and bathrooms.** One or two is enough. Skip
   near-duplicates.
6. **Outdoor space or the view:** backyard, balcony, pool, the street.
7. **Something special:** a fireplace, an office, a renovated detail.
8. **The close:** a twilight exterior or the best shot again, with the
   price, specs, and CTA (`[facts]`, or the last shot).

For a rental or a vacation stay, swap the price for the nightly or
monthly rate and lead with what guests book for (the view, the pool).

## Product: the order

1. **The hero:** the product, clean, at its best angle. A packshot on
   white looks best with `[fit: card]`.
2. **The problem, or the moment of use.**
3. **Details:** texture, materials, the label, a button, a seam, each a
   push-in on that spot, or a `[callout: x%,y% ...]`.
4. **In use, or in its setting** (lifestyle photos).
5. **Options:** colors, sizes, scale next to a hand or an everyday object.
6. **What's in the box,** if that sells it.
7. **The offer:** price, any real discount, and the CTA.

## Clips

`clip-montage` makes montages from the user's own videos, the default
whenever they have footage (or can film some). It's free and it's the
truest picture: nothing is generated.

### Filming tips for clips

Send these when the user hasn't filmed yet:
- **Vertical** (hold the phone upright), on the main camera, 1080p or 4K
  at 30fps.
- **Steady:** hold each shot for 3 to 5 seconds. Start recording a second
  before the move and stop a second after it. Elbows in, or lean on
  something.
- **Slow moves:** walk in slowly, turn slowly, or hold still. A slow move
  reads as a camera; a fast one reads as a shaky phone.
- **Light:** daytime, lights on, blinds open. Food by a window.
- **One clip per room, angle, or moment,** plus close-ups of the details
  (the faucet, the label, the sizzle, the hands at work).
- **Sound:** when someone talks to the camera, film close to them, away
  from wind and loud music.
- **People and privacy:** ask before filming anyone, and move personal
  items (family photos, mail) out of frame.

### Clips: picking the moments

- Look at each clip with `montage.js frames <clip> --every 1`: a frame
  every second with its time, and when its sound is loud.
- 1.5 to 4 seconds a shot: the moment the subject is clearest and the
  camera steadiest. Skip the first and last second of most clips (the tap
  to start, the phone lowering).
- A long clip gives two or three shots from different moments, each its
  own line (`[from: 2] [to: 5]`, then `[from: 14] [to: 17]`).
- A landscape clip is cut to 9:16. Set `[focus: x%,y%]` on what has to
  stay in frame.
- Keep a clip's own sound (`[sound]`) where it adds something: someone
  talking, a laugh, the sizzle, the crowd. Everywhere else, the music.
  Captions on it are the exact words, from the user.
- Use `pace:` in beats for clips (`pace: 4 beats`). A shot is fitted up
  to the next beat, and a bar can stretch a 3-second stretch to 5.

### Clips: the order

- **A home or a room:** as "Property: the order" below.
- **A product:** as "Product: the order" below.
- **A restaurant, a shop, a service:** the hero moment (the dish, the
  finished cut, the reveal), the people making it, the details up close,
  the space, customers enjoying it (with their OK), then the CTA (book,
  visit, order).
- **An event or a recap:** the peak moment first (the crowd, the reveal,
  the toast), then arriving or setting up, the highlights in order, and
  the close (a thank-you, the next date).
- **A day at work, behind the scenes:** the most striking moment first,
  then the day in order, ending on the result.

## Moves

`montage.js` picks a move for each shot that doesn't name one. Override
it with `[move: ...]` when the photo asks for something else.

- **Wide room (landscape photo):** a slow pan toward the focal point
  (`pan-left` / `pan-right`). A 3:2 photo in a 9:16 frame shows only
  about 40% of its width at once, so a pan is how the viewer sees the
  whole room. Set `focus=` to the part that matters, and the pan centers
  on it.
- **Tall space** (stairs, a vaulted ceiling, a chandelier): `pan-up`.
- **Detail** (a faucet, a fireplace, a product label): `push-in` with
  `focus=` on the detail.
- **Exterior or reveal:** `pull-out` from the front door or the view.
- **Product on white:** `[fit: card]` with a gentle `push-in`.
- **A photo that must be seen whole** (a floor plan, a group shot):
  `[fit: contain]`, with `move: none` or a slow push-in.
- **Video clips** keep their own motion (`none`). A slow `push-in`,
  `pull-out`, or `drift` on top works; a pan slides the zoomed clip,
  since there's nothing beside the frame to pan to.
- Consecutive shots move in different directions. A pan never moves
  faster than about a sixth of the frame a second, since faster reads as
  a shaky phone.

### 3D moves

With the depth model set up, `montage.js` gives photos 3D moves by
default. A depth map (how far each point of the photo is) lets near
things move more than far ones, which is what a real camera does and a
plain zoom doesn't.

- **`orbit`** (on a wide room): the camera slides a little around the
  focal point while traveling across the room. The furniture slides
  against the back wall. Set `focus=` on what should stay put (the
  fireplace, the island).
- **`dolly-in` / `dolly-out`** (on a room with something near the
  camera): the camera moves in. Near things grow faster than the far
  wall, so it feels like stepping into the room, not zooming.
- **`rise`** (on a tall space or an exterior): the camera lifts, and the
  foreground drops away faster than the house behind it.
- **Strength:** `amount=1` by default. Up to `1.5` for photos with clear
  layers (a sofa in front of a window), down to `0.6` for busy ones.
- **Where it breaks:** thin things against a far background (chair legs,
  plants, railings) can smear at their edges, and glass and mirrors fool
  the depth model. Use a flat move or a lower `amount=` on those shots.
  Look at the `--slides`, and at a `--draft`, which shows the motion.
- **What it can't do:** show anything that isn't in the photo. The camera
  can't turn a corner or see behind the sofa. For a real new angle, cut
  to another photo of the same room taken from somewhere else.
- 3D shots render slower, about three times as long on a machine without
  a graphics card. Say so before a long render.

## AI camera moves

A connected video model (Figma Weave or Higgsfield; see `montage-video`'s
"AI camera moves") turns a photo into a short clip where the camera
really moves: around the island, through the doorway, up the stairs. It
costs credits, and it's for photos only: when the user can film clips,
`clip-montage` gives real camera moves for free. Offer it only when the
user says they have a paid plan with a video model, and quote each run
first. It invents
what the photo doesn't show, so keep moves short and slow (they stay
truest), check every clip with `montage.js frames`, and label it `[ai]`.

| Move | Prompt | Good for |
|---|---|---|
| Orbit | Slow, smooth camera orbit to the left around the {focal point} | A kitchen island, a sofa group, a dining table |
| Dolly in | Slow, smooth dolly forward into the room toward the {focal point} | Living rooms, bedrooms, a view out the window |
| Truck | Slow sideways camera move to the right along the {feature} | Built-ins, a long room, a gallery wall |
| Crane up | Camera slowly rises from the {low feature} to reveal the room | Tall rooms, a staircase, a chandelier |
| Drone pull-back | Drone slowly pulls back and up from the front door to reveal the whole house | Exteriors, a yard, a view |
| Through a door | Camera glides forward through the open {door} into the {room} | Linking two spaces, a reveal |
| Product orbit | Slow half orbit around the {product} on the {surface} | A product on a table or in use |

End every prompt with the same clause: "Steady gimbal shot, realistic,
natural light. The room stays exactly as it is: no people, no text, no
new furniture or objects, no changes to windows, walls, or finishes."
Name only what's in the photo.

**Models** (in Weave as of this writing; always go by the quote). Weave
runs video models only on paid Figma plans; on a free (Starter) plan it
refuses to quote them ("Video models are only available on paid plans").
- **Seedance 1.5 Pro**, about 31 credits a clip: 4–12 seconds, 720p or
  1080p, and it can output vertical 9:16. Set `camera_fixed: false` and
  `generate_audio: false`. The default.
- **Veo 3.1 (image to video)**, about 90 credits: the most detail, 1080p,
  but only horizontal from a photo.
- **MiniMax H3**, about 20 credits: 480–768p, and the photo sets the
  shape. Good for drafts.
- **Hailuo-02**, about 32 credits: follows camera directions in the prompt
  well.

**Cutting AI clips:** use 2–3 seconds of each clip. The first and last
seconds of one clip are two different angles, so they make two shots.
Skip a still first moment with `[from: 0.4]`, and use the smoothest part.
A montage of 6 photos becomes 8–10 shots this way.

## Transitions

- **fade** (the default): calm, for homes and premium products.
- **cut:** on the beat, energetic. Product reels, younger brands.
- **slide / wipe:** walking from one room to the next.
- **zoom:** stepping into a space or onto a product.
- **flash:** a reveal or a "sold".
- **punch** (a cut that lands zoomed in) and **whip** (a fast sideways
  move, blurred): energetic product reels, cut on the beat.
- **mask** (opening out of a circle), **blur**, **leak** (warm light across
  the cut), and **burn** (a hot flare): a premium or cinematic feel.
- **glitch** and **spin:** tech and loud, younger brands; sparingly.
Use one transition for most of the video and a different one only where
it means something (the reveal, the before/after). Every transition is
listed with the edit it makes in `editing-techniques.md`.

## Speed

A clip without its own sound can change speed: `[speed: 0.5]` for slow
motion (a pour, a door opening, a dress turning), `[speed: 2]` for fast
motion (a process, a walk through a long hallway), and `[ramp: ...]` for a
speed ramp, slowing on the moment that matters and back to full speed
(`[ramp: 1.2:0.3,2.4:1]`), or freezing on it (`[ramp: 1.5:0,2.3:1]`).
Smooth slow motion needs footage filmed at 60fps or more; ask for it when
the client films. A `[sound]` clip plays at normal speed.

## Music by mood

The client's saved Sonic Identity comes first. Change it for one video
only when the property or product calls for it, and say so.

| Property or product | Genre | Tempo | Shots |
|---|---|---|---|
| Luxury home, high-end product | `cinematic` or `calm` | 70–90 BPM | Longer holds, fades |
| Family home, suburban listing | `acoustic` | 90–105 BPM | Fades and slides |
| City condo, modern build | `house` or `lofi` | 110–124 BPM | Cuts on the bar |
| Vacation rental | `acoustic` or `funk` | 100–115 BPM | Slides, zooms |
| Tech or gadget | `tech` | 115–125 BPM | Cuts, zooms |
| Fashion, beauty | `pop` or `house` | 110–124 BPM | Cuts on the beat |
| Food and drink | `acoustic` or `funk` | 95–112 BPM | Slides |

Longer than about 45 seconds, the generated music repeats itself, so use
a licensed track (`media.js search --type music`) instead. A track's beat
is read with `beats.js`, so the cuts land on it.

## Voiceover

- One sentence per shot, 8 to 14 words, about what's on screen right
  then. Don't read the label aloud. Add what the photo can't show ("The
  kitchen was redone last year").
- Every fact in the voiceover comes from the user or the client.
- Music-only is often better for a listing: most people watch muted, and
  the labels carry the facts. Offer a voice for a tour, a story, or a
  product that needs explaining.
- The free local voice speaks English. For another language, the user
  records each line in their own voice (`recordings:`), and captions
  follow their words.
- Or the user records the whole voiceover in one take, a phone voice
  memo included (`voiceover:`), with its words in `voiceover-text:` for
  the captions. It plays under every shot, and the shots stretch to
  cover it.

## Labels and hooks

- A label names the space or the feature in 1 to 4 words ("Chef's
  kitchen"), with an optional second line for one detail ("quartz island
  · gas range").
- Hooks for property: the news ("just listed in maple grove"), the
  standout ("a backyard you won't believe for under $700k"), or a question
  ("would you live here?"). For a product: the result, the problem, or
  the reveal. See `hooks.md`.
- Specs read best as short chips: `4 bd · 3 ba · 2,450 sq ft`.

## Wording for property

US fair-housing rules apply to every ad for a home, a reel included.
Describe the property and the area. Never describe who should live
there.

- **Say:** "three bedrooms", "fenced yard", "single-level living", "near
  the park and the train", "quiet street", "walk-in shower".
- **Don't say:** "perfect for families", "ideal for young
  professionals", "great for retirees", "bachelor pad", "exclusive
  neighborhood", "safe area", or anything about race, color, religion,
  national origin, sex, disability, or family status, even as a
  compliment.
- An accessibility feature is a feature ("step-free entry", "grab bars
  in the main bath"). Say what it is, not who it's for.
- Many states and brokerages require the brokerage name or a license
  number on ads, and many agents show "Equal Housing Opportunity". These
  go in the client's `Fine print`, shown on the end card. Ask; don't
  guess.

## Staged and edited photos

- Color, exposure, white balance, and straightening are fine.
- Virtual staging (furniture added by software) is allowed in most
  places only when it's disclosed. Every virtually staged photo gets the
  `[staged]` badge, and the caption says the photos include virtual
  staging.
- Never remove a defect (a crack, a power line, a neighbor's wall), add a
  feature, or replace the sky or view in a way that changes what a buyer
  would see in person.
- AI-animated clips of a property (from a connected video model) can
  change details. Check every frame against the photo, and drop any clip
  that changes the property.

## Photos and clips: rights and privacy

- Use photos and clips the client owns, or the listing photographer's
  licensed to the client. Never pull photos from a listing site or
  another agent's listing.
- `montage.js inspect` strips each photo's and clip's metadata, a phone's
  GPS location included, from the copies it makes.
- Leave out photos that show a recognizable person who didn't agree to
  appear, or the occupants' personal items (family photos, mail,
  documents, a car's plate).
